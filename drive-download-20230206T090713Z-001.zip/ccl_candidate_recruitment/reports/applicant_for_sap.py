from odoo import models


class ApplicantForSAP(models.AbstractModel):
    _name = 'report.ccl_candidate_recruitment.applicant_for_sap_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('Applicant For SAP')
        format_heading = workbook.add_format(
            {'text_wrap': True, 'border': True, 'font_size': 10, 'valign': 'vcenter', 'align': 'center', 'bold': True,
             'font_name': 'cambria'})
        format_body = workbook.add_format(
            {'text_wrap': True, 'font_size': 10, 'valign': 'vcenter', 'align': 'center', 'border': True,
             'font_name': 'cambria'})

        sheet.set_column(1, 28, 12)
        sheet.set_row(0, 35)
        sheet.write(0, 0, "SAP ID", format_heading)
        sheet.write(0, 1, "Start Date", format_heading)
        sheet.write(0, 2, "End Date", format_heading)
        sheet.write(0, 3, "Action Reason", format_heading)
        sheet.write(0, 4, "Position", format_heading)
        sheet.write(0, 5, "Personal Area", format_heading)
        sheet.write(0, 6, "Employee Group", format_heading)
        sheet.write(0, 7, "Employee Sub Group", format_heading)
        sheet.write(0, 8, "Personnel Sub Area", format_heading)
        sheet.write(0, 9, "Payroll area", format_heading)
        sheet.write(0, 10, "Work Contract", format_heading)
        sheet.write(0, 11, "HPL Work Area", format_heading)
        sheet.write(0, 12, "Title", format_heading)
        sheet.write(0, 13, "Last Name", format_heading)
        sheet.write(0, 14, "Middle Name", format_heading)
        sheet.write(0, 15, "First Name", format_heading)
        sheet.write(0, 16, "Name Format", format_heading)
        sheet.write(0, 17, "Gender", format_heading)
        sheet.write(0, 18, "Birth Date", format_heading)
        sheet.write(0, 19, "Birth Place", format_heading)
        sheet.write(0, 20, "Marital Status", format_heading)
        sheet.write(0, 21, "Since", format_heading)
        sheet.write(0, 22, "Country of Birth", format_heading)
        sheet.write(0, 23, "No of Child", format_heading)
        sheet.write(0, 24, "Division", format_heading)
        sheet.write(0, 25, "Religion", format_heading)
        sheet.write(0, 26, "Nationality", format_heading)
        serial_number = 1
        row = 1
        col = 1

        for index, line in enumerate(lines):
            name = str(line.partner_name).split(' ')
            last_name = name[-1]
            fname = ''
            for i in range(0, len(name) - 1):
                fname += ' ' + str(name[i])
            birth_date = (line.date_of_birth).strftime('%d.%m.%Y') if line.date_of_birth else ''

            sheet.set_row(row, 30)
            sheet.write(row, 0, '', format_body)
            sheet.write(row, 1, '', format_body)
            sheet.write(row, 2, '31.12.9999', format_body)
            sheet.write(row, 3, '01', format_body)
            sheet.write(row, 4, line.job_id.name, format_body)
            sheet.write(row, 5, '', format_body)
            sheet.write(row, 6, 'B', format_body)
            sheet.write(row, 7, '01', format_body)
            sheet.write(row, 8, '', format_body)
            sheet.write(row, 9, 'Z1', format_body)
            sheet.write(row, 10, '', format_body)
            sheet.write(row, 11, '02', format_body)
            sheet.write(row, 12, 'Mr.' if line.gender.name == 'Male' else 'Ms.', format_body)
            sheet.write(row, 13, last_name, format_body)
            sheet.write(row, 14, '', format_body)
            sheet.write(row, 15, fname, format_body)
            sheet.write(row, 16, '', format_body)
            sheet.write(row, 17, line.gender.code if line.gender else '', format_body)
            sheet.write(row, 18, birth_date, format_body)
            sheet.write(row, 19, '', format_body)
            sheet.write(row, 20, line.marital_status.code if line.marital_status.name else '', format_body)
            sheet.write(row, 21, '', format_body)
            sheet.write(row, 22, 'BD', format_body)
            sheet.write(row, 23, '', format_body)
            sheet.write(row, 24, '', format_body)
            sheet.write(row, 25, line.religion.code if line.religion else '', format_body)
            sheet.write(row, 26, 'BD', format_body)
            serial_number += 1
            row += 1
