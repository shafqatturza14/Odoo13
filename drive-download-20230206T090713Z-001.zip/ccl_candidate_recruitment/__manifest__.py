# -*- coding: utf-8 -*-

{
    'name': "ccl_candidate_recruitment",

    'summary': """""",

    'description': """
        Candidate Recruitment module
    """,

    'author': "Mim Jannat",
    'website': "",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly


    'depends': ['base', 'report_xlsx', 'hr_recruitment', 'recruitment_requests', 'hr', 'hpl_employee'],

    # always loaded
    'data': [
        'wizard/manpower_requisition_form_mail.xml',
        'wizard/send_to_hr_mail_requisition.xml',
        'wizard/hr_received.xml',
        'data/sequence.xml',
        'data/mail_template.xml',
        'security/ir.model.access.csv',
        'views/mail_template.xml',
        'views/templates.xml',
        'views/recruitment_requisition_form.xml',
        'views/pre_boarding_checklist.xml',
        'views/assessment_template.xml',
        'views/interview_evaluation_form.xml',
        'views/manpower_summary_view.xml',
        'views/report_wizard_view.xml',
        'views/candidate_wr_test.xml',
        'views/applicant_inherit.xml',
        'views/interview_schedule.xml',
        'views/hr_job_inherit_view.xml',
        'views/hr_department_inherit_view.xml',
        'views/new_employee.xml',
        'wizard/written_test_attendance.xml',
        'wizard/fresh_candidate_summary_wizard.xml',
        'wizard/experience_candidate_summary_wizard.xml',
        'wizard/written_test_result.xml',
        'wizard/interview.xml',
        'wizard/manpower_slot_wizard.xml',
        'wizard/manpower_approval_summary_wizard.xml',
        'reports/manpower_requisition_form.xml',
        'reports/pre_boarding_checklist.xml',
        'reports/interview_evaluation_form_report.xml',
        'reports/written_test_attendance_sheet.xml',
        'reports/fresher_candidate_summary.xml',
        'reports/experience_candidate_summary.xml',
        'reports/written_test_result.xml',
        'reports/interview.xml',
        'reports/applicant_for_sap.xml',
        'reports/manpower_approval_summary_wizard.xml',
        'reports/manpower_approval_details_wizard.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
