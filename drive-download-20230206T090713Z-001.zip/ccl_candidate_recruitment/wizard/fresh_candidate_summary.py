from odoo import fields, api, models


class FreshCandidateSummary(models.TransientModel):
    _name = 'fresh.candidate.summary.wizard'

    department_id = fields.Many2one('hr.department', string="Department", required=True)
    job_id = fields.Many2one('hr.job', string='Designation', required=True)

    def generate_fresh_candidate_summary(self):
        data = {
            'department_id': self.department_id.id,
            'department': self.department_id.name,
            'job_id': self.job_id.id,
            'job': self.job_id.name,

        }
        return self.env.ref('ccl_candidate_recruitment.action_fresh_candidate_summary_report').report_action(self, data=data)


class ReturnXlsxReport(models.AbstractModel):
    _name = 'report.ccl_candidate_recruitment.fresh_summary_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('Final Result Sheet Report')
        format_heading = workbook.add_format({'font_size': 10, 'align': 'center', 'bold': True})
        format_heading.set_bg_color('#d9d1d1')
        format_body = workbook.add_format({'font_size': 12, 'align': 'left'})
        bold = workbook.add_format({'font_size': 14, 'align': 'center', 'bold': True, 'border': True})

        sheet.write(5, 0, 'SI', format_heading)
        sheet.write(5, 1, 'Name', format_heading)
        sheet.write(5, 2, 'Mobile', format_heading)
        sheet.write(5, 3, 'SSC', format_heading)
        sheet.write(5, 4, 'HSC', format_heading)
        sheet.write(5, 5, 'Grad', format_heading)
        sheet.write(5, 6, 'Post Grad', format_heading)
        sheet.write(5, 7, 'Grad University', format_heading)
        sheet.write(5, 8, 'Post Grad University', format_heading)
        sheet.write(5, 9, 'Subject', format_heading)
        # sheet.write(5, 10, 'Total Exp.', format_heading)

        sheet.merge_range('A1:K3',  "Candidate Summary Report(Freshers)||" + data.get('department') +
                          " " + data.get('job'), bold)

        # sheet.write('A3:K3')
        sheet.set_column(1, 1, 20)
        sheet.set_column(7, 9, 20)
        sheet.set_column(0, 0, 5)
        sheet.set_column(2, 6, 15)
        sheet.set_column(10, 10, 15)

        department = data.get('department')
        department_id = data.get('department_id')
        job = data.get('job')
        job_id = data.get('job_id')

        sql_query = f"""
                 SELECT
              applicant.partner_name         as name,
              applicant.sl_code              as sl_code,
              applicant.partner_phone      as mobile,
              applicant.ssc                  as ssc,
              applicant.hsc                  as hsc,
              applicant.grad                 as grad,
              applicant.post_grad            as post_grad,
              applicant.grad_university      as grad_university,
              applicant.post_grad_university as post_grad_university,
              applicant.subject              as subject,
              applicant.experience           as exp
            
            from
              hr_applicant as applicant
            
            WHERE
              applicant.is_experienced = FALSE
              AND
              (applicant.job_id = '%s'
              OR
              applicant.department_id = '%s')
              
            
            Group by
              applicant.partner_name,
              applicant.sl_code,
              applicant.partner_phone,
              applicant.ssc,
              applicant.hsc,
              applicant.grad,
              applicant.post_grad,
              applicant.grad_university,
              applicant.post_grad_university,
              applicant.subject,
              applicant.experience
            
            Order BY
              applicant.sl_code;

                """ %(job_id, department_id)

        self.env.cr.execute(sql_query)
        query_data = self.env.cr.fetchall()

        rows = 6
        serial = 1
        for item in (query_data):
            sheet.write(rows, 0, serial, format_body)
            sheet.write(rows, 1, item[0], format_body)
            sheet.write(rows, 2, item[2], format_body)
            sheet.write(rows, 3, item[3], format_body)
            sheet.write(rows, 4, item[4], format_body)
            sheet.write(rows, 5, item[5], format_body)
            sheet.write(rows, 6, item[6], format_body)
            sheet.write(rows, 7, item[7], format_body)
            sheet.write(rows, 8, item[8], format_body)
            sheet.write(rows, 9, item[9], format_body)
            # sheet.write(rows, 10, item[10], format_body)
            rows += 1
            serial += 1
