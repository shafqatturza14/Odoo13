requisition_mail_template_body = '''

'''