# -*- coding: utf-8 -*-
from odoo import fields, api, models, _


class ManpowerRequisitionMail(models.TransientModel):
    _name = 'manpower.requisition.mail.hr'

    wiz_to_name = fields.Many2one('hpl.employee', 'To Name')
    to_name_mail = fields.Char('To Mail')
    wiz_c_name = fields.Many2many('hpl.employee', string='Concern People')
    all_cc_mail = fields.Char('Concern Mail')

    @api.model
    def default_get(self, fields):
        res = super(ManpowerRequisitionMail, self).default_get(fields)
        active_id = self._context.get('active_id')
        trainee = self.env['hr.recruitment.requisition'].browse(active_id)
        print("Yes, I am in")
        # res['requisition_mail_template_body'] = strings.requisition_mail_template_body.format(

        return res

    @api.onchange('wiz_to_name', 'wiz_c_name')
    def change_mail(self):
        active_id = self._context.get('active_id')
        trainee = self.env['hr.recruitment.requisition'].browse(active_id)
        cc_all_mail = ''
        for rec in self:
            rec.wiz_to_name = trainee.hr_id
            for to in rec.wiz_to_name.communication_line:
                if to.communication_type.code == '0010':
                    rec.to_name_mail = to.value
            for wiz in rec.wiz_c_name:
                for con in wiz.communication_line:
                    if con.communication_type.code == '0010':
                        cc_all_mail += con.value + ','
                        rec.all_cc_mail += con.value + ','
            rec.all_cc_mail = cc_all_mail

    def action_send_to_hr(self):
        active_id = self._context.get('active_id')
        trainee = self.env['hr.recruitment.requisition'].browse(active_id)
        template_id = self.env.ref('ccl_candidate_recruitment.requisition_email_hr_template').id
        template = self.env['mail.template'].browse(template_id)
        template['email_to'] = self.to_name_mail
        template['email_cc'] = self.all_cc_mail
        trainee.state = 'sent_to_hr'
        template.send_mail(trainee.id, force_send=True)



