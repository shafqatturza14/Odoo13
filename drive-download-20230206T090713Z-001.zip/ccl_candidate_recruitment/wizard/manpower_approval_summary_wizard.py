from odoo import fields, api, models
from datetime import datetime, timedelta


class ManpowerApprovalSummary(models.TransientModel):
    _name = 'manpower.approval.summary.report.wizard'

    planning_year = fields.Date('Planning Year')
    department_id = fields.Many2one('hr.department', string="Department")
    unit = fields.Many2one('business.unit', string='Business Unit', required=True)
    section = fields.Many2one('hr.section', string='Section')

    def generate_approval_summary_report(self):
        data = {
            'department_id': self.department_id.id,
            'department': self.department_id.name,
            'unit_id': self.unit.id,
            'unit': self.unit.name,
            'section_id': self.section.id,
            'section': self.section.name,
            'planning_year': self.planning_year,

        }
        return self.env.ref('ccl_candidate_recruitment.action_manpower_approval_report').report_action(self, data=data)


class ReturnXlsxReport(models.AbstractModel):
    _name = 'report.ccl_candidate_recruitment.manpower_approval_summary_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('Manpower Summary Report Excel')
        format_heading = workbook.add_format({'font_size': 8, 'font_name':'Calibri','valign': 'left', 'bold': True, 'bg_color': '#c6ced9', 'border': True})
        format_heading_rotate = workbook.add_format({'font_size': 8,'font_name':'Calibri',  'align': 'left', 'bold': True, 'border': True,  'rotation': '90'})
        format_heading_rotate_am = workbook.add_format(
            {'font_size': 8,'font_name':'Calibri',  'bold': True, 'bg_color': '#F4c2c2', 'border': True,  'rotation': '90'})

        format_heading_rotate_em = workbook.add_format(
            {'font_size': 8,'font_name':'Calibri',  'align': 'left', 'bold': True, 'bg_color': '#c6ced9', 'border': True,  'rotation': '90'})
        format_heading_rotate_bm = workbook.add_format(
            {'font_size': 8,'font_name':'Calibri',  'align': 'left', 'bold': True, 'bg_color': '#cefad0', 'border': True,  'rotation': '90'})


        format_body = workbook.add_format({'font_size': 8,'font_name':'Calibri',  'align': 'center', 'border': True})

        format_body_sum = workbook.add_format(
            {'align': 'center', 'valign': 'center', 'font_size': 8,'font_name':'Calibri',  'bg_color': '#e9a447', 'border': True})
        format_body_am = workbook.add_format(
            {'align': 'center', 'valign': 'center', 'font_size': 8,'font_name':'Calibri',  'bg_color': '#F4c2c2', 'border': True})
        format_body_em = workbook.add_format(
            {'align': 'center', 'valign': 'center', 'font_size': 8,'font_name':'Calibri',  'bg_color': '#c6ced9','border': True})
        format_body_bm = workbook.add_format(
            {'align': 'center', 'valign': 'center', 'font_size': 8,'font_name':'Calibri',  'bg_color': '#cefad0','border': True})

        bold = workbook.add_format(
            {'font_size': 8,'font_name':'Calibri',  'bold': True, 'align': 'center', 'valign': 'center','border': True})

        title_2 = workbook.add_format(
            {'font_size': 8,'font_name':'Calibri',  'bold': True, 'valign': 'center', 'border': True})

        title_2_am = workbook.add_format(
            {'font_size': 8,'font_name':'Calibri',  'bold': True, 'valign': 'center', 'border': True, 'bg_color': '#F4c2c2'})

        title_2_em = workbook.add_format(
            {'font_size': 8,'font_name':'Calibri',  'bold': True, 'valign': 'center', 'border': True, 'bg_color': '#c6ced9'})

        title_2_bm = workbook.add_format(
            {'font_size': 8,'font_name':'Calibri',  'bold': True, 'valign': 'center', 'border': True, 'bg_color': '#cefad0'})

        title = workbook.add_format(
            {'bold': True, 'align': 'center', 'valign': 'center', 'font_size': 14, 'font_name': 'Calibri',
             'bg_color': '#f2eee4'})
        title_end = workbook.add_format(
            {'bold': True, 'align': 'center', 'valign': 'center', 'font_size': 8, 'font_name': 'Calibri',
             'bg_color': '#f2eee4'})

        title_business_unit = workbook.add_format(
            {'bold': True, 'align': 'center', 'font_size': 8,'font_name':'Calibri',  'bg_color': '#f2eee4','border': True})

        sheet.set_column(3, 20, 5)
        sheet.set_column(0, 2, 20)
        # sheet.set_column(3, 5, workbook.add_format({'bg_color': '#87cefa'}))
        planning_year = data.get('planning_year')
        from datetime import datetime
        d = datetime.strptime(planning_year, '%Y-%m-%d')
        print(type(d))
        print((d))

        sheet.merge_range('A1:U3', "Healthcare Pharmaceuticals Limited", title)
        sheet.merge_range('A4:U5', data.get('unit') + "\n" +
                          "Manpower Planning  " + d.strftime('%B %d,%Y'), title_end)
        sheet.set_row(5,1)
        sheet.set_row(6,1)
        sheet.set_row(7,1)
        sheet.set_row(8,1)

        row_start = 13
        serial_number = 1
        sheet.merge_range('A10:A14', "Business Unit", format_heading)
        sheet.merge_range('B10:B14', "Department", format_heading)
        sheet.merge_range('C10:C14', "Section", format_heading)
        sheet.merge_range('D10:F11', "Approval Manpower", title_2_am)
        sheet.merge_range('D12:D14', "Mgt", format_heading_rotate_am)
        sheet.merge_range('E12:E14', "Non\nMgt", format_heading_rotate_am)
        sheet.merge_range('F12:F14', "Total", format_heading_rotate_am)
        sheet.merge_range('G10:L11', "Existing Manpower", title_2_em)
        sheet.merge_range('G12:G14', "Mgt", format_heading_rotate_em)
        sheet.merge_range('H12:K12', "Non Mgt", title_2_em)
        sheet.merge_range('H13:H14', "Per.", format_heading_rotate_em)
        sheet.merge_range('I13:I14', "Casu\nal", format_heading_rotate_em)
        sheet.merge_range('J13:J14', "DL", format_heading_rotate_em)
        sheet.merge_range('K13:K14', "Total", format_heading_rotate_em)
        sheet.merge_range('L12:L14', "Total", format_heading_rotate_em)
        sheet.merge_range('M10:Q11', "Balance Manpower", title_2_bm)
        sheet.merge_range('M12:M14', "Mgt-\nTotal", format_heading_rotate_bm)
        sheet.merge_range('N12:N14', "Replace\nment", format_heading_rotate_bm)
        sheet.merge_range('O12:O14', "New", format_heading_rotate_bm)
        sheet.merge_range('P12:P14', "Non\nMgt-\nTotal", format_heading_rotate_bm)
        sheet.merge_range('Q12:Q14', "Grand\nTotal", format_heading_rotate_bm)
        sheet.merge_range('S10:U11', "University Statistics\n(Mgt)", title_2)
        sheet.merge_range('S12:S14', "Public", format_heading_rotate)
        sheet.merge_range('T12:T14', "Private", format_heading_rotate)
        sheet.merge_range('U12:U14', "National", format_heading_rotate)

        unit = data.get('unit')
        unit_id = data.get('unit_id')


        if data.get('department_id'):
            dept_id = self.env['hr.department'].search([('business_unit', '=', unit_id), ('id', '=', data.get('department_id'))])
        else:
            dept_id = self.env['hr.department'].search([('business_unit', '=', unit_id)])

        print(dept_id)
        row = 14
        dept = 0
        dept_app_mgt = 0
        dept_app_non_mgt = 0
        dept_app_total_ = 0
        dept_ex_mgt = 0
        dept_per_mgt = 0
        dept_cas_mgt = 0
        dept_dl_mgt = 0
        dept_ex_non_mgt = 0
        dept_ex_all = 0
        dept_bm_mgt = 0
        dept_bm_rep = 0
        dept_bm_new = 0
        dept_bm_non = 0
        dept_bm_all = 0
        dept_public= 0
        dept_private= 0
        dept_national = 0
        is_deprtment_one = False
        for department_line in dept_id:
            dept += 1
            sections = self.env['hr.section'].search([('department_id', '=', department_line.id)])
            manage_total_sum = 0
            per_non_mgt_total_sum = 0
            cas_total_sum = 0
            dl_total_sum = 0
            public_sum = 0
            private_sum = 0
            national_sum = 0

            approved_mgt_sum = 0
            approved_non_mgt_sum = 0
            approved_total_sum = 0

            replace_total_sum = 0
            new_total_sum = 0

            print(sections)
            if sections:
                for val in sections:
                    employee_mn_sub_group = self.env['hpl.employee.sub.group'].search([('code', '=', '01')])
                    employee_cas_sub_group = self.env['hpl.employee.sub.group'].search([('code', '=', '03')])
                    employee_dl_sub_group = self.env['hpl.employee.sub.group'].search([('code', '=', '04')])

                    employee_per_group = self.env['hpl.employee.group'].search([('code', '=', 'A')])
                    employee_non_mng_sub_group = self.env['hpl.employee.sub.group'].search([('code', '=', '02'),
                                                                                            ('employee_group', '=', employee_per_group.id)])

                    approved_manpower = self.env['manpower.summary.lines'].search([('section', '=', val.id)])


                    em_mn_total = 0
                    em_cas_total = 0
                    em_dl_total = 0
                    em_non_mgt_per_total = 0

                    approved_mgt = 0
                    approved_non_mgt = 0
                    approved_total = 0

                    planning_year, month, day = str(data.get('planning_year')).split("-")
                    for approved in approved_manpower:

                        manpower_year, month, day = str(approved.manpower_line_id.planning_year).split("-")
                        print(approved)
                        if manpower_year == planning_year:
                            approved_mgt += approved.am_mgt
                            approved_non_mgt += approved.am_non_mgt
                            approved_total += (approved_mgt + approved_non_mgt)

                    approved_mgt_sum += approved_mgt
                    approved_non_mgt_sum += approved_non_mgt
                    approved_total_sum += approved_total

                    for mng in employee_mn_sub_group:
                        em_mn_total += self.env['hpl.employee'].search_count(
                            [('section', '=', val.id), ('employee_sub_group', '=', mng.id)])

                    manage_total_sum += em_mn_total

                    for cas in employee_cas_sub_group:
                        em_cas_total += self.env['hpl.employee'].search_count(
                        [('section', '=', val.id), ('employee_sub_group', '=', cas.id)])

                    cas_total_sum += em_cas_total

                    for dl in employee_dl_sub_group:
                        em_dl_total += self.env['hpl.employee'].search_count(
                        [('section', '=', val.id), ('employee_sub_group', '=', dl.id)])

                    dl_total_sum += em_dl_total

                    for non_mgt in employee_non_mng_sub_group:
                        em_non_mgt_per_total += self.env['hpl.employee'].search_count(
                        [('section', '=', val.id), ('employee_sub_group', '=', non_mgt.id)])
                    per_non_mgt_total_sum += em_non_mgt_per_total

                    # University
                    public = self.env['hpl.employee'].search_count(
                        [('section', '=', val.id), ('institute_type', '=', 'public')])
                    public_sum += public
                    private = self.env['hpl.employee'].search_count(
                        [('section', '=', val.id), ('institute_type', '=', 'private')])
                    private_sum +=private
                    national = self.env['hpl.employee'].search_count(
                        [('section', '=', val.id), ('institute_type', '=', 'national')])
                    national_sum += national

                    replace = 0
                    for mngt in employee_mn_sub_group:
                        print(employee_mn_sub_group)
                        replace += self.env['exit.request'].search_count(
                            [('section_id', '=', val.id), ('is_replacement_available', '=', True)])
                        replace += self.env['employee.emergency.exit'].search_count(
                            [('section_id', '=', val.id), ('is_replacement_available', '=', True)])

                    replace_total_sum += replace

                    non_mgt_total = em_non_mgt_per_total + em_cas_total+em_dl_total
                    grand_total = (approved_mgt - em_mn_total) + (approved_non_mgt - non_mgt_total)
                    new = (approved_mgt - em_mn_total) - replace
                    new_total_sum += new

                    sheet.write(row, 0, unit, format_body)
                    sheet.write(row, 1, department_line.name, format_body)
                    sheet.write(row, 2, val.name, format_body)
                    sheet.write(row, 3, approved_mgt, format_body_am)
                    sheet.write(row, 4, approved_non_mgt, format_body_am)
                    sheet.write(row, 5, approved_total, format_body_am)
                    sheet.write(row, 6, em_mn_total, format_body_em)
                    sheet.write(row, 7, em_non_mgt_per_total, format_body_em)
                    sheet.write(row, 8, em_cas_total, format_body_em)
                    sheet.write(row, 9, em_dl_total, format_body_em)
                    sheet.write(row, 10, non_mgt_total, format_body_em)
                    sheet.write(row, 11, em_mn_total + non_mgt_total, format_body_em)
                    sheet.write(row, 12, approved_mgt - em_mn_total, format_body_bm)
                    sheet.write(row, 13, replace, format_body_bm)
                    sheet.write(row, 14, new, format_body_bm)
                    sheet.write(row, 15, approved_non_mgt - non_mgt_total, format_body_bm)
                    sheet.write(row, 16, grand_total, format_body_bm)

                    sheet.write(row, 18, public, format_body)
                    sheet.write(row, 19, private, format_body)
                    sheet.write(row, 20, national, format_body)
                    row += 1

                full_non_mgt_sum = per_non_mgt_total_sum + dl_total_sum + cas_total_sum
                all_sum = full_non_mgt_sum + manage_total_sum

                balance_mgt_sum = approved_mgt_sum - manage_total_sum
                balance_non_mgt_sum = approved_non_mgt_sum - full_non_mgt_sum

                sheet.write(row, 0, "", format_body_sum)
                sheet.write(row, 1, '', format_body_sum)
                sheet.write(row, 2, "Total:", format_body_sum)
                sheet.write(row, 3, approved_mgt_sum, format_body_sum)
                sheet.write(row, 4, approved_non_mgt_sum, format_body_sum)
                sheet.write(row, 5, approved_total_sum, format_body_sum)
                sheet.write(row, 6, manage_total_sum, format_body_sum)
                sheet.write(row, 7, per_non_mgt_total_sum, format_body_sum)
                sheet.write(row, 8, cas_total_sum, format_body_sum)
                sheet.write(row, 9, dl_total_sum, format_body_sum)
                sheet.write(row, 10, full_non_mgt_sum, format_body_sum)
                sheet.write(row, 11, all_sum, format_body_sum)
                sheet.write(row, 12, balance_mgt_sum, format_body_sum)
                sheet.write(row, 13, replace_total_sum, format_body_sum)
                sheet.write(row, 14, new_total_sum, format_body_sum)
                sheet.write(row, 15, balance_non_mgt_sum, format_body_sum)
                sheet.write(row, 16, balance_mgt_sum + balance_non_mgt_sum, format_body_sum)

                sheet.write(row, 18, public_sum, format_body_sum)
                sheet.write(row, 19, private_sum, format_body_sum)
                sheet.write(row, 20, national_sum, format_body_sum)
                row += 1

                dept_app_mgt += approved_mgt_sum
                dept_app_non_mgt += approved_non_mgt_sum
                dept_app_total_ += approved_total_sum
                dept_ex_mgt += manage_total_sum
                dept_per_mgt += per_non_mgt_total_sum
                dept_cas_mgt += cas_total_sum
                dept_dl_mgt += dl_total_sum
                dept_ex_non_mgt += full_non_mgt_sum
                dept_ex_all += all_sum
                dept_bm_mgt += balance_mgt_sum
                dept_bm_rep += replace_total_sum
                dept_bm_new += new_total_sum
                dept_bm_non += balance_non_mgt_sum
                dept_bm_all += (balance_mgt_sum + balance_non_mgt_sum)
                dept_public += public_sum
                dept_private += private_sum
                dept_national += national_sum
            if is_deprtment_one == True:
                break


        if dept > 1:
            sheet.write(row, 0, "", format_body_sum)
            sheet.write(row, 1, '', format_body_sum)
            sheet.write(row, 2, "Total:", format_body_sum)
            sheet.write(row, 3, dept_app_mgt, format_body_sum)
            sheet.write(row, 4, dept_app_non_mgt, format_body_sum)
            sheet.write(row, 5, dept_app_total_, format_body_sum)
            sheet.write(row, 6, dept_ex_mgt, format_body_sum)
            sheet.write(row, 7, dept_per_mgt, format_body_sum)
            sheet.write(row, 8, dept_cas_mgt, format_body_sum)
            sheet.write(row, 9, dept_dl_mgt, format_body_sum)
            sheet.write(row, 10, dept_ex_non_mgt, format_body_sum)
            sheet.write(row, 11, dept_ex_all, format_body_sum)
            sheet.write(row, 12, dept_bm_mgt, format_body_sum)
            sheet.write(row, 13, dept_bm_rep, format_body_sum)
            sheet.write(row, 14, dept_bm_non, format_body_sum)
            sheet.write(row, 15, dept_bm_non, format_body_sum)
            sheet.write(row, 16, dept_bm_all,
                        format_body_sum)

            sheet.write(row, 18, dept_public, format_body_sum)
            sheet.write(row, 19, dept_private, format_body_sum)
            sheet.write(row, 20, dept_national, format_body_sum)
