from odoo import fields, models, api
from datetime import datetime, timedelta, date, time
from pytz import timezone


class WrittenAttendanceSheet(models.TransientModel):
    _name = 'written.test.attendance.wizard'
    _description = 'Written Test Attendance Wizard'

    department_id = fields.Many2one('hr.department', string="Department", required=True)
    job_id = fields.Many2one('hr.job', string='Designation',required=True)

    def generate_attendance_report(self):
        department = self.department_id
        job = self.job_id
        datas = []

        sql_query = f"""
         SELECT
          applicant.partner_name,
          applicant.sl_code,
          applicant.partner_phone,
          applicant.signature
        
        from
          hr_applicant as applicant
        JOIN 
          hr_recruitment_stage as stages on stages.id = applicant.stage_id
        
        WHERE 
        (  applicant.job_id = {job.id}
        AND
          applicant.department_id = {department.id}
          )
        AND
         stages.sequence = 1
         
        Group by
            applicant.partner_name,
            applicant.sl_code,
            applicant.partner_phone,
            applicant.signature
        Order BY
          applicant.sl_code
        ;                     
        """
        print(sql_query)
        self.env.cr.execute(sql_query)
        attendances = self.env.cr.fetchall()
        print(attendances)
        for rec in attendances:
            datas.append({
                'name': rec[0],
                'sl_code': rec[1],
                'mobile': rec[2]

            })

        res = {
            'attendances': datas,
            'department': self.department_id.name,
            'job': self.job_id.name,
        }
        print(res)
        data = {
            'form': res,
        }
        return self.env.ref('ccl_candidate_recruitment.report_candidate_attendance').report_action([], data=data)

