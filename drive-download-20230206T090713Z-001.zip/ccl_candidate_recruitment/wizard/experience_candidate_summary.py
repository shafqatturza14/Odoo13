from odoo import fields, api, models


class ExperienceCandidateSummary(models.TransientModel):
    _name = 'experience.candidate.summary.wizard'

    department_id = fields.Many2one('hr.department', string="Department", required=True)
    job_id = fields.Many2one('hr.job', string='Designation', required=True)
    stage_id = fields.Many2one('hr.recruitment.stage', string='Stage', required=True)

    def generate_experience_candidate_summary(self):
        data = {
            'department_id': self.department_id.id,
            'department': self.department_id.name,
            'job_id': self.job_id.id,
            'job': self.job_id.name,
            'stage_id': self.stage_id.id,
        }
        return self.env.ref('ccl_candidate_recruitment.action_candidate_summary_report').report_action(self, data=data)


class ReturnXlsxReport(models.AbstractModel):
    _name = 'report.ccl_candidate_recruitment.summary_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('Candidate Summary Report')
        format_heading = workbook.add_format({'text_wrap': True,'font_size': 10, 'align': 'center', 'bold': True, 'border': True,'valign':'vcenter', 'font_name':'cambria'})
        format_heading.set_bg_color('#F4C2C2')
        format_body = workbook.add_format({'text_wrap': True,'font_size': 11, 'align': 'center', 'border': True,'valign':'vcenter', 'font_name':'cambria'})
        format_body_company = workbook.add_format({'text_wrap': True,'font_size': 11, 'align': 'left','valign':'vcenter', 'border': True, 'font_name':'cambria'})
        bold = workbook.add_format({'text_wrap': True,'font_size': 11, 'valign':'vcenter',  'align': 'center', 'bold': True, 'font_name':'cambria'})
        bold_title = workbook.add_format({'text_wrap': True,'font_size': 15, 'valign':'vcenter',  'align': 'center', 'bold': True, 'font_name':'cambria'})

        sheet.merge_range('E5:F5', 'Institute', format_heading)
        sheet.merge_range('G5:H5', 'Result', format_heading)
        sheet.merge_range('I5:J5', 'Result', format_heading)

        sheet.merge_range('A5:A6', 'SI', format_heading)
        sheet.merge_range('B5:B6', 'Name', format_heading)
        sheet.merge_range('C5:C6', 'Mobile', format_heading)
        sheet.merge_range('D5:D6', 'Subject', format_heading)
        sheet.write(5, 4, 'Graduation', format_heading)
        sheet.write(5, 5, 'Post Graduation', format_heading)
        sheet.write(5, 6, 'SSC', format_heading)
        sheet.write(5, 7, 'HSC', format_heading)
        sheet.write(5, 8, 'Graduation', format_heading)
        sheet.write(5, 9, 'Post Graduation', format_heading)
        sheet.merge_range('K5:K6', 'Company Name', format_heading)
        sheet.merge_range('L5:L6', 'Designation', format_heading)
        sheet.merge_range('M5:M6', 'Duration', format_heading)
        sheet.merge_range('N5:N6', 'Total Exp.', format_heading)
        sheet.merge_range('O5:O6', 'Stage', format_heading)
        sheet.merge_range('P5:P6', 'Remarks', format_heading)

        sheet.merge_range('A1:P2', 'Healthcare Pharmaceuticals Limited', bold_title)
        sheet.merge_range('A3:P4', "Candidate Summary Report\n" + data.get('department') +
                          ", " + data.get('job'), bold)

        sheet.set_column(1, 1, 15)
        sheet.set_column(6, 9, 13)
        sheet.set_column(0, 0, 5)
        sheet.set_column(2, 5, 15)
        sheet.set_column(10, 13, 20)
        sheet.set_row(0, 20)
        sheet.set_row(3, 20)
        sheet.set_row(4, 20)

        department_id = data.get('department_id')
        job_id = data.get('job_id')
        stage_id = data.get('stage_id')
        sql_query = f"""
                 SELECT
              applicant.partner_name         as name,
              applicant.sl_code              as sl_code,
              applicant.partner_phone        as mobile,
              applicant.ssc                  as ssc,
              applicant.hsc                  as hsc,
              applicant.grad                 as grad,
              applicant.post_grad            as post_grad,
              applicant.grad_university      as grad_university,
              applicant.post_grad_university as post_grad_university,
              applicant.subject              as subject,
              applicant.experience           as exp,
              applicant.company_name         as company,
              applicant.company_designation  as designation,
              applicant.experience_list      as exp_list,
              stage.name            as stage_name


            from
              hr_applicant as applicant
            JOIN
              hr_recruitment_stage as stage on applicant.stage_id = stage.id


            WHERE
              (applicant.job_id = '%s'
              AND
              applicant.department_id = '%s')
              
              AND 
              applicant.stage_id = '%s'

            Group by
              applicant.partner_name,
              applicant.sl_code,
              applicant.partner_phone,
              applicant.ssc,
              applicant.hsc,
              applicant.grad,
              applicant.post_grad,
              applicant.grad_university,
              applicant.post_grad_university,
              applicant.subject,
              applicant.experience,
              applicant.company_name,
              applicant.company_designation,
              applicant.experience_list,
              stage.name

            Order BY
              applicant.sl_code;

                """ % (job_id, department_id, stage_id)

        print(sql_query)

        self.env.cr.execute(sql_query)
        query_data = self.env.cr.fetchall()
        print(query_data)
        rows = 6
        serial = 1
        for item in (query_data):
            company_name = ''
            company_designation = ''
            duration = ''
            total_ex = 0.0
            if item[11]:
                x = item[11].split(',')
                company_name = ''
                com_serial = 1
                for val in x:
                    company_name += str(com_serial) + "." + val + '\n'
                    com_serial += 1
                print("========Company Name==========")
                print(company_name)
            if item[12]:
                x = item[12].split(',')
                company_designation = ''
                desig_serial = 1
                for val in x:
                    company_designation += str(desig_serial) + "." + val + '\n'
                    desig_serial += 1
            if item[13]:
                x = item[13].split('|')
                duration = ''
                desig_serial = 1
                print(x)
                for val in x:
                    if val:
                        duration += str(desig_serial) + ". " + val + ' years\n'
                        desig_serial += 1

            sheet.set_row(rows, 100)
            sheet.write(rows, 0, serial, format_body)
            sheet.write(rows, 1, item[0], format_body)
            sheet.write(rows, 2, item[2], format_body)
            sheet.write(rows, 3, item[9], format_body)
            sheet.write(rows, 4, item[7], format_body)
            sheet.write(rows, 5, item[8], format_body)
            sheet.write(rows, 6, item[3], format_body)
            sheet.write(rows, 7, item[4], format_body)
            sheet.write(rows, 8, item[5], format_body)
            sheet.write(rows, 9, item[6], format_body)
            sheet.write(rows, 10, company_name, format_body_company)
            sheet.write(rows, 11, company_designation, format_body_company)
            sheet.write(rows, 12, duration, format_body_company)
            sheet.write(rows, 13, item[10], format_body)
            sheet.write(rows, 14, item[14], format_body)
            print(item)
            print(item[14])
            rows += 1
            serial += 1
