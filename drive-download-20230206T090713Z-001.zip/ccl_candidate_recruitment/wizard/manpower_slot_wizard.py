from odoo import fields, api, models


class ManpowerApprovalDetails(models.TransientModel):
    _name = 'manpower.approval.details.report.wizard'

    from_date = fields.Date(string='From Date')
    to_date = fields.Date(string='To Date')
    unit = fields.Many2one('business.unit', string='Business Unit', required=True)

    def generate_approval_details_report(self):
        data = {
            'from_date': self.from_date,
            'to_date': self.to_date,
            'unit_id': self.unit.id,
            'unit': self.unit.name,
        }
        return self.env.ref('ccl_candidate_recruitment.action_manpower_approval_details_report').report_action(self, data=data)


class ReturnXlsxReport(models.AbstractModel):
    _name = 'report.ccl_candidate_recruitment.manpower_approval_details_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('Manpower Summary Report Excel')

        from_date = data.get('from_date')
        to_date = data.get('to_date')
        unit_id = data.get('unit_id')
        unit = data.get('unit')
        format_heading = workbook.add_format({'font_size': 12, 'align': 'center', 'valign': 'center', 'bold': True, 'bg_color': 'yellow'})
        format_body = workbook.add_format({'font_size': 12, 'align': 'left', 'text_wrap': True})
        sheet.freeze_panes(0, 1)
        sheet.freeze_panes(0, 2)
        sheet.freeze_panes(0, 3)
        summary = self.env['manpower.summary'].search([('business_unit', '=', unit_id),
                                                       ('planning_year', '>=', from_date),
                                                       ('planning_year', '<=', to_date)])
        sheet.write(1, 0, "Business Unit", format_heading)
        sheet.write(1, 1, "Department", format_heading)
        sheet.write(1, 2, "Section", format_heading)
        head = 3
        for i in range(0, len(summary)):
            sheet.write(1, head, "Management", format_heading)
            sheet.write(1, head + 1, "Non Management", format_heading)
            sheet.write(1, head + 2, "Approved Total", format_heading)
            sheet.write(1, head + 3, "Approved Date", format_heading)
            head += 4
        sheet.write(1, head, "Total", format_heading)

        sheet.set_column(0, 2, 15)
        sheet.set_column(2, 15, 10)
        # sheet.set_column(1, 1, 20)

        sheet.write('A3', unit, format_body)
        departments = self.env['hr.department'].search([('business_unit', '=', unit_id)])
        row_sec = 2
        row_dept = 3
        row_dept_end = 3
        for dept in departments:
            sections = self.env['hr.section'].search([('department_id', '=', dept.id)])
            sec_count = 0
            for sec in sections:
                sheet.write(row_sec, 2, sec.name, format_body)
                total_col = 3
                total_amount = 0
                for sum in summary:
                    for line in sum.manpower_lines:
                        if line.section == sec:
                            sheet.write(row_sec, total_col, line.am_mgt, format_body)
                            sheet.write(row_sec, total_col + 1, line.am_non_mgt, format_body)
                            sheet.write(row_sec, total_col + 2, line.am_total, format_body)
                            total_amount += line.am_total
                            print('planning year', sum.planning_year)
                            sheet.write(row_sec, total_col + 3, sum.planning_year.strftime("%d-%m-%Y"), format_body)
                    total_col += 4
                sheet.write(row_sec, total_col, total_amount, format_body)

                row_sec += 1
                sec_count += 1
            if sec_count > 1:
                row_dept_end += sec_count -1

            if row_dept == row_dept_end:
                sheet.write(f'B{row_dept}:B{row_dept_end}', dept.name, format_body)
            else:
                sheet.merge_range(f'B{row_dept}:B{row_dept_end}', dept.name, format_body)
            if sec_count > 1:
                row_dept += sec_count
            else:
                row_dept += 1
            row_dept_end += 1



