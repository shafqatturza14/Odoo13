import re

from odoo import fields, models, api
from datetime import datetime, timedelta, date, time
from pytz import timezone


class CandidateWrittenTest(models.TransientModel):
    _name = 'candidate.written.test.interview.wizard'
    _description = 'Written Test Interview  Wizard'

    department_id = fields.Many2one('hr.department', string="Department", required=True)
    job_id = fields.Many2one('hr.job', string='Designation', required=True)

    def generate_attendance_report(self):
        department = self.department_id
        job = self.job_id
        datas = []

        sql_query = f"""
                  SELECT
                      applicant.partner_name         as cname,
                      applicant.sl_code              as sl_code,
                      applicant.partner_phone       as mobile,
                      applicant.ssc                  as ssc,
                      applicant.hsc                  as hsc,
                      applicant.grad                 as grad,
                      applicant.post_grad            as post_grad,
                      applicant.grad_university      as grad_university,
                      applicant.post_grad_university as post_grad_university,
                      applicant.subject              as subject,
                      applicant.experience           as exp,
                      test.hr_id                     as hr_id,
                      test.name                      as candidate,
                      test.parta                     as parta,
                      test.partb                     as partb,
                      test.partc                     as partc,
                      test.total                     as total,
                      test.percentage                as percentage,
                      interview.interview_schedule   as interview_schedule

                from
                  hr_applicant as applicant
                JOIN 
                    hr_recruitment_stage as stages on stages.id = applicant.stage_id
                JOIN
                    written_test_result_line as test on applicant.id = test.hr_id
                JOIN 
                    candidate_interview_line as interview on test.hr_id = interview.hr_id
                

                WHERE 
                  (applicant.job_id = {job.id}
                AND
                  applicant.department_id = {department.id})
               AND
                 stages.sequence = 1


                Group by
                      cname,
                      sl_code,
                      mobile,
                      ssc,
                      hsc,
                      grad,
                      post_grad,
                      grad_university,
                      post_grad_university,
                      subject,
                      exp,
                      candidate,
                      parta,
                      partb,
                      partc,
                      total,
                      test.hr_id,
                      percentage,
                      interview.interview_schedule

                Order BY
                  test.total desc
                ;                     
                """
        print(sql_query)
        self.env.cr.execute(sql_query)
        attendances = self.env.cr.fetchall()
        print(attendances)
        final_mark = -1
        sl = 1
        merit_no = 0
        for rec in attendances:
            if final_mark == -1 or final_mark != rec[16]:
                merit_no += 1
            time_fix = datetime.now()
            if rec[18]:
                time_fix = rec[18] + timedelta(hours=6)
            datas.append({
                'sl_no': sl,
                'merit_no': merit_no,
                'name': rec[0],
                'sl_code': rec[1],
                'mobile': rec[2],
                'ssc': rec[3],
                'hsc': rec[4],
                'grad': rec[5],
                'post_grad': rec[6],
                'grad_university': rec[7],
                'post_grad_university': rec[8],
                'subject': rec[9],
                'exp': "{0:.2f}".format(rec[10]) if rec[10] else '',
                'pa': rec[13],
                'pb': rec[14],
                'pc': rec[15],
                'total': rec[16],
                'percentage': rec[17],
                'interview_schedule': (time_fix.strftime('%B %d,%Y\n%H %M'))
            })
            final_mark = rec[16]
            sl += 1

        res = {
            'attendances': datas,
            'department': self.department_id.name,
            'job': self.job_id.name,
        }
        print(res)
        data = {
            'form': res,
        }
        return self.env.ref('ccl_candidate_recruitment.report_candidate_test_interview').report_action([], data=data)
