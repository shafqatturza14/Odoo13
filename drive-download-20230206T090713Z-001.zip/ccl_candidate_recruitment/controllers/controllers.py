# -*- coding: utf-8 -*-
# from odoo import http


# class CclCandidateRecruitment(http.Controller):
#     @http.route('/ccl_candidate_recruitment/ccl_candidate_recruitment/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/ccl_candidate_recruitment/ccl_candidate_recruitment/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('ccl_candidate_recruitment.listing', {
#             'root': '/ccl_candidate_recruitment/ccl_candidate_recruitment',
#             'objects': http.request.env['ccl_candidate_recruitment.ccl_candidate_recruitment'].search([]),
#         })

#     @http.route('/ccl_candidate_recruitment/ccl_candidate_recruitment/objects/<model("ccl_candidate_recruitment.ccl_candidate_recruitment"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('ccl_candidate_recruitment.object', {
#             'object': obj
#         })
