from odoo import fields, models, api


class PreBoardingChecklist(models.Model):
    _name = 'pre.boarding.list'
    _description = 'Description'
    _rec_name = 'content'

    content = fields.Char(default='Personal File Contents')
    user_id = fields.Many2one('res.users', string="Human Resource Department", readonly=True, default=lambda self: self.env.user)

    employee = fields.Many2one('hr.applicant', string="Employee")

    document_1_remarks = fields.Boolean('1.Joining Report')
    document_2_remarks = fields.Boolean('2.Appointment Letter')
    document_3_remarks = fields.Boolean('3.Acceptance / Clearence Letter( For Experience Candidates)')
    document_4_remarks = fields.Boolean('4.CV with written Exam & Interview Assessment Form')
    document_5_remarks = fields.Boolean('5.Photocopies of all relevant Certificates')
    document_6_remarks = fields.Boolean('6.Personal Information Form')
    document_7_remarks = fields.Boolean('7.Nominee Form')
    document_8_remarks = fields.Boolean('8.References Form')
    document_9_remarks = fields.Boolean('9.NID (For Age Verification & Identity)')
    document_10_remarks = fields.Boolean('10.Medical Report')
    document_11_remarks = fields.Boolean('11.PF Declaration')
    document_12_remarks = fields.Boolean('12.Nomination for PF')

    @api.onchange('employee')
    def onboarding_tagging(self):
        joining_report = self.env['employee.joining.report'].search([('employee_id', '=',  self.employee.id)])
        employee_nominee = self.env['employee.nominee'].search([('employee_id', '=',  self.employee.id)])
        employee_nominee_sales = self.env['employee.nominee.for.sales'].search([('employee_id', '=',  self.employee.id)])
        employee_reference = self.env['employee.reference'].search([('employee_id', '=',  self.employee.id)])
        employee_medical_report = self.env['employee.medical.report'].search([('employee_id', '=',  self.employee.id)])
        pf_declaration = self.env['employee.pf.declaration'].search([('employee_id', '=',  self.employee.id)])
        nomination_for_pf = self.env['employee.pf.nomination'].search([('employee_id', '=',  self.employee.id)])
        if joining_report:
            self.document_1_remarks = True
        else:
            self.document_1_remarks = False

        if employee_nominee or employee_nominee_sales:
            self.document_7_remarks = True
        else:
            self.document_7_remarks = False

        if employee_reference:
            self.document_8_remarks = True
        else:
            self.document_8_remarks = False

        if employee_medical_report:
            self.document_10_remarks = True
        else:
            self.document_10_remarks = False

        if pf_declaration:
            self.document_11_remarks = True
        else:
            self.document_11_remarks = False

        if nomination_for_pf:
            self.document_12_remarks = True
        else:
            self.document_12_remarks = False


