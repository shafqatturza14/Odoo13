# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import date


class CandidateInterview(models.Model):
    _name = 'candidate.interview'
    _rec_name = 'department'

    department = fields.Many2one('hr.department', 'Department', ondelete='cascade')
    section = fields.Many2one('hr.job', 'Designation', ondelete='cascade')
    pass_mark = fields.Float('Pass Mark (%)')
    can_lines = fields.One2many('candidate.interview.line', 'test_id', string="Template Line")

    @api.onchange('section', 'department', 'pass_mark')
    def candidate_fetch(self):
        if self.section and self.department:
            candidate = self.env['candidate.written.test'].search([('section', '=', self.section.id), ('department', '=', self.department.id)])
            for rec in self:
                lines = [(5, 0, 0)]
                for line in candidate.test_lines:
                    if line.percentage >= self.pass_mark:
                        val = {
                            'hr_id': line.hr_id,
                            'name': line.name,
                            'mark': line.percentage,
                            'mark_sign': line.percentage_with_sign,
                        }
                        lines.append((0, 0, val))
                        print(val)
                print("================Lines")
                print(lines)
                rec.can_lines = lines
                print(rec.can_lines)

class CandidateInterviewLines(models.Model):
    _name = 'candidate.interview.line'
    _description = "Template Line"

    test_id = fields.Many2one('candidate.interview', ondelete='cascade')
    hr_id = fields.Integer('Application Name', store=True)
    name = fields.Char('Name', store=True)
    mark = fields.Float('Percentage Mark')
    mark_sign = fields.Char('Percentage Mark(%)')
    interview_schedule = fields.Datetime('Time', default=date.today())

