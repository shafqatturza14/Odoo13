# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class HRDepartment(models.Model):
    _inherit = 'hr.department'

    dept_ab_code = fields.Char('Abbreviation Code', required=False)
    dept_code = fields.Char('SAP Code', required=True)
    dept_hd = fields.Many2one('hpl.employee', 'Department Head', ondelete='cascade')
