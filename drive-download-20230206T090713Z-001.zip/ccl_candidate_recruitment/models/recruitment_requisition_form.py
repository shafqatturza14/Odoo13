# -*- coding: utf-8 -*-

from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta
from odoo.http import request


class HrRecruitmentRequisition(models.Model):
    _name = 'hr.recruitment.requisition'
    _description = "Recruitment Requisition"
    _rec_name = "effective_date"

    effective_date = fields.Date('Effective Date')
    department_id = fields.Many2one('hr.department', string="Department", required=True, ondelete='cascade')
    user_id = fields.Many2one('res.users', string="Proposed By", readonly=True, default=lambda self: self.env.user)
    approve_id = fields.Many2one('res.users', string="Approved By", readonly=True)
    requisition_received_date = fields.Date('Requisition Received Date')
    requisition_received_by = fields.Many2one('res.users', string="Requisition Received By", readonly=True)
    existing_employee = fields.Integer('Existing Employee')
    approve_manpower = fields.Integer('Approved Manpower')
    state = fields.Selection(
        [('draft', 'Draft'),
         ('sent_to_hod', 'Department Head'),
         ('hod_approved', 'Department Head Approved'),
         ('sent_to_hr', 'HR'),
         ('hr_approved', 'HR Received'),
         ('hr_reject', 'HR Reject'),
         ], string='State',
        default='draft')

    mode_of_requirement = fields.Selection(
        [
            ('hr_cv_bank', 'HR CV Bank'),
            ('job_advertisement', 'Job Advertisement'),
            ('employee_referrel', 'Employee Referrel')
        ], string='Mode of Requirement',
        default='hr_cv_bank'
    )

    line_items = fields.One2many('hr.recruitment.requisition.lines', 'req_line_id', string='Requisitions')

    dept_head_id = fields.Many2one('hpl.employee', 'Department Head')
    hr_id = fields.Many2one('hpl.employee', 'Responsible HR')

    @api.onchange('line_items')
    def candidate_fetch(self):
            for rec in  self:
                rec.line_items.line_department_id = rec.department_id

    def action_send_hod(self):
        return self.write({
            'state': 'sent_to_hod',
        })

    def action_hod_confirm(self):
        self.approve_id = self.env.user
        return self.write({
            'state': 'hod_approved',
        })

    def action_send_to_hr(self):
        return self.write({
            'state': 'sent_to_hr',
        })


    def action_hr_confirm(self):
        self.requisition_received_by = self.env.user
        return self.write({
            'state': 'hr_approved',
        })

    def action_hr_reject(self):
        self.requisition_received_by = self.env.user
        return self.write({
            'state': 'hr_reject',
        })


class HrRecruitmentRequisitionLines(models.Model):
    _name = 'hr.recruitment.requisition.lines'
    _description = "Recruitment Requisition Line"

    req_line_id = fields.Many2one('hr.recruitment.requisition')
    line_department_id = fields.Many2one('hr.department')
    work_area = fields.Many2one('business.unit', string="Worked Area/BU",ondelete='cascade')
    section = fields.Many2one('hr.section', string="Section",ondelete='cascade')
    exist_employee = fields.Integer('Existing Employee', default=0, store=True)
    app_emp = fields.Integer('Approved Manpower', default=0, store=True)
    job_id = fields.Char(string="Requested Position")
    vacancy = fields.Integer(string="No. of Vacancy", store=True, compute='_compute_vacancy')
    education = fields.Char(string="Education")
    skill = fields.Char(string="Skill")
    date_expected = fields.Date(string="Date of Requirement", default=datetime.now().date())
    remarks = fields.Char(string="Remarks")

    @api.onchange('section')
    def existing_employee(self):
        for rec in self:
            existing = self.env['hpl.employee'].search_count([('section', '=', rec.section.id), ('employee_sub_group.code', '=', '01')])
            if existing > 0:
                rec.exist_employee = existing
            else:
                rec.exist_employee = 0
            rec.app_emp = 0
            approved = self.env['manpower.summary.lines'].search([('section', '=', rec.section.id)])
            for val in approved:
                rec.app_emp += val.am_mgt

    @api.depends('exist_employee', 'app_emp')
    def _compute_vacancy(self):
        for rec in self:
            if rec.app_emp or rec.exist_employee:
                rec.vacancy = rec.app_emp - rec.exist_employee




