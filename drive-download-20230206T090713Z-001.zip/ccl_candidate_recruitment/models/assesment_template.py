# -*- coding: utf-8 -*-

from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta
from odoo.http import request


class AssessmentTemplate(models.Model):
    _name = 'assessment.template'
    _description = "Assessment Template"

    name = fields.Char('Interview Assessment Template')
    template_lines = fields.One2many('assessment.template.lines', 'line_id', string="Template Line")


class AssessmentTemplateLines(models.Model):
    _name = 'assessment.template.lines'
    _description = "Template Line"

    line_id = fields.Many2one('assessment.template', ondelete='cascade')

    competencies_name = fields.Char('COMPETENCIES')
