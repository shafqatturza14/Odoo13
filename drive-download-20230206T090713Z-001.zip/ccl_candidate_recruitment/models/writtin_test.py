# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class CandidateWrittenTest(models.Model):
    _name = 'candidate.written.test'
    _rec_name = 'department'

    department = fields.Many2one('hr.department', 'Department', ondelete='cascade')
    section = fields.Many2one('hr.job', 'Designation', ondelete='cascade')
    exam_mark = fields.Float('Exam Mark')
    test_lines = fields.One2many('written.test.result.line', 'test_id', string="Template Line")

    @api.onchange('section')
    def candidate_fetch(self):
        candidate = self.env['hr.applicant'].search([('job_id', '=', self.section.id), ('department_id', '=', self.department.id)])
        for rec in self:
            lines = [(5, 0, 0)]
            for line in candidate:
                if line.stage_id.sequence == 1:
                    val = {
                        'hr_id': line.id,
                        'name': line.partner_name,
                    }
                    lines.append((0, 0, val))
                    print(val)
                    print('line ID: ', line.id)
            rec.test_lines = lines
            print(rec.test_lines)


class WrittenTestResultLines(models.Model):
    _name = 'written.test.result.line'
    _description = "Template Line"

    test_id = fields.Many2one('candidate.written.test', ondelete='cascade')
    hr_id = fields.Integer('Application Name', store=True)
    name = fields.Char('Name', store=True)
    parta = fields.Float('Part A')
    partb = fields.Float('Part B')
    partc = fields.Float('Part C')
    total = fields.Float('Total')
    percentage = fields.Float('Result Percentage')
    percentage_with_sign = fields.Char('Result')
    interview_schedule = fields.Datetime('Time')

    @api.depends('hr')
    def _compute_name(self):
        if self.hr:
            self.name = self.hr.partner_name

    @api.onchange('parta', 'partb', 'partc')
    def _compute_total(self):
        for rec in self:
            if rec.parta or rec.partb or rec.partc:
                rec.total = rec.parta + rec.partb + rec.partc
                rec.percentage = round(((rec.total) / (rec.test_id.exam_mark)) * 100.00)
                rec.percentage_with_sign = str(rec.percentage) + '%'
