# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import date


class HRJob(models.Model):
    _inherit = 'hr.job'

    job_ab_code = fields.Char('Job Abbreviation Code', required=True)
    new_candidate = fields.Integer('Expected New Candidate')
    recruitment_start_date = fields.Date(string='Recruitment Start Date')

    @api.model
    def create(self, vals):
        res = super(HRJob, self).create(vals)
        res.recruitment_start_date = date.today()
        return res

    def set_recruit(self):
        for record in self:
            no_of_recruitment = 1 if record.no_of_recruitment == 0 else record.no_of_recruitment
            record.write(
                {'state': 'recruit', 'no_of_recruitment': no_of_recruitment, 'recruitment_start_date': date.today()})
        return True
