# -*- coding: utf-8 -*-

from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta
from odoo.http import request


class ManpowerSummaryReport(models.Model):
    _name = 'manpower.summary'
    _description = "Manpower Summary Details"
    _rec_name = "planning_year"

    planning_year = fields.Date('Planning Year')
    business_unit = fields.Many2one('business.unit', string="Business Unit", required=True, ondelete='cascade')

    manpower_lines = fields.One2many('manpower.summary.lines', 'manpower_line_id', string='Manpower Details')

    @api.onchange('manpower_lines')
    def _tag_bu(self):
        self.manpower_lines.business_unit_line = self.business_unit


class ManpowerSummaryLines(models.Model):
    _name = 'manpower.summary.lines'
    _description = "Manpower Summary Line"

    manpower_line_id = fields.Many2one('manpower.summary', ondelete='cascade')
    business_unit_line = fields.Many2one('business.unit', string="Business Unit Line", ondelete='cascade')

    # department = felds.Many2one('', string='Department'
    department = fields.Many2one('hr.department', ondelete='cascade', string='Department')
    department_name = fields.Char(string='Department Name', store=True)
    section = fields.Many2one('hr.section', ondelete='cascade', string='Section')
    app_mn = fields.Integer('Management')

    am_mgt = fields.Integer(string="Mgt")
    am_non_mgt = fields.Integer(string="Non Mgt", default=0.0)
    am_total = fields.Integer(string="Total")

    em_mn_total = fields.Integer(string="Existing Management Total", store=True)
    per_total = fields.Integer(string="Permanent Total")
    cas_total = fields.Integer(string="Casual Total")
    dl_total = fields.Integer(string="DL Total")
    em_non_total = fields.Integer(string="Existing Non Management Total")
    em_total = fields.Integer(string="Existing Total")

    mgt_bm_total = fields.Integer(string="Balance Mgt")
    non_mgt_bm_total = fields.Integer(string="Balance Non Management")
    grand = fields.Integer(string="Grand Total")

    public = fields.Integer(string="Public")
    private = fields.Integer(string="Private")
    national = fields.Integer(string="National")

    replace = fields.Integer(string='Replace')
    neww = fields.Integer(string='New')

    @api.onchange('department')
    def _compute_department_name(self):
        for rec in self:
            rec.department_name = rec.department.name

    @api.onchange('am_non_mgt', 'am_mgt')
    def _compute_total(self):
        for rec in self:
            rec.am_total = rec.am_mgt + rec.am_non_mgt


            # replace = 0
            # for val in employee_mn_sub_group:
            #     replace = self.env['exit.request'].search_count(
            #         [('department_id', '=', rec.department.id), ('emp_group', '=', val.id)])
            # rec.replace = replace
