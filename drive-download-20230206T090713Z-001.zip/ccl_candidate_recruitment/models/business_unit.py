# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class BusinessUnit(models.Model):
    _name = 'business.unit'
    _description = 'Business Unit'
    _rec_name = 'name'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Business Unit', required=True)
