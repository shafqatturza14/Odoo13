# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import datetime

class HrApplicantCode(models.Model):
    _inherit = 'hr.applicant'

    sl_code = fields.Char(string="Candidate ID", required=False, readonly=False, store=True,
                          default="New")
    applicant_code = fields.Char(string="Applicant Code", required=False,store=True, default="New", compute='_initial_code')

    signature = fields.Char('Signature', default="")

    @api.onchange('stage_id')
    def sl_id_creation(self):
        if self.job_id.id:
            jobs = self.env['hr.applicant'].search_count([('job_id', '=', self.job_id.id), ('stage_id.sequence', '=', self.stage_id.sequence)])
            company_name = "HPL-"
            designation = ''
            for rec in self:
                if rec.job_id:
                    designation = rec.job_id.job_ab_code
            currentMonth = datetime.now().month
            currentYear = datetime.now().year
            for val in self:
                if val.stage_id.sequence == 1 and val.sl_code == 'New':
                    if company_name and designation and currentMonth and currentYear:
                        sl_code = company_name + designation + "-" + str(currentYear) + "-" + \
                                   str(currentMonth)+'-' + str(jobs+1)
                        val.sl_code = sl_code

                if val.stage_id.sequence == 2 and val.sl_code == 'New':
                    sl_code = str(jobs+1)
                    val.sl_code = sl_code

    @api.depends('stage_id')
    def _initial_code(self):
        for rec in self:
            company_name = "HPL-"
            designation = ''
            for rec in self:
                if rec.job_id:
                    designation = rec.job_id.job_ab_code
            currentMonth = datetime.now().month
            currentYear = datetime.now().year
            for val in self:
                if val.applicant_code == 'New':
                    if company_name and designation and currentMonth and currentYear:
                        applicant_code ='App-'+ company_name + designation + "-" + str(currentYear) + "-" + \
                                  str(currentMonth) + '-' + str(self.env['ir.sequence'].next_by_code('candidate.code'))
                        val.applicant_code = applicant_code


                        applicant = self.env['hr.applicant'].browse(rec.id)
                        print('applicant:', applicant)
                        template_id = self.env.ref('ccl_candidate_recruitment.applicant_letter_email_template').id
                        template = self.env['mail.template'].browse(template_id)
                        template['email_to'] = rec.email_from
                        # template['email_from'] = self.user_id.email_formatted
                        template.send_mail(applicant.id, force_send=True)
