# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class InheritDepartment(models.Model):
    _inherit = 'hr.department'
    _description = 'Department'

    business_unit = fields.Many2one('business.unit', string='Business Unit', required=True)
