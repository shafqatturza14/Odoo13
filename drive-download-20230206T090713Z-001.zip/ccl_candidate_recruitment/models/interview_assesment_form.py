# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class InterviewAssessmentForm(models.Model):
    _name = 'interview.assessment.form'
    _rec_name = 'effective_date'

    effective_date = fields.Date('Interview Date', required=False)
    name = fields.Many2one('hr.applicant', required=False, ondelete='cascade')
    position = fields.Char(string='Position', ondelete='cascade')
    sl_no = fields.Char(string='SL.No', required=False)

    strength = fields.Char(string='Strength for this Job:')
    doubt = fields.Char(string='Deficiency/Doubt on any Aspect:')
    remarks = fields.Char(string='Remarks/Commitment:')

    present_salary = fields.Char(string='Present Salary')
    expected_salary = fields.Char(string='Expected Salary')
    notice_period = fields.Char(string='Notice Period')

    template_id = fields.Many2one('assessment.template', required=False, string='Assessment Template')
    line_items = fields.One2many('interview.assessment.form.line', 'interview_form_id', string="Template Line")

    recommendation = fields.Selection(
        [('suitable_for_employment', 'Suitable for Employment'),

         ('future_employment', 'On Hold for Future Employment'),
         ('not_suitable', 'Not Suitable'),
         ], string='Recommendation:',
        default='')

    sum_weight = fields.Char('Weight Sum', store=True, compute='_compute_sum_weight')
    sum_total_weight = fields.Char('Total Weight', default='0.0', compute='_compute_weight_sum', store=True)

    @api.onchange('name')
    def _compute_position(self):
        if self.name:
            self.position = self.name.job_id.name

    @api.depends('line_items.weight')
    def _compute_sum_weight(self):
        temp = 0
        for rec in self.line_items:
            temp += float(rec.weight)
        self.sum_weight = temp

    @api.depends('line_items.total_weight')
    def _compute_weight_sum(self):
        temp = 0
        for rec in self.line_items:
            temp += float(rec.total_weight)
        self.sum_total_weight = str(temp)

    @api.onchange('template_id')
    def onchange_temp_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.template_id.template_lines:
                val = {
                    'question_id': line.line_id.id,
                    'competences': line.competencies_name,
                }
                lines.append((0, 0, val))
            rec.line_items = lines


class InterviewAssessmentFormLine(models.Model):
    _name = 'interview.assessment.form.line'
    _description = 'Competences Line'

    interview_form_id = fields.Many2one('interview.assessment.form')
    question_id = fields.Many2one('assessment.template')

    competences = fields.Char('COMPETENCIES')
    weight = fields.Float('Weight', required=True)
    excellent = fields.Char('Excellent(9-10)', required=False, defaul='')
    very_good = fields.Char('Very Good(7-8)', required=False)
    good = fields.Char('Good(5-6)', required=False)
    average = fields.Char('Average(3-4)', required=False)
    poor = fields.Char('Poor(1-2)', required=False)
    total_weight = fields.Float('Total(Weight*Rating)')

    @api.onchange('weight', 'excellent', 'very_good', 'good', 'average', 'poor')
    def _compute_total_weight(self):
        excellent, very_good, good, average, poor = 0.00, 0.00, 0.00, 0.00, 0.00
        if self.excellent:
            excellent = float(self.excellent)
        if self.very_good:
            very_good = float(self.very_good)
        if self.good:
            good = float(self.good)
        if self.average:
            average = float(self.average)
        if self.poor:
            poor = float(self.poor)

        self.total_weight = (excellent + very_good + good + average + poor) * float(self.weight)
