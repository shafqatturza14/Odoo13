# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class NewEmployee(models.Model):
    _name = 'new.employee'
    _description = 'New Employee'
    _rec_name = 'applicant'

    applicant = fields.Many2one('hr.applicant', 'Confirm Applicant', domain=[('stage_id', '=', 4)])
    exit_values = fields.Many2one('exit.request', 'Replacement Available',  domain=[('is_replacement_available', '=', True)])
    exit_values_emergency = fields.Many2one('employee.emergency.exit', 'Replacement Available(Emergency)',  domain=[('is_replacement_available', '=', True)])

    @api.onchange('exit_values')
    def exit_value_change(self):
        self.exit_values.is_replacement_available = False

    @api.onchange('exit_values_emergency')
    def exit_value_change(self):
        self.exit_values_emergency.is_replacement_available = False


