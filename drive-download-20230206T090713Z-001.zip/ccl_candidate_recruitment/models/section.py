# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class Section(models.Model):
    _name = 'hr.section'
    _description = 'Section Name'

    department_id = fields.Many2one('hr.department', string='Department')
    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Section Name', required=True)
