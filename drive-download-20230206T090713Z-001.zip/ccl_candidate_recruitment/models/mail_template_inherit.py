# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class HRJob(models.Model):
    _inherit = 'hr.job'

    job_ab_code = fields.Char('Job Abbreviation Code', required=True)
    new_candidate = fields.Integer('Expected New Candidate')
