# -*- coding: utf-8 -*-

from . import recruitment_requisition_form
from . import pre_boarding_checklist
from . import assesment_template
from . import interview_assesment_form
from . import manpower_summary_report
from . import applicant_sl_code
from . import section
from . import business_unit
# from . import company_details
from . import writtin_test
from . import business_unit
from . import department
from . import interview_schedule
from . import hr_job_inherit
from . import hr_department_inherit
from . import new_employee
