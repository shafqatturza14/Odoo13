from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class FinalSettlementPFTemplate(models.Model):
    _name = 'final.settlement.pf.template'
    _description = 'Final Settlement PF Template'

    name = fields.Char(string='Name', required=True)
    template_lines = fields.One2many('final.settlement.pf.template.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):

        length = len(vals['template_lines'])

        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['particular_id']}")
            if not vals['template_lines'][i][2]['particular_id']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(FinalSettlementPFTemplate, self).create(vals)

        return rec


class FinalSettlementPFTemplateLine(models.Model):
    _name = 'final.settlement.pf.template.line'
    _description = 'Template Line'

    template_id = fields.Many2one('final.settlement.pf.template')
    particular_id = fields.Many2one('final.settlement.pf.account', string="Particular")
