from odoo import fields, models, api


class FinalSettlementSummary(models.Model):
    _name = 'final.settlement.summary'
    _description = 'Final Settlement Summary'
    _rec_name = 'summary_particular'

    summary_particular = fields.Char(string='Particular', required=True)
