from odoo import fields, models, api


class InterviewRateCriteria(models.Model):
    _name = 'interview.rate.criteria'
    _description = 'Criteria'
    _rec_name = 'criteria'

    criteria = fields.Char(string='Criteria', required=True)
