from odoo import fields, models, api
from datetime import date, datetime, timedelta


class ExitCustodyLine(models.Model):
    _name = 'exit.custody.line'
    _description = 'Description'

    exit_request_id = fields.Many2one('exit.request')

    purpose = fields.Char(string='Reason', track_visibility='always', required=True, help="Reason"
                          )
    custody_name = fields.Many2one('custody.property', string='Property', required=True,
                                   help="Property name")
    return_date = fields.Date(string='Return Date', track_visibility='always', readonly=True,
                              help="Return date")

    date_request = fields.Date(string='Requested Date', required=True, track_visibility='always', readonly=True,
                               help="Requested date", default=datetime.now().strftime('%Y-%m-%d'))

    activity = fields.Boolean(string='Check')

    @api.model
    def check_exit_custody_lines(self, selected_ids):
        orderline_sudo = self.env['exit.custody.line'].sudo()
        order_lines = orderline_sudo.browse(selected_ids)
        print('my custody lines', order_lines)

        # for line in order_lines:
        #     line.unlink()
        return True
