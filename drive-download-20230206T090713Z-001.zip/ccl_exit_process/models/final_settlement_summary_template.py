from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class FinalSettlementSummaryTemplate(models.Model):
    _name = 'final.settlement.summary.template'
    _description = 'Final Settlement Summary Template'

    name = fields.Char(string='Name', required=True)
    template_lines = fields.One2many('final.settlement.summary.template.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):

        length = len(vals['template_lines'])

        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['particular_id']}")
            if not vals['template_lines'][i][2]['particular_id']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(FinalSettlementSummaryTemplate, self).create(vals)

        return rec


class FinalSettlementSummaryTemplateLine(models.Model):
    _name = 'final.settlement.summary.template.line'
    _description = 'Template Line'

    template_id = fields.Many2one('final.settlement.summary.template')
    particular_id = fields.Many2one('final.settlement.summary', string="Particular")
