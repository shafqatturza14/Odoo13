from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import date, datetime, timedelta
from odoo.http import request


class ExitInterview(models.Model):
    _name = 'exit.interview'
    _description = 'Exit Interview'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    # employee_id = fields.Many2one('hr.employee', required=True, string="Employee",
    #                               default=lambda self: self.env.user.employee_id)
    employee_id = fields.Many2one('hpl.employee', required=True, string="Employee")
    employee_code = fields.Char(string='Employee ID', required=True,)
    job_id = fields.Char('Designation')
    department_id = fields.Many2one('hr.department', 'Department')
    emp_joining_date = fields.Date('Date of Joining')
    resignation_date = fields.Date('Date of Leaving')
    employee_salary = fields.Char(string='Current Salary (gross)')
    reason = fields.Char(string='Reason')
    Category = fields.Char(string='Category')
    replaced_by = fields.Char(string='Replaced By')
    job_duration = fields.Char(string='Length of Employment at HPL', default="0.0 -Yr(s)", compute='_compute_job_duration')
    show_part_one = fields.Boolean('Is Show part 1?', default=True)
    show_part_two = fields.Boolean('Is Show part 2?', default=False)
    show_part_three = fields.Boolean('Is Show part 3?', default=False)
    can_explained_job_responsibility = fields.Selection([('yes', 'Yes'),
                               ('no', 'No'),
                               ('uncertain', 'Uncertain')
                               ], 'Explained')
    responsibility_explaination = fields.Text(string='Comments')

    job_opportunity = fields.Boolean('1.Better job opportunity')
    work_type = fields.Boolean('2. Type of work')
    rate_pay = fields.Boolean('3. Rate of pay')
    self_employment = fields.Boolean('4. Self-employment ')
    return_studies = fields.Boolean('5. Return to studies')
    supervision = fields.Boolean('6. Supervision')
    commuting_distance = fields.Boolean('7. Commuting distance')
    un_encouraging = fields.Boolean('8. Advancement un-encouraging')
    job_pressure = fields.Boolean('9. Excessive job pressure')
    working_conditions = fields.Boolean('10. Working conditions')
    travel_reasons = fields.Boolean('11. Travel reasons')
    inadequate_training = fields.Boolean('12. Inadequate training')
    family_circumstances = fields.Boolean('13. Family circumstances')
    illness = fields.Boolean('14. Illness or physical condition')
    other_specify = fields.Char('15. Other (Please specify)')

    about_leaving = fields.Text(string='About leaving HPL?')
    resign_intention = fields.Text(string='Intention to resign with your Supervisor?')

    same_type_work = fields.Selection([
                        ('yes', 'Yes'),
                        ('no', 'No')],
                        'In your new job, will you be performing the same type of work?')
    explanation = fields.Text(string='If no, please specify')
    better_future = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')],
        'Better future')
    better_hours = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')],
        'Better hours ')
    higher_pay = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')],
        'Higher pay ')
    interesting_work = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')],
        'More interesting work')

    strenuous_work = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')],
        'Less strenuous work')

    former_job = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')],
        'Return to former trade or job')

    new_position_specify = fields.Text(string='Other (Specify) ')
    like_most_job = fields.Text(string=' What did you like most about your job, department & Company?')
    like_least_job = fields.Text(string='Other (Specify) ')
    contribute_company = fields.Selection([
        ('always', 'Almost always'),
        ('sometimes', 'Sometimes '),
        ('seldom', 'Seldom'),
        ('never ', 'Never'),
        ('know', 'Didn’t know ')],
        '(a) To the Company?')
    contribute_department = fields.Selection([
        ('always', 'Almost always'),
        ('sometimes', 'Sometimes '),
        ('seldom', 'Seldom'),
        ('never ', 'Never'),
        ('know', 'Didn’t know ')],
        ' (b) To your Department?')
    expected_work = fields.Selection([
        ('1', '1. Too much for one person'),
        ('2', '2. Occasionally heavy, but about right most of the time '),
        ('3', '3. Just right, not overworked or under worked'),
        ('4', '4. Not enough did not fully take up time.')],
        '9. Was the amount of work you were expected to do?')

    # find_work = fields.Selection([
    #     ('1', '1. Interesting   '),
    #     ('2', '2. Challenging'),
    #     ('3', '3. Simple  '),
    #     ('4', '4. Uninspiring'),
    #     ('5', '5. Restrictive'),
    #     ('6', '6.  Rewarding')],
    #     ' Did you find your work -')
    interesting = fields.Boolean('1. Interesting')
    challenging = fields.Boolean('2. Challenging')
    simple = fields.Boolean('3. Simple')
    uninspiring = fields.Boolean('4. Uninspiring')
    restrictive = fields.Boolean('5. Restrictive')
    rewarding = fields.Boolean('6. Rewarding')
    prevent_leave = fields.Text(string='11. Could anything has been done to prevent your leaving?')
    return_to_company = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')],
        'For the Company')

    return_to_department = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')],
        'For the same Department')

    same_boss = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No')],
        'For the same Boss')
    return_interesting_comment = fields.Text(string='Comment')
    is_recommend = fields.Selection([
        ('yes', 'Yes'),
        ('perhaps', 'Perhaps'),
        ('no', 'No')],
        '13. Would you recommend Healthcare as a good place to work?')
    recommend_explain = fields.Text(string='Please explain')
    benefited_comment = fields.Text(string='Part 15')
    supervision_guide_comment = fields.Text(string='Part 16')
    other_factor = fields.Text(string='Any Other Factor')
    manufacturing_plan = fields.Text(string='Hr Comment')

    state = fields.Selection(
        [('draft', 'Draft'),
         ('sent_employee', 'Sent To Employee'),
         ('sent_hr', 'Sent To HR'),
         ('confirmed', 'Confirmed'),
         ], string='State',
        default='draft')

    interview_criteria_template_id = fields.Many2one('interview.rate.template', string='Interview Rate Template',
                                                     default=lambda self: self._default_template_id(),required=True)

    exit_interview_rate_template_lines = fields.One2many('exit.interview.rate.template.line', 'exit_interview_rate_id',
                                                         string='Template line')

    def _default_template_id(self):
        template_id = self.env['interview.rate.template'].search([], limit=1)
        return template_id

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.full_name

    @api.onchange('employee_id')
    def onchange_employee_id(self):
        for emp in self:
            print("-------------onchange_employee_id------------")
            emp.employee_code = emp.employee_id.employee_id
            emp.department_id = emp.employee_id.department.id
            emp.emp_joining_date = emp.employee_id.start_date
            emp.job_id = emp.employee_id.position_name
            if emp.employee_id.personal_area:
                if emp.employee_id.personal_area.code == '2000':
                    exists_exit = self.env['exit.request.field.force'].search(
                        [('employee_code', '=', emp.employee_id.employee_id)], limit=1)
                    if exists_exit.resignation_date:
                        emp.resignation_date = exists_exit.resignation_date

                else:
                    exits = self.env['exit.request'].search([('employee_code', '=', emp.employee_id.employee_id)],
                                                            limit=1)
                    if exits.resignation_date:
                        emp.resignation_date = exits.resignation_date

    @api.onchange('interview_criteria_template_id')
    def onchange_interview_criteria_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.interview_criteria_template_id.template_lines:
                val = {
                    'criteria_id': line.criteria_id.id,
                }
                lines.append((0, 0, val))
            rec.exit_interview_rate_template_lines = lines

    @api.depends('emp_joining_date', 'resignation_date')
    def _compute_job_duration(self):
        for settlement in self:
            if settlement.resignation_date:
                if settlement.emp_joining_date:
                    duration_year_round = str(round((
                            abs(settlement.resignation_date - settlement.emp_joining_date).days / 365), 2))
                    duration_yr = duration_year_round + '-Yr(s)'
                    settlement.job_duration = duration_yr
                else:
                    settlement.job_duration = ''
            else:
                settlement.job_duration = ''

    def action_submit_employee(self):
        self.write({
            'state': 'sent_employee',
        })

    def action_show_two(self):
        self.write({
            'show_part_one': False,
            'show_part_two': True,
            'show_part_three': False,
        })

    def action_show_one(self):
        self.write({
            'show_part_one': True,
            'show_part_two': False,
            'show_part_three': False,
        })

    def action_show_three(self):
        self.write({
            'show_part_one': False,
            'show_part_two': False,
            'show_part_three': True,
        })

    def action_submit_to_hr(self):

        self.write({
            'state': 'sent_hr',
        })

    def action_confirm(self):
        self.write({
            'state': 'confirmed',
        })


class ExitInterviewRateTemplateLine(models.Model):
    _name = 'exit.interview.rate.template.line'
    _description = 'Template Line'

    exit_interview_rate_id = fields.Many2one('exit.interview', string="Exit")
    criteria_id = fields.Many2one('interview.rate.criteria', string="Criteria")
    first = fields.Float(string='1')
    second = fields.Float(string='2')
    third = fields.Float(string='3')
    fourth = fields.Float(string='4')
    fifth = fields.Float(string='5')
