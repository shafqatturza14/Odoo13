from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class FieldForceParticularTemplate(models.Model):
    _name = 'field.force.particular.template'
    _description = 'Field Force Particular Template'

    name = fields.Char(string='Name', required=True)

    template_lines = fields.One2many('field.force.particular.template.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):

        length = len(vals['template_lines'])

        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['particulars']}")
            if not vals['template_lines'][i][2]['particulars']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(FieldForceParticularTemplate, self).create(vals)

        return rec


class FieldForceParticularTemplateLine(models.Model):
    _name = 'field.force.particular.template.line'
    _description = 'Template Line'

    template_id = fields.Many2one('field.force.particular.template', 'Template')
    sl = fields.Char(string='SL')
    particulars = fields.Char(string='Particulars', required=True)
