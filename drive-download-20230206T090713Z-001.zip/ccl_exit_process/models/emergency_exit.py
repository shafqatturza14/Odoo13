from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import date, datetime, timedelta
from odoo.http import request


class ExitRequest(models.Model):
    _name = 'employee.emergency.exit'
    _description = 'Emergency Exit'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', store=True,compute='_compute_rec_name')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id)
    employee_id = fields.Many2one('hpl.employee', required=True, string="Employee", readonly=False)

    # user_id = fields.Many2one(related='employee_id.user_id', string='User', readonly=True)

    employee_code = fields.Char(string='Employee ID', readonly=True, store=True, compute='_compute_employee_code')
    job_id = fields.Char('Designation', readonly=True, compute='_compute_employee_job_position')
    department_id = fields.Many2one('hr.department', 'Department', readonly=True, compute='_compute_employee_dept')
    emp_joining_date = fields.Date('Date of Joining', readonly=True, compute='_compute_employee_joining_date')
    supervisor_id = fields.Many2one('hpl.employee', required=True, string="Immediate Supervisor")
    # parent_id = fields.Many2one('hr.employee', 'Supervisor', readonly=True, compute='_compute_employee_manager')

    # last_work_date = fields.Date(string='Last Day of Work', required=True)
    # notice_period_days = fields.Integer(string='Notice Period (Days)', required=True)

    user_id = fields.Many2one('res.users', string='User',
                              default=lambda self: self.env.user, readonly=True)
    # employee_user_id = fields.Many2one('res.users', compute='_compute_employee_user', string='Employee User',
    #                                    readonly=True)
    resignation_date = fields.Date('Effective From', required=True, default=fields.date.today())
    resignation_date_str = fields.Char('Date', compute='_compute_resign_date_formate')

    is_replacement_available = fields.Boolean('Is Replacement Available', default=False)
    clearance_person = fields.Many2many('hpl.employee', string="Clearance Authority")

    # Department

    gmp_document = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    action_plan = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    # gmp_document = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])

    supervisor_others = fields.Boolean(string='Others', default=False)
    other_remarks = fields.Char(string='If Others')
    sup_remark = fields.Text(string='Remarks (If Any)')

    # Plant Admin
    stationeries = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    keys = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    admin_others = fields.Boolean(string='Others')
    admin_other_remarks = fields.Char(string='If Others')
    admin_remark = fields.Text(string='Remarks (If Any)')

    # Hr
    visiting_card = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    id_card = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    brief_case = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    bag = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    exit_interview = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    hr_others = fields.Boolean(string='Others')
    hr_other_remarks = fields.Char(string='If Others')
    hr_remark = fields.Text(string='Remarks (If Any)')

    # Accounts.
    iou = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    account_others = fields.Boolean(string='Others')
    account_other_remarks = fields.Char(string='If Others')
    accounts_remark = fields.Text(string='Remarks (If Any)')

    # Audit.
    medical_bill = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    audit_others = fields.Boolean(string='Others')
    audit_other_remarks = fields.Char(string='If Others')
    audit_remark = fields.Text(string='Remarks (If Any)')

    # IT
    cpu = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    monitor = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    ups = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    mobile = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    document_backup = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    email = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    mobile_ceiling = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    sim_duce = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    laptop_duce = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    it_others = fields.Boolean(string='Others')
    it_other_remarks = fields.Char(string='If Others')
    corp_it_others = fields.Boolean(string='Others')
    corp_it_other_remarks = fields.Char(string='If Others')
    it_remark = fields.Text(string='Remarks (If Any)')
    corp_it_remark = fields.Text(string='Remarks (If Any)')

    # Corporate Service.
    vehicle = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    cs_others = fields.Boolean(string='Others')
    cs_other_remarks = fields.Char(string='If Others')
    cs_remark = fields.Text(string='Remarks (If Any)')

    # Finance.
    salary = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    finance_iou = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    finance_others = fields.Boolean(string='Others')
    finance_others_remarks = fields.Char(string='If Others')
    finance_remark = fields.Text(string='Remarks (If Any)')

    state_id = fields.Selection(
        [('draft', 'Draft'),
         ('hr_approved', 'Approved'),
         ('sent_to_supervisor', 'Sent To Supervisor'),
         ('clearance_open', 'Open to Clearance'),
         ('confirmed', 'Done'),
         ], string='State',
        default='draft')

    section_id = fields.Many2one('hr.section', 'Section', readonly=False,
                                 compute='_compute_employee_section')

    @api.depends('employee_id')
    def _compute_employee_section(self):
        for emp in self:
            if emp.employee_id.section:
                emp.section_id = emp.employee_id.section.id
            else:
                emp.section_id = ''

    @api.depends('employee_id')
    def _compute_employee_code(self):
        for emp in self:
            if emp.employee_id.employee_id:
                emp.employee_code = emp.employee_id.employee_id
            else:
                emp.employee_code = ''

    @api.depends('resignation_date')
    def _compute_resign_date_formate(self):
        for rec in self:
            rec.resignation_date_str = rec.resignation_date.strftime("%b %d, %Y")

    # @api.depends('employee_id')
    # def _compute_employee_user(self):
    #     for emp in self:
    #         if emp.employee_id.user_id:
    #             emp.employee_user_id = emp.employee_id.user_id
    #         else:
    #             emp.employee_user_id = ''

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.full_name

    @api.depends('employee_id')
    def _compute_employee_job_position(self):
        for emp in self:
            if emp.employee_id.position_name:
                emp.job_id = emp.employee_id.position_name
            else:
                emp.job_id = ''

    @api.depends('employee_id')
    def _compute_employee_dept(self):
        for emp in self:
            if emp.employee_id.department:
                emp.department_id = emp.employee_id.department.id
            else:
                emp.department_id = ''

    @api.depends('employee_id')
    def _compute_employee_joining_date(self):
        for emp in self:
            if emp.employee_id.start_date:
                joining_date = emp.employee_id.start_date
                emp.emp_joining_date = joining_date.strftime("%b %d, %Y")
            else:
                emp.emp_joining_date = ''

    @api.depends('employee_id')
    def _compute_employee_manager(self):
        for emp in self:
            if emp.employee_id.parent_id:
                emp.parent_id = emp.employee_id.parent_id.id
            else:
                raise UserError(_('Employee Manager not found. Edit this employee details'))

    @api.model
    def emp_get_email(self, emp_obj):
        if emp_obj:
            flag = 0
            for communication in emp_obj.communication_line:
                if communication.communication_type_code == '0010' and flag == 0:
                    email = communication.value
                    flag += 1
        return email

    def action_approve(self):

        # Disable employee from active employee list
        inactive_employment = self.env['hpl.employment'].search([('code', '=', 1)])
        self.employee_id.update({
            'employment': inactive_employment.id
        })

        # Archiving employee related user
        self.employee_id.user_id.active = False

        self.write({
            'state_id': 'hr_approved'
        })

    def action_sent_supervisor(self):
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                     'emergency_exit_sent_supervisor_template')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'emergency_exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'employee_emergency_exit_act_window')

        values = email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                          request.httprequest.host_url + "web#id=" + str(
                                                              self.id) + "&view_type=form"
                                                                         "&model=exit.request&menu_id=" + str(
                                                              recruitment_menu.id) + "&action=" + str(
                                                              recruitment_action.id)).replace("_user_name_",
                                                                                          self.supervisor_id.full_name)
        values['email_from'] = self.user_id.email_formatted

        # generate HOD mail id
        flag = 0
        for emp in self:
            if emp.supervisor_id:
                sup_email = self.emp_get_email(emp.supervisor_id)

        values['email_to'] = sup_email
        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state_id': 'sent_to_supervisor',
        })

    def action_clearance_open(self):
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                     'emergency_exit_request_check_list_template')
        # template = self.env['mail.template'].browse(template_id)
        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'emergency_exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'employee_emergency_exit_act_window')
        values = email_template.generate_email(self.id)
        values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                          request.httprequest.host_url + "web#id=" + str(
                                                              self.id) + "&view_type=form"
                                                                         "&model=employee.emergency.exit&menu_id=" + str(
                                                              recruitment_menu.id) + "&action=" + str(
                                                              recruitment_action.id))
        values['email_from'] = self.user_id.email_formatted

        email_list = []
        # GENERATE CORPORATE FINANCE MAIL ID
        for emp in self:
            if emp.clearance_person:
                for person in emp.clearance_person:
                    emails = self.emp_get_email(person)
                    email_list.append(emails)
        values['email_to'] = ','.join(map(str, email_list))
        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state_id': 'clearance_open',
        })

    def action_confirm(self):
        self.write({
            'state_id': 'confirmed'
        })
