from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class InterviewRateTemplate(models.Model):
    _name = 'interview.rate.template'
    _description = 'Template'

    name = fields.Char(string='Name', required=True)

    template_lines = fields.One2many('interview.rate.template.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):

        length = len(vals['template_lines'])

        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['criteria_id']}")
            if not vals['template_lines'][i][2]['criteria_id']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(InterviewRateTemplate, self).create(vals)

        return rec


class InterviewRateTemplateLine(models.Model):
    _name = 'interview.rate.template.line'
    _description = 'Template Line'

    template_id = fields.Many2one('interview.rate.template.template')
    criteria_id = fields.Many2one('interview.rate.criteria', string="Criteria")
