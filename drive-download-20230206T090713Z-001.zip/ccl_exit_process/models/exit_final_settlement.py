from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
from odoo.http import request


class ExitFinalSettlement(models.Model):
    _name = 'exit.final.settlement'
    _description = 'Exit Final Settlement'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    legacy_id = fields.Char(string='Legacy ID')
    sap_id = fields.Char(string='SAP ID')
    employee_code = fields.Char(string='Employee ID', store=True)
    # employee_id = fields.Many2one('hr.employee', required=True, string="Name",
    #                               default=lambda self: self.env.user.employee_id)
    employee_id = fields.Many2one('hpl.employee', required=True, string="Employee")
    job_id = fields.Char('Designation')
    department_id = fields.Many2one('hr.department', 'Department')
    emp_joining_date = fields.Date('Joining Date', readonly=True)
    resignation_date = fields.Date('Last Working Day', required=True)
    confirmation_date = fields.Date('Confirmation Date', required=True, default=fields.date.today())
    gross_salary = fields.Float(string='Gross Salary', readonly=True)
    basic_salary = fields.Float(string='Basic Salary')
    noticed_period = fields.Char(string='Notice Period')
    job_duration = fields.Char(string='Job Duration', default="0.0 -Yr(s)", compute='_compute_job_duration')
    pf_duration = fields.Char(string='PF Duration', default="0.0 -Yr(s)", compute='_compute_pf_duration')
    section = fields.Many2one('hr.section', string="Section")

    company_template_lines = fields.One2many('company.template.line', 'exit_final_settlement_id',
                                                        string='Template line')
    pf_account_template_lines = fields.One2many('pf.account.template.line', 'exit_final_settlement_id',
                                                         string='Template line')
    summary_template_lines = fields.One2many('final.settlement.summary.line', 'exit_final_settlement_id',
                                                         string='Template line')

    company_template_id = fields.Many2one('final.settlement.company.template', required=True,
                                  default=lambda self: self._default_company_template_id(), string='Company Template')
    pf_template_id = fields.Many2one('final.settlement.pf.template', required=True,
                                     default=lambda self: self._default_pf_template_id(), string='PF Template')
    summary_template_id = fields.Many2one('final.settlement.summary.template', required=True,
                                     default=lambda self: self._default_summary_template_id(), string='Template of Summary')
    company_total_payable = fields.Float(string="Net Payable", compute='_compute_company_total')
    company_total_deduction = fields.Float(string="Net Receivable", compute='_compute_company_total')
    company_total_net_balance = fields.Float(string="Net Balance", compute='_compute_company_total')

    pf_total_payable = fields.Float(string="Net Payable", compute='_compute_pf_total')
    pf_total_deduction = fields.Float(string="Net Receivable", compute='_compute_pf_total')
    pf_total_net_balance = fields.Float(string="Net Balance", compute='_compute_pf_total')

    summary_total_payable = fields.Float(string="Net Payable", compute='_compute_summary_total')
    summary_total_deduction = fields.Float(string="Net Receivable", compute='_compute_summary_total')
    summary_total_net_balance = fields.Float(string="Net Balance", compute='_compute_summary_total')

    corporate = fields.Boolean('Is Corporate Service?', default=False)
    corporate_office = fields.Many2one('hpl.employee', 'For Corporate Office')
    prepared_by = fields.Many2one('hpl.employee', 'Prepared By')
    checked_by = fields.Many2one('hpl.employee', 'Checked By')
    another_checked_by = fields.Many2one('hpl.employee', 'Checked By')
    responsible_one = fields.Many2one('hpl.employee', 'Executive Director')
    responsible_two = fields.Many2one('hpl.employee', 'Director')
    responsible_three = fields.Many2one('hpl.employee', 'DMD or CEO')
    payroll_pf = fields.Many2one('hpl.employee', 'Payroll PF', required=True)
    payroll_manager = fields.Many2one('hpl.employee', 'Payroll Manager', required=True)
    prepared_by_sign = fields.Image(string='Signature', readonly=False, compute='_compute_prepared_by_sign')
    checked_by_sign = fields.Image(string='Signature', readonly=False, compute='_compute_checked_by_sign')
    another_checked_by_sign = fields.Image(string='Signature', readonly=False, compute='_compute_another_checked_by_sign')
    corporate_office_sign = fields.Image(string='Signature', readonly=False, compute='_compute_corporate_office_sign')

    state_id = fields.Selection(
        [('draft', 'Draft'),
         ('send_to_pf', 'Waiting for PF Approval'),
         ('send_to_payroll', 'Waiting for Payroll'),
         ('confirmed', 'Done'),
         ], string='State',
        default='draft')

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.full_name

    @api.onchange('employee_id')
    def onchange_employee_id(self):
        for emp in self:
            print("-------------onchange_employee_id------------")
            interview = self.env['exit.interview'].search([('employee_id', '=', emp.employee_id.id)], limit=1)
            emp.employee_code = emp.employee_id.employee_id
            emp.sap_id = emp.employee_id.employee_id
            emp.job_id = emp.employee_id.position_name
            emp.department_id = emp.employee_id.department.id
            emp.emp_joining_date = emp.employee_id.start_date
            emp.section = emp.employee_id.section.id
            if interview:
                for item in interview:
                    emp.gross_salary = item.employee_salary
                    emp.resignation_date = item.resignation_date
            if emp.employee_id.internal_line:
                for line in emp.employee_id.internal_line:
                    emp.legacy_id = line.prev_personal_no

            print("sap--------", emp.sap_id, "----designation------", emp.job_id)

    @api.depends('prepared_by')
    def _compute_prepared_by_sign(self):
        for emp in self:
            if emp.prepared_by.sign:
                emp.prepared_by_sign = emp.prepared_by.sign
            else:
                emp.prepared_by_sign = ''

    @api.depends('checked_by')
    def _compute_checked_by_sign(self):
        for emp in self:
            if emp.checked_by.sign:
                emp.checked_by_sign = emp.checked_by.sign
            else:
                emp.checked_by_sign = ''

    @api.depends('another_checked_by')
    def _compute_another_checked_by_sign(self):
        for emp in self:
            if emp.another_checked_by.sign:
                emp.another_checked_by_sign = emp.another_checked_by.sign
            else:
                emp.another_checked_by_sign = ''

    # @api.depends('employee_code')
    # def _compute_gross_salary(self):
    #     for rec in self:
    #         interview = self.env['exit.interview'].search([('employee_id', '=', rec.employee_id.id)], limit=1)
    #         if interview:
    #             for item in interview:
    #                 if item.employee_salary:
    #                     rec.gross_salary = item.employee_salary
    #         else:
    #             rec.gross_salary =''

    @api.depends('corporate_office')
    def _compute_corporate_office_sign(self):
        for emp in self:
            if emp.corporate_office.sign:
                emp.corporate_office_sign = emp.corporate_office.sign
            else:
                emp.corporate_office_sign = ''



    # @api.depends('employee_id')
    # def _compute_employee_resignation_date(self):
    #     for emp in self:
    #         if emp.employee_id.personal_area:
    #             if emp.employee_id.personal_area.code == '2000':
    #                 exists_exit = self.env['exit.request.field.force'].search(
    #                     [('employee_code', '=', emp.employee_id.employee_id)],
    #                     limit=1)
    #                 if exists_exit.resignation_date:
    #                     emp.resignation_date = exists_exit.resignation_date
    #                 else:
    #                     emp.resignation_date = ''
    #             else:
    #                 exits = self.env['exit.request'].search([('employee_code', '=', emp.employee_id.employee_id)],
    #                                                         limit=1)
    #                 if exits.resignation_date:
    #                     emp.resignation_date = exits.resignation_date
    #                 else:
    #                     emp.resignation_date = ''
    #         else:
    #             emp.resignation_date = ''

    @api.depends('emp_joining_date', 'resignation_date')
    def _compute_job_duration(self):
        for settlement in self:
            if settlement.resignation_date:
                if settlement.emp_joining_date:
                    duration_year_round = str(round((
                            abs(settlement.resignation_date - settlement.emp_joining_date).days / 365), 2))
                    duration_yr = duration_year_round + '-Yr(s)'
                    settlement.job_duration = duration_yr
                else:
                    settlement.job_duration = ''
            else:
                settlement.job_duration = ''

    @api.depends('confirmation_date', 'resignation_date')
    def _compute_pf_duration(self):
        for settlement in self:
            if settlement.resignation_date:
                if settlement.emp_joining_date:
                    duration_year_round = str(round((
                            abs(settlement.resignation_date - settlement.confirmation_date).days / 365), 2))
                    duration_yr = duration_year_round + '-Yr(s)'
                    settlement.pf_duration = duration_yr
                else:
                    settlement.pf_duration = ''
            else:
                settlement.pf_duration = ''

    # @api.depends('confirmation_date', 'resignation_date')
    # def _compute_pf_duration(self):
    #     for settlement in self:
    #         settlement.pf_duration = str(round((
    #                 abs(settlement.resignation_date - settlement.confirmation_date).days / 365), 2)) + '-Yr(s)'

    def _default_company_template_id(self):
        template_id = self.env['final.settlement.company.template'].search([], limit=1)
        print("template_id---93----", template_id)
        return template_id

    def _default_pf_template_id(self):
        template_id = self.env['final.settlement.pf.template'].search([], limit=1)
        return template_id

    def _default_summary_template_id(self):
        template_id = self.env['final.settlement.summary.template'].search([], limit=1)
        print("template_id---177----", template_id)
        return template_id

    @api.onchange('company_template_id')
    def onchange_company_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.company_template_id.template_lines:
                val = {
                    'company_particular_id': line.particular_id.id,
                }
                lines.append((0, 0, val))
            rec.company_template_lines = lines

    @api.onchange('pf_template_id')
    def onchange_pf_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.pf_template_id.template_lines:
                val = {
                    'pf_particular_id': line.particular_id.id,
                }
                lines.append((0, 0, val))
            rec.pf_account_template_lines = lines

    @api.onchange('summary_template_id')
    def onchange_summary_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.summary_template_id.template_lines:
                val = {
                    'summary_particular_id': line.particular_id.id,
                }
                lines.append((0, 0, val))
            rec.summary_template_lines = lines

    @api.depends('company_template_lines')
    def _compute_company_total(self):
        """
       Compute the total amounts of the Final Settlement Company.
       """
        for rec in self:
            payable = 0.0
            deduct = 0.0
            net_balance = 0.0
            for line in rec.company_template_lines:
                payable += line.payable
                deduct += line.deduction
                net_balance += line.net_balance
            rec.update({
                'company_total_payable': payable,
                'company_total_deduction': deduct,
                'company_total_net_balance': net_balance,
            })

    @api.depends('pf_account_template_lines')
    def _compute_pf_total(self):
        """
       Compute the total amounts of the Final Settlement PF Account.
       """
        for rec in self:
            payable = 0.0
            deduct = 0.0
            net_balance = 0.0
            for line in rec.pf_account_template_lines:
                payable += line.payable
                deduct += line.deduction
                net_balance += line.net_balance
            rec.update({
                'pf_total_payable': payable,
                'pf_total_deduction': deduct,
                'pf_total_net_balance': net_balance,
            })

    @api.depends('summary_template_lines')
    def _compute_summary_total(self):
        """
         Compute the total amounts of the Final Settlement Summary.
       """
        for rec in self:
            payable = 0.0
            deduct = 0.0
            net_balance = 0.0
            for line in rec.summary_template_lines:
                payable += line.payable
                deduct += line.deduction
                net_balance += line.net_balance
            rec.update({
                'summary_total_payable': payable,
                'summary_total_deduction': deduct,
                'summary_total_net_balance': net_balance,
            })

    @api.model
    def emp_get_email(self, emp_obj):
        if emp_obj:
            flag = 0
            for communication in emp_obj.communication_line:
                if communication.communication_type_code == '0010' and flag == 0:
                    email = communication.value
                    flag += 1
        return email

    def action_submit_to_pf(self):
        template_id = self.env.ref('ccl_onboarding.final_settlement_pf_email_template').id
        template = self.env['mail.template'].browse(template_id)
        for emp in self:
            if emp.payroll_pf:
                for person in emp.payroll_pf:
                    email = self.emp_get_email(person)
        template['email_to'] = email
        template.send_mail(self.id, force_send=True)
        self.write({
            'state_id': 'send_to_pf',
        })

    def action_submit_to_payroll_manager(self):
        template_id = self.env.ref('ccl_onboarding.final_settlement_payroll_email_template').id
        template = self.env['mail.template'].browse(template_id)
        for emp in self:
            if emp.payroll_manager:
                for person in emp.payroll_manager:
                    email = self.emp_get_email(person)
        template['email_to'] = email
        template.send_mail(self.id, force_send=True)

        self.write({
            'state_id': 'send_to_payroll',
        })

    def action_done(self):
        template_id = self.env.ref('ccl_exit_process.exit_settlement_final_approved').id
        template = self.env['mail.template'].browse(template_id)
        for emp in self:
            if emp.prepared_by:
                for person in emp.prepared_by:
                    email = self.emp_get_email(person)
        template['email_to'] = email
        template.send_mail(self.id, force_send=True)

        self.write({
            'state_id': 'confirmed',
        })


class CompanyTemplateLine(models.Model):
    _name = 'company.template.line'
    _description = 'Company Template Line'

    exit_final_settlement_id = fields.Many2one('exit.final.settlement', string="Exit")
    company_particular_id = fields.Many2one('final.settlement.company', string="particular")
    day = fields.Integer(string='Days')
    payable = fields.Float(string='Payable')
    deduction = fields.Float(string='Deduction')
    net_balance = fields.Float(string='Net Balance', compute='_compute_net_balance')

    @api.depends('payable', 'deduction')
    def _compute_net_balance(self):
        for rec in self:
            rec.net_balance = rec.payable - rec.deduction


class PFAccountTemplateLine(models.Model):
    _name = 'pf.account.template.line'
    _description = 'PF Account Template Line'

    exit_final_settlement_id = fields.Many2one('exit.final.settlement', string="Exit")
    pf_particular_id = fields.Many2one('final.settlement.pf.account', string="particular")
    payable = fields.Float(string='Payable')
    deduction = fields.Float(string='Deduction')
    net_balance = fields.Float(string='Net Balance', compute='_compute_net_balance')

    @api.depends('payable', 'deduction')
    def _compute_net_balance(self):
        for rec in self:
            rec.net_balance = rec.payable - rec.deduction


class SummaryTemplateLine(models.Model):
    _name = 'final.settlement.summary.line'
    _description = 'Summary Template Line'

    exit_final_settlement_id = fields.Many2one('exit.final.settlement', string="Exit")
    summary_particular_id = fields.Many2one('final.settlement.summary', string="particular")
    payable = fields.Float(string='Payable', compute='_compute_summery_payable')
    deduction = fields.Float(string='Deduction', compute='_compute_deduction')
    net_balance = fields.Float(string='Net Balance', compute='_compute_net_balance')

    @api.depends('payable', 'deduction')
    def _compute_net_balance(self):
        for rec in self:
            rec.net_balance = rec.payable - rec.deduction

    @api.depends('exit_final_settlement_id.pf_total_payable', 'exit_final_settlement_id.company_total_payable')
    def _compute_summery_payable(self):
        for rec in self:
            if rec.summary_particular_id.summary_particular == 'Settlement of Company Account':
                rec.payable = rec.exit_final_settlement_id.company_total_payable
            elif rec.summary_particular_id.summary_particular == 'Settlement of PF Account':
                rec.payable = rec.exit_final_settlement_id.pf_total_payable

    @api.depends('exit_final_settlement_id.company_total_deduction', 'exit_final_settlement_id.pf_total_deduction')
    def _compute_deduction(self):
        for rec in self:
            if rec.summary_particular_id.summary_particular == 'Settlement of Company Account':
                rec.deduction = rec.exit_final_settlement_id.company_total_deduction
            elif rec.summary_particular_id.summary_particular == 'Settlement of PF Account':
                rec.deduction = rec.exit_final_settlement_id.pf_total_deduction
