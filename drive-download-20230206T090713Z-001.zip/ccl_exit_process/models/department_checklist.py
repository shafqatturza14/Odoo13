from odoo import fields, models, api


class DepartmentChecklist(models.Model):
    _name = 'exit.department.checklist'
    _description = 'Description'

    responsibility_handover = fields.Selection(selection=[
        ('completed', 'Completed'),
        ('notcompleted', 'Not Completed')], string='Responsibility Handover')
    responsibility_checklist = fields.Selection(selection=[
        ('softcopy', 'Soft Copy'),
        ('hardcopy', 'Hard Copy')], string='Responsibility Checklist')
    documents_handover = fields.Selection(selection=[
        ('completed', 'Completed'),
        ('notcompleted', 'Not Completed')], string='Documents Handover')

    departmental_assets = fields.Selection(selection=[
        ('yes', 'Yes'),
        ('no', 'No')], string='Departmental Assets')

    removal_backend_done_by = fields.Many2one('res.users', string='Removal of Backend Access done by', \
                                              default=lambda self: self.env.user)

    handover_taken_by = fields.Many2one('res.users', string='Handover taken by', \
                                        default=lambda self: self.env.user)

    head_of_department = fields.Many2one('res.users', string='Head of Department', \
                                         default=lambda self: self.env.user)
