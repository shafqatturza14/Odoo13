import base64
from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.modules.module import get_module_resource


class ExitFieldForce(models.Model):
    _name = 'exit.request.field.force'
    _description = 'Exit Field Force'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']
    _rec_name = "name"

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_code = fields.Char(string='Employee ID', readonly=True, store=True, compute='_compute_employee_code')
    posted = fields.Char(string='Posted', readonly=False, compute='_compute_employee_posting')
    employee_id = fields.Many2one('hpl.employee', required=True, string="Name")
    zone_id = fields.Char(string='Zone', readonly=False, compute='_compute_employee_zone')
    job_id = fields.Char('Designation', readonly=False, compute='_compute_employee_job_position')
    # emp_joining_date = fields.Date('Joining Date', readonly=True, compute='_compute_employee_joining_date')
    department_id = fields.Many2one('hr.department', 'Department', readonly=True, compute='_compute_employee_dept')
    region = fields.Char(string='Region', readonly=False, compute='_compute_employee_region')
    resignation_date = fields.Date('Resignation Date', required=True, default=fields.date.today())
    terminated_date = fields.Date('Terminated Date', required=True, default=fields.date.today())
    particulars_lines = fields.One2many('particulars.line', 'exit_req_id', string='Particulars line')
    second_particulars_lines = fields.One2many('second.particulars.line', 'exit_req_id', string='Second Particulars line')
    motor_bike_lines = fields.One2many('moto.bike.line', 'exit_req_id', string='Motor Bike line')
    particulars_template_id = fields.Many2one('field.force.particular.template','Particulars Template', required=True,
                                              default=lambda self: self._default_particular_template_id())
    motorbike_template_id = fields.Many2one('field.force.moto.bike.template','MotorBike Template', required=True,
                                              default=lambda self: self._default_motorbike_template_id())
    second_particulars_template_id = fields.Many2one('second.field.force.particular.template','Particulars Template', required=True,
                                            default=lambda self: self._default_second_particular_template_id())

    supervisor = fields.Many2one('hpl.employee', required=True, string="Immediate Supervisor")
    supervisor_id = fields.Char(string='ID', readonly=False, compute='_compute_supervisor_id')
    supervisor_contact_no = fields.Char(string='Contact')
    supervisor_designation = fields.Char('Designation', readonly=False, compute='_compute_supervisor_designation')
    dept_head = fields.Many2one('hpl.employee', required=True, string="Departmental Head")
    dept_head_id = fields.Char(string='ID', readonly=False, compute='_compute_dept_head_id')
    dept_head_designation = fields.Char('Designation', readonly=False, compute='_compute_dept_head_designation')
    dept_head_contact_no = fields.Char(string='Contact')
    supervisor_comment = fields.Text(string='Comment')
    dept_head_comment = fields.Text(string='Comment')
    reasons_of_leaving = fields.Text(string='Reasons of leaving')
    comment_of_market = fields.Text(string='Comments of Market & Depot Clearance')
    comment_of_agm = fields.Text(string='Comments of AGM (Sales)/ DGM (Sales)/ GM (Sales)')
    comment_of_gm = fields.Text(string='Comments of General Manager, Human Resources')
    comment_of_director = fields.Text(string='Comments of Executive Director, Sales & Admin')
    remarks = fields.Char(string='If wish to transfer the motor bike, mention the name of MIO/SMIO/AM/RM')

    @api.depends('employee_id', 'employee_code')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.name

    @api.depends('supervisor')
    def _compute_supervisor_id(self):
        for emp in self:
            if emp.supervisor.employee_id:
                emp.supervisor_id = emp.supervisor.employee_id
            else:
                emp.supervisor_id = ''

    @api.depends('dept_head')
    def _compute_dept_head_id(self):
        for emp in self:
            if emp.dept_head.employee_id:
                emp.dept_head_id = emp.dept_head.employee_id
            else:
                emp.dept_head_id = ''

    @api.depends('employee_id')
    def _compute_employee_code(self):
        for emp in self:
            if emp.employee_id.employee_id:
                emp.employee_code = emp.employee_id.employee_id
            else:
                emp.employee_code = ''

    @api.depends('employee_id')
    def _compute_employee_job_position(self):
        for emp in self:
            if emp.employee_id.position:
                emp.job_id = emp.employee_id.position
            else:
                emp.job_id = ''

    @api.depends('supervisor')
    def _compute_supervisor_designation(self):
        for emp in self:
            if emp.supervisor.position:
                emp.supervisor_designation = emp.supervisor.position
            else:
                emp.supervisor_designation = ''

    def _default_particular_template_id(self):
        template_id = self.env['field.force.particular.template'].search([], limit=1)
        return template_id

    def _default_motorbike_template_id(self):
        template_id = self.env['field.force.moto.bike.template'].search([], limit=1)
        return template_id

    def _default_second_particular_template_id(self):
        template_id = self.env['second.field.force.particular.template'].search([], limit=1)
        return template_id

    @api.depends('dept_head')
    def _compute_dept_head_designation(self):
        for emp in self:
            if emp.dept_head.position:
                emp.dept_head_designation = emp.dept_head.position
            else:
                emp.dept_head_designation = ''

    @api.depends('employee_id')
    def _compute_employee_dept(self):
        for emp in self:
            if emp.employee_id.department:
                emp.department_id = emp.employee_id.department.id
            else:
                emp.department_id = ''

    @api.depends('employee_id')
    def _compute_employee_region(self):
        for emp in self:
            if emp.employee_id.personal_sub_area:
                emp.region = emp.employee_id.personal_sub_area.name
            else:
                emp.region = ''

    @api.depends('employee_id')
    def _compute_employee_zone(self):
        for emp in self:
            if emp.employee_id.personal_area:
                emp.zone_id = emp.employee_id.personal_area.name
            else:
                emp.zone_id = ''

    @api.depends('employee_id')
    def _compute_employee_posting(self):
        for emp in self:
            if emp.employee_id.personal_area:
                emp.posted = emp.employee_id.personal_area.name
            else:
                emp.posted = ''

    @api.onchange('particulars_template_id')
    def onchange_particulars_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.particulars_template_id.template_lines:
                val = {
                    'sl': line.sl,
                    'particulars': line.particulars,
                }
                lines.append((0, 0, val))
            rec.particulars_lines = lines

    @api.onchange('motorbike_template_id')
    def onchange_motorbike_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.motorbike_template_id.template_lines:
                val = {
                    'particulars': line.particulars,
                }
                lines.append((0, 0, val))
            rec.motor_bike_lines = lines

    @api.onchange('second_particulars_template_id')
    def onchange_second_particulars_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.second_particulars_template_id.template_lines:
                val = {
                    'sl': line.sl,
                    'particulars': line.particulars,
                }
                lines.append((0, 0, val))
            rec.second_particulars_lines = lines


class Particulars(models.Model):
    _name = 'particulars.line'
    _description = 'Exit Request Particulars Line'

    exit_req_id = fields.Many2one('exit.request.field.force', string="ExitRequest")
    sl = fields.Char(string='SL')
    particulars = fields.Char(string='Particulars', required=True)
    submitted = fields.Boolean(string='Submitted', default=False)
    not_submitted = fields.Boolean(string='Not Submitted', default=False)
    not_provided = fields.Boolean(string='Not Provided', default=False)
    is_category = fields.Boolean('Is a category', default=False)
    # motobike_lines = fields.One2many('moto.bike.line', 'perticular_id', string='Particulars line')

    @api.onchange('submitted')
    def onchange_submitted(self):
        for rec in self:
            if rec.submitted == True:
                rec.not_submitted = False
                rec.not_provided = False

    @api.onchange('not_submitted')
    def onchange_not_submitted(self):
        for rec in self:
            if rec.not_submitted == True:
                rec.submitted = False
                rec.not_provided = False

    @api.onchange('not_provided')
    def onchange_not_provided(self):
        for rec in self:
            if rec.not_provided == True:
                rec.submitted = False
                rec.not_submitted =False

class SecondParticulars(models.Model):
    _name = 'second.particulars.line'
    _description = 'Exit Request Second Particulars Line'

    exit_req_id = fields.Many2one('exit.request.field.force', string="ExitRequest")
    sl = fields.Char(string='SL')
    particulars = fields.Char(string='Particulars', required=True)
    submitted = fields.Boolean(string='Submitted', default=False)
    not_submitted = fields.Boolean(string='Not Submitted', default=False)
    not_provided = fields.Boolean(string='Not Provided', default=False)
    is_category = fields.Boolean('Is a category', default=False)

    @api.onchange('submitted')
    def onchange_submitted(self):
        for rec in self:
            if rec.submitted == True:
                rec.not_submitted = False
                rec.not_provided = False

    @api.onchange('not_submitted')
    def onchange_not_submitted(self):
        for rec in self:
            if rec.not_submitted == True:
                rec.submitted = False
                rec.not_provided = False

    @api.onchange('not_provided')
    def onchange_not_provided(self):
        for rec in self:
            if rec.not_provided == True:
                rec.submitted = False
                rec.not_submitted = False


class MotorBikeLine(models.Model):
    _name = 'moto.bike.line'
    _description = 'Motor Bike Line'

    exit_req_id = fields.Many2one('exit.request.field.force', string="ExitRequest")
    perticular_id = fields.Many2one('particulars.line', string="Perticulars")
    particulars = fields.Char(string='Particulars', required=True)
    submitted = fields.Boolean(string='Submitted',default=False)
    not_submitted = fields.Boolean(string='Not Submitted', default=False)
    not_provided = fields.Boolean(string='Not Provided', default=False)
    remarks = fields.Char(string='Remarks')


    @api.onchange('submitted')
    def onchange_submitted(self):
        for rec in self:
            if rec.submitted == True:
                rec.not_submitted = False
                rec.not_provided = False

    @api.onchange('not_submitted')
    def onchange_not_submitted(self):
        for rec in self:
            if rec.not_submitted == True:
                rec.submitted = False
                rec.not_provided = False

    @api.onchange('not_provided')
    def onchange_not_provided(self):
        for rec in self:
            if rec.not_provided == True:
                rec.submitted = False
                rec.not_submitted = False