from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class FinalSettlementCompanyTemplate(models.Model):
    _name = 'final.settlement.company.template'
    _description = 'Final Settlement Company Template'

    name = fields.Char(string='Name', required=True)
    template_lines = fields.One2many('final.settlement.company.template.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):

        length = len(vals['template_lines'])

        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['particular_id']}")
            if not vals['template_lines'][i][2]['particular_id']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(FinalSettlementCompanyTemplate, self).create(vals)

        return rec


class InterviewRateTemplateLine(models.Model):
    _name = 'final.settlement.company.template.line'
    _description = 'Template Line'

    template_id = fields.Many2one('final.settlement.company.template')
    particular_id = fields.Many2one('final.settlement.company', string="Particular")
