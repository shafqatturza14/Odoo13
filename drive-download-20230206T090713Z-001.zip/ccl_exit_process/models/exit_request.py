from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import date, datetime, timedelta
from odoo.http import request


class ExitRequest(models.Model):
    _name = 'exit.request'
    _description = 'Description'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', store=True,compute='_compute_rec_name')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id)
    # employee_id = fields.Many2one('hr.employee', required=True, string="Employee", readonly=True,
    #                               default=lambda self: self.self._default_employee_confirmation())
    employee_id = fields.Many2one('hpl.employee', required=True, string="Employee",
                                  default=lambda self: self.env['hpl.employee'].search(
                                      [('user_id', '=', self.env.user.id)]).id)
    # user_id = fields.Many2one(related='employee_id.user_id', string='User', readonly=True)

    employee_code = fields.Char(string='Employee ID', readonly=False,store=True, compute='_compute_employee_code')
    job_id = fields.Char( 'Designation',required=True, readonly=False, compute='_compute_employee_job_position')
    department_id = fields.Many2one('hr.department', 'Department', readonly=False, required=True,
                                    compute='_compute_employee_dept')
    section_id = fields.Many2one('hr.section', 'Section', readonly=False,
                                 compute='_compute_employee_section')
    contact_no = fields.Char('Contact No', readonly=False, compute='_compute_employee_contact')
    father_name = fields.Char('Father', readonly=False, compute='_compute_employee_father')
    mother_name = fields.Char('Mother', readonly=False, compute='_compute_employee_mother')
    address = fields.Char('Address', readonly=False, compute='_compute_employee_address')
    city = fields.Char('City', readonly=False, compute='_compute_employee_address')
    district = fields.Char('District', readonly=False, compute='_compute_employee_address')
    emp_joining_str = fields.Char('Date of Joining', compute='_compute_employee_joining_date')
    is_replacement_available = fields.Boolean('Is Replacement Available', default=False, store=True)
    supervisor = fields.Many2one('hpl.employee', 'Supervisor')
    hod = fields.Many2one('hpl.employee', 'Head of Department')
    human_resource = fields.Many2one('hpl.employee', 'Human Resources')
    immediate_supervisor = fields.Many2one('hpl.employee', 'Immediate Supervisor')
    clearance_person = fields.Many2many('hpl.employee', string="Clearance Authority")
    resignation_date = fields.Date('Effective From', required=True, default=fields.date.today())
    resignation_date_str = fields.Char('Date', compute='_compute_resign_date_formate')
    date = fields.Date('Date', default=fields.date.today())
    date_str = fields.Char('Date', compute='_compute_date_formate')

    @api.depends('date')
    def _compute_date_formate(self):
        for rec in self:
            rec.date_str = rec.date.strftime("%d %b %Y")

    @api.depends('date')
    def _compute_resign_date_formate(self):
        for rec in self:
            rec.resignation_date_str = rec.resignation_date.strftime("%b %d, %Y")

    user_id = fields.Many2one('res.users', string='User', \
                              default=lambda self: self.env.user, readonly=True)
    employee_user_id = fields.Many2one('res.users', string='Employee User'
                                      )

    completion_date = fields.Date(string='Completion Date', \
                                  readonly=True, copy=False)

    # Department

    gmp_document = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    action_plan = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    # gmp_document = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])

    supervisor_others = fields.Boolean(string='Others', default=False)
    other_remarks = fields.Char(string='If Others')
    sup_remark = fields.Text(string='Remarks (If Any)')

    # Plant Admin
    stationeries = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    keys = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    admin_others = fields.Boolean(string='Others')
    admin_other_remarks = fields.Char(string='If Others')
    admin_remark = fields.Text(string='Remarks (If Any)')

    # Hr
    visiting_card = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    id_card = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    brief_case = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    bag = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    exit_interview = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    hr_others = fields.Boolean(string='Others')
    hr_other_remarks = fields.Char(string='If Others')
    hr_remark = fields.Text(string='Remarks (If Any)')

    # Accounts.
    iou = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    account_others = fields.Boolean(string='Others')
    account_other_remarks = fields.Char(string='If Others')
    accounts_remark = fields.Text(string='Remarks (If Any)')

    # Audit.
    medical_bill = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    audit_others = fields.Boolean(string='Others')
    audit_other_remarks = fields.Char(string='If Others')
    audit_remark = fields.Text(string='Remarks (If Any)')

    # IT
    cpu = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    monitor = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    ups = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    mobile = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    document_backup = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    email = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    mobile_ceiling = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    sim_duce = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    laptop_duce = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    it_others = fields.Boolean(string='Others')
    it_other_remarks = fields.Char(string='If Others')
    corp_it_others = fields.Boolean(string='Others')
    corp_it_other_remarks = fields.Char(string='If Others')
    it_remark = fields.Text(string='Remarks (If Any)')
    corp_it_remark = fields.Text(string='Remarks (If Any)')

    # Corporate Service.
    vehicle = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    cs_others = fields.Boolean(string='Others')
    cs_other_remarks = fields.Char(string='If Others')
    cs_remark = fields.Text(string='Remarks (If Any)')

    # Finance.
    salary = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    finance_iou = fields.Selection([('Yes', 'Outstanding'), ('No', 'Not Outstanding')])
    finance_others = fields.Boolean(string='Others')
    finance_others_remarks = fields.Char(string='If Others')
    finance_remark = fields.Text(string='Remarks (If Any)')
    emp_group = fields.Char(string='Group', readonly=False, compute='_compute_emp_group')

    add_exit_attachment = fields.Many2many('ir.attachment', string="Add Exit Attachment")
    state = fields.Selection(
        [('draft', 'Draft'), ('sent_to_supervisor', 'Send to Supervisor'),
         ('supervisor_approved', 'Supervisor Approved'),
         ('hod_approved', 'HoD Approved'),
         ('hr_approved', 'HR Approved'),
         ('sent_immediate_supervisor', 'Send to Immediate Supervisor'),
         ('clearance_open', 'Open to Clearance'),
         ('confirmed', 'Done'),
         ], string='State',
        default='draft')

    @api.model
    def create(self, vals):
        user = self.env.user
        employee_obj = self.env['hr.employee'].search([('user_id', '=', user.id)])
        if employee_obj:
            exit_obj = self.env['exit.request'].search([('employee_id', '=', employee_obj.id)])
            print(f'exit {exit_obj}')
            if exit_obj:
                raise UserError(_('Exit request already created for this employee'))

        res = super(ExitRequest, self).create(vals)

        employee_inventory = self.env['employee.inventory'].search([('employee_id', '=', res.employee_id.id)])

        if employee_inventory:

            for emp_inventory in employee_inventory:
                # create employee inventory return
                values = {
                    'employee_id': res.employee_id.id,
                    'provided_inventory_date': emp_inventory.inventory_date,
                    'returning_inventory_date': False,
                }
                employee_inventory_return = self.env['employee.inventory.return'].search(
                    [('employee_id', '=', res.employee_id.id)])
                if not employee_inventory_return:
                    inventory_return = self.env['employee.inventory.return'].create(values)

                if emp_inventory.inventory_lines:
                    for line in emp_inventory.inventory_lines:
                        val = {
                            'exit_request_id': res.id,
                            'product_id': line.product_id.id,
                            'qty_given': line.qty_needed,
                            'return_product': 'no'
                        }
                        self.env['temp.employee.inventory.line'].sudo().create(val)
                        employee_inventory_return = self.env['employee.inventory.return'].search(
                            [('employee_id', '=', res.employee_id.id)])

                        return_value = {
                            'inventory_id': employee_inventory_return.id,
                            'product_id': line.product_id.id,
                            'qty_given': line.qty_needed,
                            'return_product': 'no'
                        }

                        self.env['employee.inventory.return.line'].sudo().create(return_value)

        return res

    def unlink(self):
        # "your code"
        employee_inventory_return = self.env['employee.inventory.return'].sudo().search(
            [('employee_id', '=', self.employee_id.id)])

        for inventory_return in employee_inventory_return:
            inventory_return.sudo().unlink()

        res = super(ExitRequest, self).unlink()
        return res

    @api.depends('employee_id')
    def _compute_employee_code(self):
        for emp in self:
            if emp.employee_id.employee_id:
                emp.employee_code = emp.employee_id.employee_id
            else:
                emp.employee_code = ''

    def _default_employee_id(self):
        for emp in self:
            user = self.env.user
            employee_id = self.env['hpl.employee'].search([('user_id', '=', user.id)]).id
            if employee_id:
                emp.employee_id = employee_id

    @api.depends('employee_id')
    def _compute_emp_group(self):
        for emp in self:
            if emp.employee_id.employee_sub_group:
                emp.emp_group = emp.employee_id.employee_sub_group.name
            else:
                emp.emp_group = ''

    @api.depends('employee_id')
    def _compute_employee_contact(self):
        flag = 0
        for emp in self:
            if emp.employee_id:
                for communication in emp.employee_id.communication_line:
                    if communication.communication_type_code == '0004' and flag == 0:
                        emp.contact_no = communication.value
                        flag += 1
                        break
                    elif communication.communication_type_code == 'CELL' and flag == 0:
                        emp.contact_no = communication.value
                        flag += 1
                        break
                    else:
                        emp.contact_no = ''
            else:
                emp.contact_no=''

    @api.depends('employee_id')
    def _compute_employee_father(self):
        father_flag = 0
        for emp in self:
            if emp.employee_id:
                for family in emp.employee_id.family_line:
                    if family.family_type.code == '11' and father_flag == 0:
                        emp.father_name = family.full_name
                        father_flag += 1
                        break
                    else:
                        emp.father_name = ''
                else:
                    emp.father_name = ''

            else:
                emp.father_name = ''

    @api.depends('employee_id')
    def _compute_employee_mother(self):
        flag = 0
        for emp in self:
            if emp.employee_id:
                for family in emp.employee_id.family_line:
                    if family.family_type.code == '12' and flag == 0:
                        emp.mother_name = family.full_name
                        flag += 1
                        break
                    else:
                        emp.mother_name = ''
                else:
                    emp.mother_name = ''
            else:
                emp.mother_name = ''
    @api.depends('employee_id')
    def _compute_employee_address(self):
        flag = 0
        for emp in self:
            if emp.employee_id:
                for addr in emp.employee_id.address_line:
                    if addr.address_type.code == '1' and flag == 0:
                        if addr.street_house:
                            emp.address = addr.street_house
                        else:
                            emp.address = ''

                        if addr.city:
                            emp.city = addr.city
                        else:
                            emp.city = ''

                        if addr.district:
                            emp.district = addr.district
                        else:
                            emp.district = ''

                        flag += 1
                        break
            else:
                emp.address = ''
                emp.city = ''
                emp.district = ''
    @api.depends('employee_id')
    def _compute_employee_user(self):
        for emp in self:
            if emp.employee_id.user_id:
                emp.employee_user_id = emp.employee_id.user_id
            else:
                raise UserError(_('Employee related user not found. Edit this employee details'))

    @api.depends('employee_id', 'employee_code')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = str(emp.employee_id.full_name) + '-' + str(emp.employee_code)

    @api.depends('employee_id')
    def _compute_employee_job_position(self):
        for emp in self:
            if emp.employee_id.position_name:
                emp.job_id = emp.employee_id.position_name
            else:
                emp.job_id = ''

    @api.depends('employee_id')
    def _compute_employee_dept(self):
        for emp in self:
            if emp.employee_id.department:
                emp.department_id = emp.employee_id.department.id
            else:
                emp.department_id = ''
    @api.depends('employee_id')
    def _compute_employee_section(self):
        for emp in self:
            if emp.employee_id.section:
                emp.section_id = emp.employee_id.section.id
            else:
                emp.section_id = ''

    @api.depends('employee_id')
    def _compute_employee_joining_date(self):
        for emp in self:
            if emp.employee_id.start_date:
                joining_date = emp.employee_id.start_date
                emp.emp_joining_str = joining_date.strftime("%b %d, %Y")
            else:
                emp.emp_joining_str = ''

    @api.depends('employee_id')
    def _compute_employee_manager(self):
        for emp in self:
            if emp.employee_id.parent_id:
                emp.parent_id = emp.employee_id.parent_id.id
            else:
                raise UserError(_('Employee Manager not found. Edit this employee details'))

    # Developed by Sohan

    def action_submit_to_supervisor(self):
        if not self.supervisor:
            raise UserError(_('Supervisor not found. Please Select it first'))
        # send email to supervisor
        supervisor_email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_sent_to_supervisor_template')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_act_window')

        values = supervisor_email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                          request.httprequest.host_url + "web#id=" + str(
                                                              self.id) + "&view_type=form"
                                                                         "&model=exit.request&menu_id=" + str(
                                                              recruitment_menu.id) + "&action=" + str(
                                                              recruitment_action.id)).replace("_user_name_",
                                                                                              self.supervisor.full_name)
        values['email_from'] = self.user_id.email_formatted

        # generate Supervisor mail id
        flag = 0
        for emp in self:
            if emp.supervisor:
                for communication in emp.supervisor.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        supervisor_email = communication.value
                        flag += 1

        values['email_to'] = supervisor_email

        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state': 'sent_to_supervisor',
        })

    def action_supervisor_approve(self):
        if not self.hod:
            raise UserError(_('Head of Department not found. Please Select it first'))
        if not self.human_resource:
            raise UserError(_('Human Resources not found. Please Select it first'))
        # send email to supervisor
        supervisor_email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                                'exit_request_supervisor_approved_template')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_act_window')

        values = supervisor_email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                          request.httprequest.host_url + "web#id=" + str(
                                                              self.id) + "&view_type=form"
                                                                                 "&model=exit.request&menu_id=" + str(
                                                              recruitment_menu.id) + "&action=" + str(
                                                              recruitment_action.id)).replace("_user_name_",
                                                                                          self.hod.full_name)
        values['email_from'] = self.user_id.email_formatted

        # generate HOD mail id
        flag = 0
        for emp in self:
            if emp.hod:
                for communication in emp.hod.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        sup_email = communication.value
                        flag += 1

        values['email_to'] = sup_email

        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        # SEND MAIL TO EMPLOYEE .
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                                'exit_request_confirm_confirm_mail_template')

        values = email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_department_name_", self.supervisor.position_name).replace("_user_name_",
                                                                                              self.employee_id.full_name)
        values['email_from'] = self.user_id.email_formatted

        # GENERATE EMPLOYEE MAIL ID
        flag = 0
        for emp in self:
            if emp.employee_id:
                for communication in emp.employee_id.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        emp_email = communication.value
                        flag += 1

        values['email_to'] = emp_email

        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state': 'supervisor_approved',
        })

    def action_supervisor_reject(self):
        # SEND MAIL TO EMPLOYEE .
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                     'exit_request_confirm_reject_mail_template')

        values = email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_department_name_", self.supervisor.position).replace("_user_name_",
                                                                                                          self.employee_id.full_name)
        values['email_from'] = self.user_id.email_formatted

        # GENERATE EMPLOYEE MAIL ID
        flag = 0
        for emp in self:
            if emp.employee_id:
                for communication in emp.employee_id.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        email = communication.value
                        flag += 1

        values['email_to'] = email
        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state': 'draft',
        })

    def hod_approve(self):
        # send email to HOD
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                                'exit_request_supervisor_approved_template')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_act_window')

        values = email_template.generate_email(self.id)
        if not self.hod:
            raise UserError(_('Head of Department not found. Please Select it first'))

        values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                          request.httprequest.host_url + "web#id=" + str(
                                                              self.id) + "&view_type=form"
                                                                         "&model=exit.request&menu_id=" + str(
                                                              recruitment_menu.id) + "&action=" + str(
                                                              recruitment_action.id)).replace("_user_name_",
                                                                                              self.human_resource.full_name)
        values['email_from'] = self.user_id.email_formatted

        # generate HOD mail id
        flag = 0
        for emp in self:
            if emp.human_resource:
                for communication in emp.human_resource.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        hr_email = communication.value
                        flag += 1

        values['email_to'] = hr_email

        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        # SEND MAIL TO EMPLOYEE .
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                     'exit_request_confirm_confirm_mail_template')

        values = email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_department_name_", self.hod.position).replace("_user_name_",
            self.employee_id.full_name)
        values['email_from'] = self.user_id.email_formatted

        # GENERATE EMPLOYEE MAIL ID
        flag = 0
        for emp in self:
            if emp.employee_id:
                for communication in emp.employee_id.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        email = communication.value
                        flag += 1

        values['email_to'] = email

        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state': 'hod_approved',
        })

    def action_hod_reject(self):

        # SEND MAIL TO EMPLOYEE .
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                     'exit_request_confirm_reject_mail_template')
        values = email_template.generate_email(self.id)
        if not self.hod:
            raise UserError(_('Head of Department not found. Please Select it first'))

        values['body_html'] = values['body_html'].replace("_department_name_", self.hod.position).replace(
                                                                            "_user_name_", self.employee_id.full_name)
        values['email_from'] = self.user_id.email_formatted

        # GENERATE EMPLOYEE MAIL ID
        flag = 0
        for emp in self:
            if emp.employee_id:
                for communication in emp.employee_id.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        email = communication.value
                        flag += 1

        values['email_to'] = email
        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state': 'sent_to_supervisor',
        })

    def hr_approve(self):

        # send email to HR
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                     'exit_request_confirm_confirm_mail_template')

        values = email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_department_name_", self.human_resource.position).replace(
                                                                            "_user_name_", self.employee_id.full_name)

        values['email_from'] = self.user_id.email_formatted

        # GENERATE EMPLOYEE MAIL ID
        flag = 0
        for emp in self:
            if emp.employee_id:
                for communication in emp.employee_id.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        email = communication.value
                        flag += 1

        values['email_to'] = email

        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        # Disable employee from active employee list
        inactive_employment = self.env['hpl.employment'].search([('code', '=', 1)])
        self.employee_id.update({
            'employment': inactive_employment.id
        })
        # Archiving employee related user
        self.employee_id.user_id.active = False

        return self.write({
            'state': 'hr_approved'
        })

    def action_hr_reject(self):
        # SEND MAIL TO EMPLOYEE .
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                     'exit_request_confirm_reject_mail_template')

        values = email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_department_name_", self.human_resource.position).replace(
            "_user_name_", self.employee_id.full_name)
        values['email_from'] = self.user_id.email_formatted

        # GENERATE EMPLOYEE MAIL ID
        flag = 0
        for emp in self:
            if emp.supervisor:
                for employee_id in emp.employee_id.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        email = communication.value
                        flag += 1

        values['email_to'] = email
        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state': 'supervisor_approved',
        })

    def action_sent_immediate_supervisor(self):
        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                     'exit_request_supervisor_approved_template')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_act_window')

        values = email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                          request.httprequest.host_url + "web#id=" + str(
                                                              self.id) + "&view_type=form"
                                                                         "&model=exit.request&menu_id=" + str(
                                                              recruitment_menu.id) + "&action=" + str(
                                                              recruitment_action.id)).replace("_user_name_",
                                                                                          self.supervisor.full_name)
        values['email_from'] = self.user_id.email_formatted

        # generate HOD mail id
        flag = 0
        for emp in self:
            if emp.supervisor:
                for communication in emp.supervisor.communication_line:
                    if communication.communication_type_code == '0010' and flag == 0:
                        sup_email = communication.value
                        flag += 1

        values['email_to'] = sup_email

        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state': 'sent_immediate_supervisor',
        })

    def action_clearance_open(self):

        email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                     'exit_request_check_list_template')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_act_window')

        values = email_template.generate_email(self.id)

        values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                          request.httprequest.host_url + "web#id=" + str(
                                                              self.id) + "&view_type=form"
                                                                         "&model=exit.request&menu_id=" + str(
                                                              recruitment_menu.id) + "&action=" + str(
                                                              recruitment_action.id))
        values['email_from'] = self.user_id.email_formatted

        email_list = []

        for emp in self:
            if emp.clearance_person:
                for person in emp.clearance_person:
                    emails = self.emp_get_email(person)
                    email_list.append(emails)
        values['email_to'] = ','.join(map(str, email_list))
        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        self.write({
            'state': 'clearance_open',
        })

    @api.model
    def emp_get_email(self, emp_obj):
        if emp_obj:
            flag = 0
            for communication in emp_obj.communication_line:
                if communication.communication_type_code == '0010' and flag == 0:
                    email = communication.value
                    flag += 1
        return email

    def confirm(self):
        return self.write({
            'state': 'confirmed'
        })

class ExitRequestDocLine(models.Model):
    _name = "exit.request.doc.line"
    _description = "Exit Request Document Line"
    _rec_name = 'document_name'

    master_id = fields.Many2one('exit.request', string='Request', ondelete='restrict')
    document_name = fields.Char('Document Name')
    attachment_file_ids = fields.Many2many('ir.attachment', 'exit_request_ir_attachments_rel',
                                           'line_id',
                                           'attachment_id', string='Attachments', help="Attach files here")


class TempEmployeeInventoryLine(models.Model):
    _name = 'temp.employee.inventory.line'
    _description = 'Description'

    exit_request_id = fields.Many2one('exit.request')
    product_id = fields.Many2one('product.product', 'Product', ondelete="cascade", check_company=True,
                                 domain="[('type', '!=', 'service')]")
    qty_given = fields.Float(
        'Given Quantity', digits=0, store=True)

    return_product = fields.Selection([('yes', 'Yes'), ('no', 'No'), ], 'Return Product', default='no')
