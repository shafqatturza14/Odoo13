from odoo import fields, models, api


class FinalSettlementPFAccount(models.Model):
    _name = 'final.settlement.pf.account'
    _description = 'Final Settlement PF Account'
    _rec_name = 'pf_particular'

    pf_particular = fields.Char(string='Particular', required=True)
