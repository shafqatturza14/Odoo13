from odoo import fields, models, api


class FinalSettlementCompany(models.Model):
    _name = 'final.settlement.company'
    _description = 'Final Settlement Company'
    _rec_name = 'company_particular'

    company_particular = fields.Char(string='Particular', required=True)