from odoo import fields, models, api, _

from odoo.exceptions import UserError, ValidationError

from datetime import datetime, timedelta


class EmployeeInventoryReturn(models.Model):
    _name = 'employee.inventory.return'
    _description = 'Description'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('employee.inventory.return.sequence')
        res = super(EmployeeInventoryReturn, self).create(vals)

        print('entered into create method ')
        return res

    def write(self, vals):
        res = super(EmployeeInventoryReturn, self).write(vals)

        employee_inventory_return = self.env['employee.inventory.return'].browse(self.id)
        for rec in employee_inventory_return:
            stock_picking_type = self.env['stock.picking.type'].search([('code', '=', 'internal')],
                                                                       limit=1)
            base_location = self.env['stock.location'].search([('is_base_location', '=', True)],
                                                              limit=1)
            new_partner = self.employee_id.user_id.partner_id
            stock_picking_value = {
                'move_type': 'direct',
                'picking_type_id': stock_picking_type.id,
                'location_dest_id': base_location.id,
                'location_id': self.employee_id.destination_location_id.id,
                'partner_id': new_partner.id,
            }
            stock_picking_obj = self.env['stock.picking'].create(stock_picking_value)

            employee_exit_obj = self.env['exit.request'].search([('employee_id', '=', self.employee_id.id)],
                                                                limit=1)

            i = 0
            for line in rec.inventory_lines:
                employee_exit_obj.temp_inventory_line_ids[i].write(
                    {'exit_request_id': employee_exit_obj.id, 'product_id': line.product_id.id,
                     'qty_given': line.qty_given, 'return_product': 'no'})

                if line.return_product == 'yes':
                    dt_string = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    oo_stock_picking_value = {
                        'company_id': self.env.company.id,
                        'date': dt_string,
                        'date_expected': dt_string,
                        'location_dest_id': base_location.id,
                        'location_id': self.employee_id.destination_location_id.id,
                        'name': line.product_id.name,
                        'procure_method': 'make_to_stock',
                        'product_id': line.product_id.id,
                        'product_uom': 1,
                        'product_uom_qty': line.qty_given,
                        'quantity_done': line.qty_given,
                        'picking_id': stock_picking_obj.id,
                        'state': 'done',
                    }
                    # creating stock picking line
                    stock_move_create = self.env['stock.move'].create(oo_stock_picking_value)
                    stock_move_create.write({'state': 'done'})
                    employee_exit_obj.temp_inventory_line_ids[i].write({'return_product': 'yes'})
                i = i + 1

            stock_picking_obj.write({'state': 'done'})

        employee_exit_obj.write({'state': 'clear_it'})

        return res

    name = fields.Char(string="Inventory Reference ", readonly=True, copy=False,
                       default=lambda self: _('New'))

    employee_id = fields.Many2one('hr.employee', string="Employee")
    provided_inventory_date = fields.Date(string="Inventory Provided Date")
    returning_inventory_date = fields.Date(string="Inventory Return Date")
    inventory_lines = fields.One2many('employee.inventory.return.line', 'inventory_id', string="Products",
                                      required=True,
                                      copy=True)

    transfer_id = fields.Many2one('stock.picking', readonly=True, string="Transfer")


class EmployeeInventoryReturnLine(models.Model):
    _name = 'employee.inventory.return.line'
    _rec_name = "product_id"

    inventory_id = fields.Many2one('employee.inventory.return')

    product_id = fields.Many2one('product.product', 'Product', ondelete="cascade", check_company=True,
                                 domain="[('type', '!=', 'service')]")
    qty_given = fields.Float('Given Quantity', store=True)

    # qty_available = fields.Float('Available Quantity', store=True)

    return_product = fields.Selection([('yes', 'Yes'), ('no', 'No'), ], 'Return Product', default='no')
