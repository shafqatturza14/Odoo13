from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import date, datetime, timedelta
from odoo.http import request


class ExitRequest(models.Model):
    _name = 'emergency.exit.request'
    _description = 'Emergency Exit'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(compute='_compute_rec_name')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id)
    # employee_id = fields.Many2one('hr.employee', required=True, string="Employee", readonly=True,
    #                               default=lambda self: self.env.user.employee_id)
    employee_id = fields.Many2one('hpl.employee', required=True, string="Employee")
    # user_id = fields.Many2one(related='employee_id.user_id', string='User', readonly=True)

    employee_code = fields.Char(string='Employee ID', readonly=False, compute='_compute_employee_code')
    job_id = fields.Char('Designation', required=True, readonly=False, compute='_compute_employee_job_position')
    department_id = fields.Many2one('hr.department', 'Department', readonly=False, required=True,
                                    compute='_compute_employee_dept')
    section_id = fields.Many2one('hr.section', 'Section', readonly=False,
                                 compute='_compute_employee_section')
    contact_no = fields.Char('Contact No', readonly=False, compute='_compute_employee_contact')
    emp_joining_str = fields.Char('Date of Joining', compute='_compute_employee_joining_date')
    is_replacement_available = fields.Boolean('Is Replacement Available', default=False)
    separation_type = fields.Selection(selection=[
        ('voluntary', 'Voluntary'),
        ('nonvoluntary', 'Non-Voluntary')], required=True, string='Separation Type',
        help='')

    state = fields.Selection(
        [('draft', 'Draft'), ('confirmed', 'Confirmed'),
         ], string='State',
        default='draft')

    @api.depends('employee_id')
    def _compute_employee_code(self):
        for emp in self:
            if emp.employee_id.employee_id:
                emp.employee_code = emp.employee_id.employee_id
            else:
                emp.employee_code = ''

    @api.depends('employee_id')
    def _compute_employee_user(self):
        for emp in self:
            if emp.employee_id.user_id:
                emp.employee_user_id = emp.employee_id.user_id
            else:
                raise UserError(_('Employee related user not found. Edit this employee details'))

    @api.depends('employee_id', 'employee_code')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = str(emp.employee_id.full_name) + '-' + str(emp.employee_code)

    @api.depends('employee_id')
    def _compute_employee_job_position(self):
        for emp in self:
            if emp.employee_id.position_name:
                emp.job_id = emp.employee_id.position_name
            else:
                emp.job_id = ''

    @api.depends('employee_id')
    def _compute_employee_dept(self):
        for emp in self:
            if emp.employee_id.department:
                emp.department_id = emp.employee_id.department.id
            else:
                emp.department_id = ''

    @api.depends('employee_id')
    def _compute_employee_section(self):
        for emp in self:
            if emp.employee_id.section:
                emp.section_id = emp.employee_id.section.id
            else:
                emp.section_id = ''

    @api.depends('employee_id')
    def _compute_employee_contact(self):
        phone_flag = 0
        for emp in self:
            if emp.employee_id:
                for communication in emp.employee_id.communication_line:
                    if communication.communication_type_code == 'CELL' and phone_flag == 0:
                        emp.contact_no = communication.value
                        phone_flag += 1
                    elif communication.communication_type_code == '0004' and phone_flag == 0:
                        emp.contact_no = communication.value
                        phone_flag += 1

            else:
                emp.contact_no = ''

    @api.depends('employee_id')
    def _compute_employee_joining_date(self):
        for emp in self:
            if emp.employee_id.start_date:
                joining_date = emp.employee_id.start_date
                emp.emp_joining_str = joining_date.strftime("%b %d, %Y")
            else:
                emp.emp_joining_str = ''



    def action_confirm(self):
        self.write({
            'state': 'confirmed'
        })
        print("employe--", self.employee_id.active)
        self.employee_id.active = False
