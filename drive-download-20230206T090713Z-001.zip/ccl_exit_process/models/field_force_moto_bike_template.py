from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class FieldForceMotorBikeTemplate(models.Model):
    _name = 'field.force.moto.bike.template'
    _description = 'Field Force MotorBike Template'

    name = fields.Char(string='Name', required=True)

    template_lines = fields.One2many('field.force.moto.bike.template.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):

        length = len(vals['template_lines'])

        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['particulars']}")
            if not vals['template_lines'][i][2]['particulars']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(FieldForceMotorBikeTemplate, self).create(vals)

        return rec


class FieldForceMotoBikeTemplateLine(models.Model):
    _name = 'field.force.moto.bike.template.line'
    _description = 'Template Line'

    template_id = fields.Many2one('field.force.moto.bike.template', 'Template')
    sl = fields.Char(string='SL')
    particulars = fields.Char(string='Particulars', required=True)
