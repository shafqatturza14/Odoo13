# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from odoo.http import request
from odoo.exceptions import UserError


class FinanceApproval(models.TransientModel):
    _name = 'exit.finance.approval'

    exit_id = fields.Many2one(
        'exit.request',
        default=lambda self: self._default_exit_request(),
        required=True
    )

    current_user = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.user)

    financial_outstanding = fields.Float(string='Financial Outstanding')

    state = fields.Selection(
        [('draft', 'Draft'), ('sent_to_hod', 'Send to HoD'),
         ('hod_approved', 'HoD Approved'), ('sent_to_it', 'Send to IT'),
         ('clear_it', 'Clear from IT'), ('sent_to_finance', 'Send to Finance'),
         ('clear_finance', 'Clear from Finance'),
         ('sent_to_hr', 'Send to HR'), ('hr_approved', 'HR Approved'),
         ('confirmed', 'Confirmed'),
         ], string='State', related='exit_id.state')

    def _default_exit_request(self):
        return self.env['exit.request'].browse(self.env.context.get(
            'active_id'))

    def send_email(self):

        # send email to HOD

        # get department HOD
        hod_email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_finance_approved_template_')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_act_window')


        values = hod_email_template.generate_email(self.exit_id.id)

        values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                          request.httprequest.host_url + "web#id=" + str(
                                                              self.exit_id.id) + "&view_type=form"
                                                                                 "&model=exit.request&menu_id=" + str(
                                                              recruitment_menu.id) + "&action=" + str(
                                                              recruitment_action.id)).replace("_user_name_",
                                                                                              self.exit_id.employee_id.employee_department_head.name)
        values['email_from'] = self.current_user.email_formatted
        if self.exit_id.employee_id.work_email:

            values['email_to'] = self.exit_id.employee_id.work_email
        else:
            raise UserError(_('Employee Work Email not found.'))
        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()

        return self.exit_id.write({
            'financial_outstanding': self.financial_outstanding,
            'state': 'clear_finance'
        })
