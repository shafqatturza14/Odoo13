# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from odoo.http import request
from odoo.exceptions import UserError


class ExitEmployeeConfirm(models.TransientModel):
    _name = 'exit.employee.confirm'

    exit_id = fields.Many2one(
        'exit.request',
        default=lambda self: self._default_exit_request(),
        required=True
    )

    current_user = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.user)

    def _default_exit_request(self):
        return self.env['exit.request'].browse(self.env.context.get(
            'active_id'))

    def send_email(self):
        # send email to HOD
        # get department HOD
        hod_email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_confirm_exit_hr_template_')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_act_window')

        users = self.env.ref('ccl_exit_process.group_exit_hr_manager').users.ids
        if users:
            for user in users:
                user_id = self.env['res.users'].browse(user)

                values = hod_email_template.generate_email(self.exit_id.id)

                values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                                  request.httprequest.host_url + "web#id=" + str(
                                                                      self.exit_id.id) + "&view_type=form"
                                                                                         "&model=exit.request&menu_id=" + str(
                                                                      recruitment_menu.id) + "&action=" + str(
                                                                      recruitment_action.id)).replace(
                    "_user_name_",
                    user_id.name)
                values['email_from'] = self.current_user.email_formatted

                values['email_to'] = user_id.login

                send_mail = self.env['mail.mail'].create(values)
                send_mail.send()
        else:
            raise UserError(_('HR group user not set'))

        # Archiving employee
        self.sudo().exit_id.employee_id.active = False
        # Archiving employee related user
        self.sudo().exit_id.employee_id.user_id.active = False

        return self.exit_id.write({
            'state': 'confirmed'
        })
