# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from odoo.http import request
from odoo.exceptions import UserError


class ExitSubmitHOD(models.TransientModel):
    _name = 'exit.submit.hod'

    exit_id = fields.Many2one(
        'exit.request',
        default=lambda self: self._default_exit_request(),
        required=True
    )

    current_user = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.user)

    def _default_exit_request(self):
        return self.env['exit.request'].browse(self.env.context.get(
            'active_id'))

    def send_email(self):

        # send email to HOD

        # get department HOD
        hod_email_template = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_sent_to_hod_template_')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                       'exit_request_menu')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('ccl_exit_process',
                                                                         'exit_request_act_window')

        employee_obj = self.env['hr.employee'].browse(self.exit_id.employee_id.id)

        if employee_obj.employee_department_head:
            manager_user_id = employee_obj.employee_department_head.user_id

            values = hod_email_template.generate_email(self.exit_id.id)

            values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                              request.httprequest.host_url + "web#id=" + str(
                                                                  self.exit_id.id) + "&view_type=form"
                                                                                     "&model=exit.request&menu_id=" + str(
                                                                  recruitment_menu.id) + "&action=" + str(
                                                                  recruitment_action.id)).replace("_user_name_",
                                                                                                  manager_user_id.name)
            values['email_from'] = self.current_user.email_formatted

            values['email_to'] = manager_user_id.login

            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()
        else:
            raise UserError(_('Department HoD not set'))

        return self.exit_id.write({
            'state': 'sent_to_hod',
        })
