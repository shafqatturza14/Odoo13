from odoo import models
import datetime


class InterviewReportXLSX(models.AbstractModel):
    _name = 'report.ccl_exit_process.report_exit_interview_summary_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, rows):
        report_name = 'Sheet1'
        sheet = workbook.add_worksheet(report_name)
        bold = workbook.add_format({'font_size': 8, 'bg_color': '#1B75D5', 'color': 'white', 'bold': False,
                            'left':1, 'border_color': 'black', 'align': 'center',  'rotation': '90', 'text_wrap': True})
        bold.set_align('vcenter')
        normal = workbook.add_format({'font_size': 8})

        # sheet.write(1, 3, 'Employee Name', bold)

        label_names = [
            'SAP ID', 'Lagacy ID', 'Name', 'Job', 'Organizational Unit/Sub Section', 'Personnel Subarea',
            'Employee Subgroup', 'Leaving', 'Joining Date', 'Duration', 'Reason ', 'Category ', 'Month ',
            'Year', 'Replaced By', 'Clarity of Responsibility', 'Better job opportunity', 'Type of work',
            'Rate of pay', 'Self-employment', 'Return to studies',
            'Supervision', 'Commuting distance', 'Advancement un-encouraging', 'Excessive job pressure',
            'Working conditions', 'Travel reasons', 'Inadequate training', 'Family circumstances',
            'Illness or physical condition', 'Others', 'Like Least-1', 'Like Least-2', 'Like Least-3', 'Interesting',
            'Challenging', 'Simple', 'Uninspiring', 'Restrictive', 'Rewarding', 'Future in HPL (Company)',
            'Future in HPL (Same Department)', 'Future in HPL (Same Boss)', 'Fair and equal treatment',
            'Recognition on the job', 'Co-operation and team work ', 'Resolve complaints & problems',
            'Training & Development', 'Communication with employees', 'Communication within dept', 'On-the-job training'
            , 'Rate of pay for your job', 'Employee benefit', 'Chances for advancement', 'Access to information',
            'Acceptance of new ideas', 'Relationship-supervisors/peers', 'Supervisor Knowledge', 'Resigned Check'
        ]

        # label_names = [
        #     'SAP ID', 'Lagacy ID', 'Name', 'Job', 'Organizational Unit/Sub Section', 'Personnel Subarea',
        #     'Employee Subgroup', 'Leaving', 'Joining Date', 'Duration', 'Reason ', 'Category '
        #
        # ]

        for i, label in enumerate(label_names):
            sheet.write(0, i, label, bold)
            sheet.set_row(0, 100)
            sheet.set_column(0, 13, 15)
            sheet.set_column(31, 33, 10)
            sheet.set_column(15, 31, 4)
            sheet.set_column(34, 57, 4)

        for i, item in enumerate(rows, start=1):
            resign_date = item.resignation_date
            joining_date = item.emp_joining_date
            join_date = joining_date.strftime("%d-%m-%Y")
            leaving_date = resign_date.strftime("%d-%m-%Y")
            job_responsibility = ''
            better_job = ''
            work_type = ''
            if item.can_explained_job_responsibility == 'yes':
                job_responsibility = 'Yes'
            elif item.can_explained_job_responsibility == 'no':
                job_responsibility = 'No'
            elif item.can_explained_job_responsibility == 'uncertain':
                job_responsibility = 'Uncertain'

            if item.job_opportunity == 1:
                better_job = 'Yes'
            else:
                better_job = 'No'

            if item.work_type == 1:
                work_type = 'Yes'
            else:
                work_type = 'No'

            if item.rate_pay == 1:
                rate_pay = 'Yes'
            else:
                rate_pay = 'No'

            if item.self_employment == 1:
                self_employment = 'Yes'
            else:
                self_employment = 'No'

            if item.return_studies == 1:
                return_studies = 'Yes'
            else:
                return_studies = 'No'

            if item.supervision == 1:
                supervision = 'Yes'
            else:
                supervision = 'No'

            if item.commuting_distance == 1:
                commuting_distance = 'Yes'
            else:
                commuting_distance = 'No'

            if item.un_encouraging == 1:
                un_encouraging = 'Yes'
            else:
                un_encouraging = 'No'

            if item.job_pressure == 1:
                job_pressure = 'Yes'
            else:
                job_pressure = 'No'

            if item.working_conditions == 1:
                working_conditions = 'Yes'
            else:
                working_conditions = 'No'

            if item.travel_reasons == 1:
                travel_reasons = 'Yes'
            else:
                travel_reasons = 'No'

            if item.inadequate_training == 1:
                inadequate_training = 'Yes'
            else:
                inadequate_training = 'No'

            if item.family_circumstances == 1:
                family_circumstances = 'Yes'
            else:
                family_circumstances = 'No'

            if item.illness == 1:
                illness = 'Yes'
            else:
                illness = 'No'

            if item.interesting == 1:
                interesting = 'Yes'
            else:
                interesting = 'No'

            if item.challenging == 1:
                challenging = 'Yes'
            else:
                challenging = 'No'

            if item.simple == 1:
                simple = 'Yes'
            else:
                simple = 'No'
            if item.uninspiring == 1:
                uninspiring = 'Yes'
            else:
                uninspiring = 'No'

            if item.restrictive == 1:
                restrictive = 'Yes'
            else:
                restrictive = 'No'

            if item.rewarding == 1:
                rewarding = 'Yes'
            else:
                rewarding = 'No'

            if item.return_to_company == 'yes':
                same_company = 'Yes'
            elif item.return_to_company == 'no':
                same_company = 'No'
            else:
                same_company = ''

            if item.return_to_department == 'yes':
                same_dept = 'Yes'
            elif item.return_to_department == 'no':
                same_dept = 'No'
            else:
                same_dept = ''

            if item.same_boss == 'yes':
                same_boss = 'Yes'
            elif item.same_boss == 'no':
                same_boss = 'No'
            else:
                same_boss = ''

            equal_treatment = ''
            recognition = ''
            cooperation = ''
            complaints = ''
            training = ''
            communication = ''
            department = ''
            job_training = ''
            pay_rate = ''
            benefit = ''
            advantage = ''
            information = ''
            management = ''
            relationship = ''
            for line in item.exit_interview_rate_template_lines:
                if line.criteria_id.criteria == 'Fair and equal treatment by management':
                    if line.first:
                        equal_treatment = line.first
                    elif line.second:
                        equal_treatment = line.second
                    elif line.third:
                        equal_treatment = line.third
                    elif line.fourth:
                        equal_treatment = line.fourth
                    elif line.fifth:
                        equal_treatment = line.fifth

                elif line.criteria_id.criteria == 'Company provides recognition on the job':
                    if line.first:
                        recognition = line.first
                    elif line.second:
                        recognition = line.second
                    elif line.third:
                        recognition = line.third
                    elif line.fourth:
                        recognition = line.fourth
                    elif line.fifth:
                        recognition = line.fifth

                elif line.criteria_id.criteria == 'Development of cooperation and team work':
                    if line.first:
                        cooperation = line.first
                        print("first----------", cooperation)
                    elif line.second:
                        cooperation = line.second
                        print("first----------", cooperation)
                    elif line.third:
                        cooperation = line.third
                        print("first----------", cooperation)
                    elif line.fourth:
                        cooperation = line.fourth
                        print("first----------", cooperation)
                    elif line.fifth:
                        cooperation = line.fifth
                        print("first----------", cooperation)

                elif line.criteria_id.criteria == 'Resolving complaints and problems':
                    if line.first:
                        complaints = line.first
                    elif line.second:
                        complaints = line.second
                    elif line.third:
                        complaints = line.third
                    elif line.fourth:
                        complaints = line.fourth
                    elif line.fifth:
                        complaints = line.fifth

                elif line.criteria_id.criteria == 'Development of employees by training':
                    if line.first:
                        training = line.first
                    elif line.second:
                        training = line.second
                    elif line.third:
                        training = line.third
                    elif line.fourth:
                        training = line.fourth
                    elif line.fifth:
                        training = line.fifth

                elif line.criteria_id.criteria == 'Company communication with employees':
                    if line.first:
                        communication = line.first
                    elif line.second:
                        communication = line.second
                    elif line.third:
                        communication = line.third
                    elif line.fourth:
                        communication = line.fourth
                    elif line.fifth:
                        communication = line.fifth

                elif line.criteria_id.criteria == 'Communication within your department':
                    if line.first:
                        department = line.first
                    elif line.second:
                        department = line.second
                    elif line.third:
                        department = line.third
                    elif line.fourth:
                        department = line.fourth
                    elif line.fifth:
                        department = line.fifth

                elif line.criteria_id.criteria == 'On-the-job training':
                    if line.first:
                        job_training = line.first
                    elif line.second:
                        job_training = line.second
                    elif line.third:
                        job_training = line.third
                    elif line.fourth:
                        job_training = line.fourth
                    elif line.fifth:
                        job_training = line.fifth

                elif line.criteria_id.criteria == 'Rate of pay for your job':
                    if line.first:
                        pay_rate = line.first
                    elif line.second:
                        pay_rate = line.second
                    elif line.third:
                        pay_rate = line.third
                    elif line.fourth:
                        pay_rate = line.fourth
                    elif line.fifth:
                        pay_rate = line.fifth

                elif line.criteria_id.criteria == 'Employee benefit':
                    if line.first:
                        benefit = line.first
                    elif line.second:
                        benefit = line.second
                    elif line.third:
                        benefit = line.third
                    elif line.fourth:
                        benefit = line.fourth
                    elif line.fifth:
                        benefit = line.fifth

                elif line.criteria_id.criteria == 'Chances for advancement':
                    if line.first:
                        advantage = line.first
                    elif line.second:
                        advantage = line.second
                    elif line.third:
                        advantage = line.third
                    elif line.fourth:
                        advantage = line.fourth
                    elif line.fifth:
                        advantage = line.fifth

                elif line.criteria_id.criteria == 'Access to information needed to do your job':
                    if line.first:
                        information = line.first
                    elif line.second:
                        information = line.second
                    elif line.third:
                        information = line.third
                    elif line.fourth:
                        information = line.fourth
                    elif line.fifth:
                        information = line.fifth

                elif line.criteria_id.criteria == 'Receptivity of management to your ideas':
                    if line.first:
                        management = line.first
                    elif line.second:
                        management = line.second
                    elif line.third:
                        management = line.third
                    elif line.fourth:
                        management = line.fourth
                    elif line.fifth:
                        management = line.fifth

                elif line.criteria_id.criteria == 'Relationship with supervisors/peers':
                    if line.first:
                        relationship = line.first
                    elif line.second:
                        relationship = line.second
                    elif line.third:
                        relationship = line.third
                    elif line.fourth:
                        relationship = line.fourth
                    elif line.fifth:
                        relationship = line.fifth

            data_list = [
                    item.employee_code or '',  # 'SAP ID'
                    item.employee_code or '',  # 'Lagacy ID'
                    item.employee_id.full_name or '',  # 'Employee Name'
                    item.employee_id.position_name or '',  # 'Designation'
                    item.employee_id.section.name or '',  # 'Section'
                    item.employee_id.personal_sub_area.name or '',  # 'Sub Area'
                    item.employee_id.employee_sub_group.name or '',  # 'Sub Group'
                    leaving_date or '',  # 'Resign Date'
                    join_date or '',  # 'Join Date'
                    item.job_duration or '',  # 'Job Duration'
                    item.reason or '',  # 'Reason'
                    item.Category or '',  # 'Category'
                    item.resignation_date.month or '',  # 'Month'
                    item.resignation_date.year or '',  # 'Year'
                    item.replaced_by or '',  # 'Replaced By'
                    job_responsibility or '',  # 'Clarity of Responsibility'
                    better_job or '',  # 'Better job opportunity'
                    work_type or '',  # 'Type of work'
                    rate_pay or '',  # 'Pay to Rate'
                    self_employment or '',  # 'Self-employment'
                    return_studies or '',  # 'Return to studies'
                    supervision or '',  # 'supervision'
                    commuting_distance or '',  # 'Commuting distance'
                    un_encouraging or '',  # 'Advancement un-encouraging'
                    job_pressure or '',  # 'Excessive job pressure'
                    working_conditions or '',  # 'Working conditions'
                    travel_reasons or '',  # 'Travel reasons'
                    inadequate_training or '',  # 'inadequate training'
                    family_circumstances or '',  # 'family circumstances'
                    illness or '',  # 'Illness or physical condition'
                    item.other_specify or '',  # 'Other'
                    '' or '',  # 'Like Least-1'
                    '' or '',  # 'Like Least-2'
                    '' or '',  # 'Like Least-3'
                    interesting or '',  # 'Interesting'
                    challenging or '',  # 'Challenging'
                    simple or '',  # 'simple'
                    uninspiring or '',  # 'uninspiring'
                    restrictive or '',  # 'restrictive'
                    rewarding or '',  # 'rewarding'
                    same_company or '',  # 'same Company'
                    same_dept or '',  # 'same department'
                    same_boss or '',  # 'same boss'
                    equal_treatment or '',  # 'Fair and equal treatment'
                    recognition or '',  # 'recognition'
                    cooperation or '',  # 'cooperation'
                    complaints or '',  # 'complaints'
                    training or '',  # 'training'
                    communication or '',  # 'communication'
                    department or '',  # 'department'
                    job_training or '',  # 'job_training'
                    pay_rate or '',  # 'pay_rate'
                    benefit or '',  # 'benefit'
                    advantage or '',  # 'advantage'
                    information or '',  # 'information'
                    management or '',  # 'management'
                    relationship or '',  # 'relationship'
                    item.supervision_guide_comment or '',  # 'relationship'

                ]
            for j, data_item in enumerate(data_list):
                sheet.write(i, j, data_item, normal)
