# -*- coding: utf-8 -*-
{
    'name': "Exit Process",

    'summary': """""",
    'support': 'shoaib.cse.27@gmail.com',
    'description': """
        Long description of module's purpose
    """,

    'author': "Shoaib Ahmed",
    'website': "",

    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'hr', 'hpl_employee'],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/menus.xml',
        'data/sequence.xml',
        'data/request_email.xml',
        'views/exit_request_view.xml',
        'wizard/submit_hod.xml',
        'wizard/hod_approval.xml',
        'wizard/supervisor_approval_view.xml',
        'wizard/submit_it.xml',
        'wizard/it_approval.xml',
        'wizard/submit_finance.xml',
        'wizard/finance_approval.xml',
        'wizard/submit_hr_manager.xml',
        'wizard/hr_approval.xml',
        'wizard/exit_confirm.xml',
        'report/employee_exit_form_report.xml',
        'report/emergency_exit_checklist_report.xml',
        'report/exit_experience_letter_pdf.xml',
        'report/exit_interview_report.xml',
        'report/exit_report_field_force.xml',
        'report/final_settlement_report.xml',
        'report/paperformat.xml',
        'report/report.xml',
        'views/employee_inventory_return_view.xml',
        'views/emergency_exit_views.xml',
        'views/exit_interview_view.xml',
        'views/exit_interview_view.xml',
        'views/interview_rate_criteria_views.xml',
        'views/interview_rate_template_views.xml',
        'views/exit_final_settlement_views.xml',
        'views/final_settlement_company_views.xml',
        'views/final_settlement_pf_views.xml',
        'views/final_settlement_summary_views.xml',
        'views/final_settlement_company_template_views.xml',
        'views/final_settlement_summary_template_views.xml',
        'views/final_settlement_pf_template_views.xml',
        'views/exit_request_field_force.xml',
        'views/exit_request_checklist_permission.xml',
        'views/emergency_exit_checklist_permission.xml',
        'views/field_force_particular_view.xml',
        'views/second_field_force_particular_template_view.xml',
        'views/field_force_motorbike_template_view.xml',

    ],

}
