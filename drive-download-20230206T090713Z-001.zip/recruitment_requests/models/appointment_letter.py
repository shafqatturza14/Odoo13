# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class AppointmentLetter(models.Model):
    _name = 'appointment.letter'
    _description = 'Appointment Letter'
    _rec_name= 'job_name'

    job_name = fields.Many2one('hr.job', string='Job Name')
    salary_structure = fields.Many2one('salary.structure.template', default=lambda self: self._default_template_id(),
                                       string='Salary Structure Template')

    def _default_template_id(self):
        return self.env['salary.structure.template'].search([], limit=1)

    applicant_line = fields.One2many('confirmed.applicant', 'appointment_id',
                                     string='Applicant Line')

    @api.onchange('job_name')
    def confirmed_applicant_fetch(self):
        for rec in self:
            applicants = self.env['hr.applicant'].search([('job_id', '=', rec.job_name.id),
                                                          ('stage_id', '=', 4)])
            print('Applicants:', applicants)
            lines = [(5, 0, 0)]
            for line in applicants:
                val = {
                    'applicant_id': line.id,
                    'name': line.partner_name,
                    'email': line.email_from,
                }
                lines.append((0, 0, val))
            rec.applicant_line = lines


class ConfirmedApplicant(models.Model):
    _name = 'confirmed.applicant'
    _description = 'Confirmed Applicant'

    appointment_id = fields.Many2one('appointment.letter', string='Appointment Id')
    applicant_id = fields.Many2one('hr.applicant', string='Applicant Id')
    name = fields.Char(string='Name')
    email = fields.Char(string='Email')
    salary = fields.Integer(string='Salary', default=None)
    salary_in_word = fields.Char(string='Salary In Word')
    joining_date = fields.Date(string='Joining Date')
    reporting_person = fields.Many2one('hpl.employee', string='Reporting Person')
    letter_sent = fields.Boolean(string='Sent', default=False)


class SalaryStructureTemplate(models.Model):
    _name = 'salary.structure.template'
    _description = 'Salary Structure Template'

    code = fields.Char(string='Code')
    name = fields.Char(string='Name')
    temp_line = fields.One2many('salary.structure.template.line', 'line_id', string='Template Line')


class SalaryStructureTemplateLine(models.Model):
    _name = 'salary.structure.template.line'
    _description = 'Salary Structure Template Line'

    line_id = fields.Many2one('salary.structure.template', string='Line Id')
    component = fields.Char(string='Component')
    rule = fields.Char(string='Rule')



