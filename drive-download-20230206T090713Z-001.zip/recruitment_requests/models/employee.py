# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    request_id = fields.Many2one('hr.recruitment.request', string='Enrolment Request', store=True)

    @api.model
    def create(self, vals):
        vals['state'] = 'recruited'
        res = super(HrEmployee, self).create(vals)

        # mail to IT user about employee creation

        # create stock location for this employee
        parent_location_id = self.env["stock.location"].browse(7)
        print(f"parent location id {parent_location_id}")
        location_values = {
            "employee_id": res.id,
            "is_base_location": False,
            "usage": 'internal',
            "name": "Location : " + res.name + "/" + res.employee_code
        }
        location_obj = self.env["stock.location"].create(location_values)
        print(f"location id {location_obj}")

        self.env.cr.execute("UPDATE hr_employee SET destination_location_id = %s WHERE id = %s",
                            [location_obj.id, res.id])

        return res

    # @api.model
    # def write(self, vals):
    #     if vals['probation_period_enabled'] == 'Yes':
    #         vals['assessment_date'] = vals['probation_end_date']
    #     res = super(HrEmployee, self).write(vals)
    #     return res
