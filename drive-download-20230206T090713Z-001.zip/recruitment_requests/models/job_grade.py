from odoo import fields, models, api


class HrJobGrade(models.Model):
    _name = 'employee.job.grade'

    name = fields.Char(string='Name', required=True)
