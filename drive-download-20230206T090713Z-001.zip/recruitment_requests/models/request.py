# -*- coding: utf-8 -*-

from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta
from odoo.http import request


class HrRecruitmentRequest(models.Model):
    _name = 'hr.recruitment.request'
    _description = "Recruitment Request"
    _rec_name = 'rr_name'

    rr_name = fields.Char('Recruitment Ref', readonly=True)
    name = fields.Text(string="Subject", required=True)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)
    department_id = fields.Many2one('hr.department', string="Department", required=True,
                                    domain=lambda self: self.get_requested_employee_department())
    job_id = fields.Many2one('hr.job', string="Requested Position", required=True)
    # job_tmp = fields.Char(string="Requested Position")
    employees_count = fields.Integer(string="# of employees", compute='get_employees_count')
    expected_employees = fields.Integer(string="No. of resources to be hired", required=True, default=1)
    date_expected = fields.Date(string="Request Date", required=True, default=datetime.now().date())
    user_id = fields.Many2one('res.users', string="Requested By", readonly=True, default=lambda self: self.env.user)
    approver_id = fields.Many2one('res.users', string="Confirmed By", readonly=True)
    # refused_by = fields.Many2one('res.users', string="Refused By", readonly=True)
    applicants_count = fields.Integer('# of Application', compute='get_applicants_count')
    position_justification = fields.Text(string="Position Justification", required=True)
    description = fields.Text(string="Job Description", required=True)

    state = fields.Selection(
        [('draft', 'Draft'), ('sent_to_hod', 'Send to HoD'), ('hod_approved', 'HoD Approved'),
         ('sent_to_hr', 'Send to HR'),
         ('hr_approved', 'HR Approved'), ('sent_to_md', 'Send to MD'), ('md_approved', 'MD Approved'),
         ('md_rejected', 'MD Rejected'), ('accepted', 'Confirmed'),
         ('refused', 'Refused'), ('confirmed', 'Waiting Approval'),
         ('recruiting', 'In Recruitment'), ('done', 'Done'),
         ], string='State',
        default='draft')

    applicant_ids = fields.One2many('hr.applicant', 'request_id', string='Applicant', readonly=True)

    employee_ids = fields.One2many('hr.employee', 'request_id', string="Recruited Employees", readonly=True)
    recruited_employees = fields.Integer('Recruited Percentage', compute='get_recruited_employees_percentage')
    # existing_job = fields.Selection([('Yes', 'Yes'), ('No', 'No')], string='Existing Job Position', required=True)
    # submit_manager = fields.Many2many('res.users','manager_user_rel','id','user_id', string='Manager')

    proposed_job_grade = fields.Many2one('employee.job.grade', string="Proposed Job Grade")
    reason_for_request = fields.Selection(
        [('Budget', 'Budget'), ('Replacement', 'Replacement'), ('Additional', 'Additional')],
        string='Reason for Request')
    upper_salary_range = fields.Float()
    lower_salary_range = fields.Float()
    attainment_requirements = fields.Text(string="Educational Qualifications", help='Educational Qualifications')
    attainment_experience = fields.Text(string="Experience Required")
    attainment_circumstances = fields.Text(string="Circumstances", help='Any special requirements for the job, such '
                                                                        'Certificate; Licenses, etc. ')

    second_tier_hod_id = fields.Many2one('res.users', string="Second Tier HOD", readonly=True)
    hod_id = fields.Many2one('res.users', string="HoD", readonly=True)
    hr_id = fields.Many2one('res.users', string="HR", readonly=True)
    md_id = fields.Many2one('res.users', string="MD", readonly=True)

    hod_comment = fields.Text(string="HoD Comments")

    hr_comment = fields.Text(string="HR Comments")

    md_comment = fields.Text(string="MD Comments")

    md_reject_reason = fields.Text(string="MD Reject Reason")

    hr_confirmation_comment = fields.Text(string="HR Confirmation Comment")
    current_user = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.user)

    # @api.onchange('existing_job')
    # def update_job(self):
    #     for res in self:
    #         res.job_id = False
    #         res.job_tmp = False

    # @api.multi
    def get_recruited_employees_percentage(self):
        for percentage in self:
            percentage.recruited_employees = (percentage.employees_count / percentage.expected_employees) * 100

    def get_applicants_count(self):
        for applicants in self:
            applicants.applicants_count = len(applicants.applicant_ids.ids)

    def get_employees_count(self):
        for employee in self:
            employee.employees_count = len(employee.employee_ids.ids)

    @api.model
    def create(self, V):
        seq = self.env['ir.sequence'].next_by_code('hr.recruitment.request') or '/'
        V['rr_name'] = seq

        # send mail to HOD that request has been created
        # send main to Second HOD that your request submit to HOD

        return super(HrRecruitmentRequest, self).create(V)

    def get_requested_employee_department(self):
        department = False
        if self.env.user in self.env.ref('hr_recruitment.group_hr_recruitment_manager').users:
            department = self.env['hr.department'].search([]).ids
        else:
            department = []
            employee_department = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)])
            department.append(employee_department.department_id.id)
            department_object = self.env['hr.department'].search([('manager_id.user_id', '=', self.env.user.id)])
            department.append(department_object.id)
        return [('id', 'in', department)]

    # @api.onchange('department_id', 'existing_job')
    # def get_requested_position(self):
    #     position = {}
    #     if self.department_id:
    #         job_object = self.env['hr.job'].search([('department_id', '=', self.department_id.id)])
    #         if job_object:
    #             position['domain'] = {'job_id': [('id', 'in', job_object.ids)]}
    #     else:
    #         position['domain'] = {'job_id': [('id', 'in', [])]}
    #     return position

    @api.onchange('department_id')
    def update_job_id(self):
        self.job_id = False

    @api.onchange('job_id', 'department_id')
    def get_job_description(self):
        if self.job_id:
            self.description = self.job_id.description
        else:
            self.description = False

    # HOD Second Tier will submit request to HOD

    def action_submit_to_hod_(self):
        return {
            'name': 'Submit to HoD',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'submit.hod',
            'target': 'new',
        }

    # HOD / HOD Second Tier will fill up request and approve

    def hod_approve(self):
        # self.write({
        #     'state': 'hod_approved',
        # })
        return {
            'name': 'HoD Approval',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'hod.approval',
            'target': 'new',
        }

    # HOD will submit request to HR

    def action_submit_to_hr_(self):
        return {
            'name': 'Submit to HR',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'submit.hr.manager',
            'target': 'new',
        }

    # HR will approve
    def hr_approve(self):
        # self.write({
        #     'state': 'hr_approved',
        # })
        return {
            'name': 'HR Approval',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'hr.approval',
            'target': 'new',
        }

    # HR will send request to MD

    def action_submit_to_md_(self):
        return {
            'name': 'Submit to MD',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'submit.md',
            'target': 'new',
        }

    # HR will approve
    def hr_approve(self):
        # self.write({
        #     'state': 'hr_approved',
        # })
        return {
            'name': 'HR Approval',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'hr.approval',
            'target': 'new',
        }

    # MD will approve

    def md_approve(self):
        return {
            'name': 'MD Approval',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'md.approval',
            'target': 'new',
        }

    # MD will reject
    def md_reject(self):
        return {
            'name': 'MD Rejection',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'md.rejection',
            'target': 'new',
        }

    # action for start recruitment
    def action_accept_request(self):
        if not self.job_id:
            return {
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'start.recruiting.process',
                'target': 'new',
            }
        else:
            job_request_object = self.env['hr.job'].search([('id', '=', self.job_id.id)])
            if job_request_object.state == 'open':
                return self.write({'md_id': self.current_user, 'state': 'accepted'})
            else:
                # raise ValidationError("An existing request for this job position already in queue")
                raise ValidationError(
                    "Job recruitment process in progress related to respective job position.First Complete that one "
                    "then start a new hiring process.")

    def action_draft(self):
        self.write({
            'state': 'draft',
        })

    def action_done(self):

        start_recruiting_template = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                                'recruitment_done_template')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('hr_recruitment',
                                                                       'menu_hr_recruitment_root')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                         'action_hr_recruitment_request')

        second_tier_hod_id = self.env['res.users'].browse(self.second_tier_hod_id.id)
        hod_id = self.env['res.users'].browse(self.hod_id.id)
        md_id = self.env['res.users'].browse(self.md_id.id)
        hr_id = self.env['res.users'].browse(self.hr_id.id)

        if hr_id and md_id and second_tier_hod_id and hod_id:
            values = start_recruiting_template.generate_email(self.id)

            # MD

            values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                              request.httprequest.host_url + "web#id=" + str(
                                                                  self.id) + "&view_type=form"
                                                                                            "&model=hr.recruitment.request&menu_id=" + str(
                                                                  recruitment_menu.id) + "&action=" + str(
                                                                  recruitment_action.id)).replace("_user_name_",
                                                                                                  md_id.name)

            values['email_to'] = md_id.login

            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()

            # HR Manager

            values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                              request.httprequest.host_url + "web#id=" + str(
                                                                  self.id) + "&view_type=form"
                                                                                            "&model=hr.recruitment.request&menu_id=" + str(
                                                                  recruitment_menu.id) + "&action=" + str(
                                                                  recruitment_action.id)).replace("_user_name_",
                                                                                                  hr_id.name)

            values['email_to'] = hr_id.login

            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()
            # Second Tier HOD

            values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                              request.httprequest.host_url + "web#id=" + str(
                                                                  self.id) + "&view_type=form"
                                                                                            "&model=hr.recruitment.request&menu_id=" + str(
                                                                  recruitment_menu.id) + "&action=" + str(
                                                                  recruitment_action.id)).replace("_user_name_",
                                                                                                  second_tier_hod_id.name)

            values['email_to'] = second_tier_hod_id.login

            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()

            # HOD

            values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                              request.httprequest.host_url + "web#id=" + str(
                                                                  self.id) + "&view_type=form"
                                                                                            "&model=hr.recruitment.request&menu_id=" + str(
                                                                  recruitment_menu.id) + "&action=" + str(
                                                                  recruitment_action.id)).replace("_user_name_",
                                                                                                  hod_id.name)

            values['email_to'] = hod_id.login

            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()

        self.write({
            'state': 'done',
        })
