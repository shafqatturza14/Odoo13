from odoo import fields, models, api


class HrEmployeeType(models.Model):
    _name = 'employee.type'

    name = fields.Char(string='Name', required=True)
