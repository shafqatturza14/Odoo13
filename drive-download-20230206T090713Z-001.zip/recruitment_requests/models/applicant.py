# -*- coding: utf-8 -*-
from math import ceil

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import date, datetime
from dateutil.relativedelta import relativedelta


class HrApplicant(models.Model):
    _inherit = 'hr.applicant'

    request_id = fields.Many2one('hr.recruitment.request', string='Enrolment Request', store=True,
                                 compute='get_recruitment_request')

    religion = fields.Many2one('hpl.religion', 'Religion', required=False)
    gender = fields.Many2one('hpl.gender', 'Gender', required=False)
    age = fields.Integer('Age', required=False, compute='calculateAge')
    location = fields.Char('Location', required=False)
    ssc = fields.Char(string='SSC Result')
    school = fields.Char(string='School')
    ssc_subject = fields.Char(string='SSC Subject')
    hsc = fields.Char(string='HSC Result')
    college = fields.Char(string='College')
    hsc_subject = fields.Char(string='HSC Subject')
    subject = fields.Char(string='Graduation Subject')
    grad = fields.Char(string='Graduation Result')
    grad_university = fields.Char(string='Graduation University')
    grad_institute_type = fields.Selection(
        [('public', 'Public'), ('private', 'Private'), ('national', 'National')], string='Graduation Institute Type',
        default='')
    post_grad = fields.Char(string='Post Graduation Result')
    post_grad_university = fields.Char(string='Post Graduation University')
    post_grad_subject = fields.Char(string='Post Graduation Subject')
    is_experienced = fields.Boolean(string='Is Experienced', default=False)
    is_pharma = fields.Boolean(string='Is pharma', default=False)
    pharma_experience = fields.Float(string='pharma Experience', default=False)
    experience = fields.Float(string='Total Experience')
    company_name = fields.Text(string='Company Name')
    company_designation = fields.Text(string='Company Designation')
    company_start_date = fields.Text(string='Company Start Date')
    company_end_date = fields.Text(string='Company End Date')

    nid_number = fields.Char('NID NO', required=True, default='')
    till_now = fields.Boolean(string='Till Now', default=False)

    home_district = fields.Char('Home District')
    pe_company = fields.Char('Company')
    pe_duration = fields.Char('Duration')
    pe_posting_place = fields.Char('Previous Posting Place')
    blood_group_web = fields.Selection([
        ('A+', 'A+'),
        ('A-', 'A-'),
        ('B+', 'B+'),
        ('B-', 'B-'),
        ('O+', 'O+'),
        ('O-', 'O-'),
        ('AB+', 'AB+'),
        ('AB-', 'AB-'),
    ], default='A+', string='Blood Group')
    blood_group_hpl = fields.Many2one('hpl.blood.group', 'Blood Group')
    date_of_birth = fields.Date(string='Date of Birth')
    references = fields.Char('References')
    marital_status = fields.Many2one('hpl.marital.status', 'Marital Status')
    wife_occupation = fields.Char('Spouse Occupation', default='')

    village = fields.Char(string='Village(PERM)')
    post_office = fields.Char(string='Post Office(PERM)')
    police_station = fields.Char(string='Police Station(PERM)')
    district = fields.Char(string='District(PERM)')
    batches = fields.Many2one('all.batch', 'Batch Tag')
    batch_number = fields.Integer('Batch', store=True)

    father = fields.Char("Father's Name")
    mother = fields.Char("Mother's Name")
    reason_of_blocking = fields.Char("Reason Of Blocking")
    present_address = fields.Char("Present Address")
    last_name = fields.Char('Last Name', store=True, compute='_compute_last_name')
    trainee_code = fields.Char('Trainee Code', store=True)
    hpl_team = fields.Char('Training Team Name', store=True)
    is_employee_created = fields.Boolean(string='Is Employee Created', Store=True, default=False)

    @api.onchange('batches')
    def batch_tag(self):
        if self.batches:
            self.batch_number = self.batches.batches
            self.trainee_code = ''
            self.hpl_team = ''
            print("HPL TEAM")
            print(self.hpl_team)

    @api.depends('partner_name')
    def _compute_last_name(self):
        print('last name')
        if self.partner_name:
            split_str = self.partner_name.split(' ')
            self.last_name = split_str[-1]

    salary_wizard = fields.Char('Salary')
    current_salary = fields.Float('Current Salary')
    remarks = fields.Char('Remarks for Blocking')
    candidate_birth_date = fields.Date('Candidate Birth Date')
    experience_line = fields.One2many('prev.exp', 'prev_exp_id', string='Experience Line')
    previous_application = fields.Many2one('hr.applicant', string='Previous Application')
    previous_application_status = fields.Char(string='Previous Application status')
    spouse_name = fields.Char('Spouse Name')
    experience_list = fields.Char('Experience List', store=True, compute='experience_calculate')
    postal_code = fields.Char('Postal Code')

    @api.depends('company_start_date', 'company_end_date')
    def experience_calculate(self):
        for rec in self:
            if rec.company_start_date and rec.company_end_date:
                start_date = (rec.company_start_date).split(',')
                end_date = (rec.company_end_date).split(',')
                exp = ''
                rec.experience = 0.0
                for s, e in zip(start_date, end_date):
                    start = s.split('-')
                    end = e.split('-')
                    start_date_input = start[0] + start[1] + start[2]
                    end_date_input = end[0] + end[1] + end[2]
                    start_datetimeobject = datetime.strptime(start_date_input, '%Y%m%d')
                    end_datetimeobject = datetime.strptime(end_date_input, '%Y%m%d')
                    diff = (end_datetimeobject.year - start_datetimeobject.year) * 12 + (
                                end_datetimeobject.month - start_datetimeobject.month)
                    print("DIFF")
                    print(diff)
                    res = (round((diff / 12), 2))
                    print(res)
                    rec.experience += res
                    exp += str(res) + '|'
                rec.experience_list = exp
            else:
                rec.experience_list = ''

    @api.depends('date_of_birth')
    def calculateAge(self):
        for rec in self:
            if rec.date_of_birth:
                today = date.today()
                age = today.year - rec.date_of_birth.year - (
                            (today.month, today.day) < (rec.date_of_birth.month, rec.date_of_birth.day))
                rec.age = age
            else:
                rec.age = 0

    @api.model
    def search_existing_applicant(self, nid_number):
        print('nid_number', nid_number)
        applicant = self.env['hr.applicant'].search([('nid_number', '=', nid_number)], limit=1)
        print('applicant', applicant.partner_name)
        return {
            'application': applicant.id,
            'application_status': applicant.stage_id.name,
            'name': applicant.partner_name if applicant.partner_name else '',
            'email': applicant.email_from if applicant.email_from else '',
            'phone': applicant.partner_phone if applicant.partner_phone else '',
            'ssc': applicant.ssc if applicant.ssc else '',
            'hsc': applicant.hsc if applicant.hsc else '',
            'grad': applicant.grad if applicant.grad else '',
            'post_grad': applicant.post_grad if applicant.post_grad else '',
            'grad_university': applicant.grad_university if applicant.grad_university else '',
            'post_grad_university': applicant.post_grad_university if applicant.post_grad_university else '',
            'subject': applicant.subject if applicant.subject else '',
            'grad_institute_type': applicant.grad_institute_type if applicant.grad_institute_type else '',
            'is_experienced': applicant.is_experienced if applicant.is_experienced else False,
            'current_salary': applicant.current_salary if applicant.current_salary else '',
            'salary_expected': applicant.salary_expected if applicant.salary_expected else '',
            'blood_group_web': applicant.blood_group_hpl.code if applicant.blood_group_hpl else '',
            'date_of_birth': applicant.date_of_birth if applicant.date_of_birth else '',
            'religion': applicant.religion.code if applicant.religion else '',
            'gender': applicant.gender.code if applicant.gender else '',
            'marital_status': applicant.marital_status.code if applicant.marital_status else '',
            'father': applicant.father if applicant.father else '',
            'mother': applicant.mother if applicant.mother else '',
            'present_address': applicant.present_address if applicant.present_address else '',
            'school': applicant.school if applicant.school else '',
            'college': applicant.college if applicant.college else '',
            'spouse': applicant.spouse_name if applicant.spouse_name else '',
            'village': applicant.village if applicant.village else '',
            'post_office': applicant.post_office if applicant.post_office else '',
            'police_station': applicant.police_station if applicant.police_station else '',
            'district': applicant.district if applicant.district else '',
            'postal_code': applicant.postal_code if applicant.postal_code else '',
        }

    @api.model
    def duplicate_applicant_in_same_job(self, nid_number, job):
        print(job)
        job_data = self.env['hr.job'].search([('name', '=', job)])
        duplicate = self.env['hr.applicant'].search([('nid_number', '=', nid_number),
                                                     ('job_id.name', '=', job),
                                                     ('create_date', '>=', job_data.recruitment_start_date)],
                                                    limit=1)
        if duplicate:
            raise ValidationError(_("You Have Already Applied For This Job"))

    @api.onchange('nid_number')
    def get_value_from_nid(self):
        candidate = self.env['hr.applicant'].search([('nid_number', '=', self.nid_number)])
        for rec in candidate:
            self.partner_name = rec.partner_name

    @api.depends('job_id')
    def get_recruitment_request(self):
        for rec in self:
            if rec.job_id:
                recruitment_object = self.env['hr.recruitment.request'].search(
                    [('job_id', '=', rec.job_id.id)])
                for recruitment in recruitment_object:
                    rec.request_id = recruitment.id
            else:
                rec.request_id = False

    def create_employee_from_applicant(self):
        res = super(HrApplicant, self).create_employee_from_applicant()
        if self.request_id:
            employee = self.env['hr.employee'].browse(res['res_id'])
            employee.update({'request_id': self.request_id.id, 'state': 'recruited'})
        return res

    def website_form_input_filter(self, request, values):
        print('Dhukse:', values)
        if 'ssc' in values:
            values.setdefault('ssc', '%d ' % values['ssc'])
            print('values: ', values)
        return super(HrApplicant, self).website_form_input_filter(request, values)

    def send_regret_letter(self):
        applicant = self.env['hr.applicant'].browse(self.id)
        print('applicant:', applicant)
        template_id = self.env.ref('recruitment_requests.regret_letter_email_template').id
        template = self.env['mail.template'].browse(template_id)
        # template['email_from'] = self.user_id.email_formatted
        template.send_mail(applicant.id, force_send=True)

    def create_hpl_employee_from_applicant(self):
        print('Hello')
        employee_rec = self.env['hpl.employee'].search([('applicant', '=', self.id)], limit=1)
        if employee_rec:
            raise UserError(_("Employee already created from this applicant."))
        return {
            'res_model': 'hpl.employee',
            'type': 'ir.actions.act_window',
            'context': {'default_full_name': self.partner_name,
                        'default_applicant': self.id
                        },
            # 'default_gender': self.gender,
            # 'default_religion': self.religion,
            # 'default_marital_status': self.marital_status,
            # 'default_blood_group_hpl': self.blood_group_hpl,
            # },
            'view_mode': 'form',
            'view_id': self.env.ref("hpl_employee.hpl_employee_form_view").id
        }


class PrevExperience(models.Model):
    _name = 'prev.exp'
    _description = 'Previous Experience'

    prev_exp_id = fields.Many2one('hr.applicant', string='Exp ID')
    app_nid_no = fields.Char(string='NID No', store=True)
    company_name = fields.Char(string='Company Name', store=True)
    designation = fields.Char(string='Company Designation', store=True)
    experience = fields.Integer(string='Experience', store=True)
    from_date = fields.Date(string='From Date', store=True)
    to_date = fields.Date(string='To Date', store=True)

    @api.model
    def add_experience(self, nid_no, company_name, designation, from_date, to_date):
        print(company_name, designation, from_date, to_date)
        self.env['prev.exp'].search([('nid_no', '=', nid_no)]).unlink()
        self.env['prev.exp'].create({
            'app_nid_no': nid_no,
            'company_name': company_name,
            'designation': designation,
            'from_date': from_date,
            'to_date': to_date,
        })
        # exp = self.env['prev.exp'].search([('nid_number', '=', nid_no)])
        # if exp:
        #     exp.update({
        #         'company_name': company_name,
        #         'designation': designation,
        #         'from_date': from_date,
        #         'to_date': to_date,
        #     })
        # else:
        #     exp.create({
        #         'company_name': company_name,
        #         'designation': designation,
        #         'from_date': from_date,
        #         'to_date': to_date,
        #     })

        return nid_no,company_name, designation, from_date, to_date
