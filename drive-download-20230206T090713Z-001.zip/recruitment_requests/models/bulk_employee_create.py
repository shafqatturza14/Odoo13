from odoo import fields, models, api, _
from datetime import datetime


class BulkEmployeeCreate(models.Model):
    _name = 'bulk.employee.create'
    _description = 'Bulk Employee Create'

    employee_id = fields.Char(string='Employee Id', required=True)
    legacy_id = fields.Char(string='Legacy Id', required=True)
    name = fields.Char(string='Name', required=True)
    nid = fields.Char(string='NID', required=True)
    joining_date = fields.Date(string='Joining Date', required=True, default=datetime.today())
    position_code = fields.Char(string='Position Code', required=True)
    personal_area = fields.Char(string='Personal Area', required=True)
    personal_sub_area = fields.Char(string='Personal Sub Area', required=True)
