from odoo import fields, models, api


class AppointLetter(models.AbstractModel):
    _name= 'report.recruitment_requests.print_appointment_letter'

    @api.model
    def _get_report_values(self, docids, data):
        model_id = data['model_id']
        model_obj = self.env['hr.applicant'].browse(model_id)
        appointment_template = data['appointment_template']
        print(appointment_template)
        signee = data['signee']
        position = data['position']
        print(signee[0])
        unit = data['unit']
        return {
            'docs': model_obj,
            'appointment_template': appointment_template,
            'signee_1_name': signee[0],
            'signee_2_name': signee[1],
            'signee_3_name': signee[2] if len(signee) == 3 else ' ',
            'position_1_name': position[0],
            'position_2_name': position[1],
            'position_3_name': position[2] if len(position) == 3 else ' ',
            'unit': unit
       }
