# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from odoo.http import request
from odoo.exceptions import UserError


class SubmitMD(models.TransientModel):
    _name = 'submit.md'
    _description = "MD Submit"

    recruitment_id = fields.Many2one(
        'hr.recruitment.request',
        default=lambda self: self._default_recruitment(),
        required=True
    )
    current_user = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.user)

    def _default_recruitment(self):
        return self.env['hr.recruitment.request'].browse(self.env.context.get(
            'active_id'))

    def send_email(self):
        md_email_template = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                        '_rr_sent_to_md_template_')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('hr_recruitment',
                                                                       'menu_hr_recruitment_root')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                         'action_hr_recruitment_request')

        second_tier_hod_id = self.env['res.users'].browse(self.recruitment_id.second_tier_hod_id.id)
        hod_id = self.env['res.users'].browse(self.recruitment_id.hod_id.id)

        values = md_email_template.generate_email(self.recruitment_id.id)

        values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                          request.httprequest.host_url + "web#id=" + str(
                                                              self.recruitment_id.id) + "&view_type=form"
                                                                                        "&model=hr.recruitment.request&menu_id=" + str(
                                                              recruitment_menu.id) + "&action=" + str(
                                                              recruitment_action.id)).replace("_user_name_",
                                                                                              'Managing Director')
        values['email_from'] = self.current_user.email_formatted

        # static email for now
        values['email_to'] = 'shz.md.test@gmail.com'

        send_mail = self.env['mail.mail'].create(values)
        send_mail.send()


        return self.recruitment_id.write({
            'hr_id': self.current_user,
            'state': 'sent_to_md',
        })
