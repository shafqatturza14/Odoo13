# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from odoo.http import request
from odoo.exceptions import UserError


class SubmitHOD(models.TransientModel):
    _name = 'submit.hod'

    recruitment_id = fields.Many2one(
        'hr.recruitment.request',
        default=lambda self: self._default_recruitment(),
        required=True
    )

    current_user = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.user)

    def _default_recruitment(self):
        return self.env['hr.recruitment.request'].browse(self.env.context.get(
            'active_id'))

    def send_email(self):
        return self.recruitment_id.write({
            'state': 'sent_to_hod',
        })
