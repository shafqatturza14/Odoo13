# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from datetime import date
from . import strings
import base64


class AppointmentWizard(models.TransientModel):
    _name = 'appointment.wizard'

    appointment_template = fields.Text(string='Appointment Letter')
    signee = fields.Many2many('hpl.employee', string='Signee', required=True)

    # @api.onchange('salary')
    # def salary_onchange(self):
    #     print('i was here--------------')
    #     for res in self:
    #         str_tem = str(res.appointment_template)
    #         print(type(str_tem))
    #         str_tem.replace("total_amount", res.salary)
    #         print('after replace =', str_tem)
    #         res['appointment_template'] = str_tem

    @api.model
    def default_get(self, fields):
        res = super(AppointmentWizard, self).default_get(fields)
        active_id = self._context.get('active_id')
        confirmed_applicant = self.env['confirmed.applicant'].browse(active_id)
        applicant = confirmed_applicant.applicant_id
        salary = confirmed_applicant.salary
        salary_in_word = confirmed_applicant.salary_in_word
        reporting_person = confirmed_applicant.reporting_person
        joining_date = (confirmed_applicant.joining_date).strftime('%B %d,%Y')
        template = confirmed_applicant.appointment_id.salary_structure
        print('template', template)
        data = self.calculate_salary_structure(template.code, salary)

        if applicant.gender.code == '1':
            title = 'Mr.'
            so_do = 'S/O'
        else:
            title = 'Ms.'
            so_do = 'D/O'
        today = (date.today()).strftime('%B %d,%Y')
        print(applicant.department_id.business_unit.code)
        if applicant.department_id.business_unit.code == "1000":
            print('if')
            print(data['basic'], data['house_rent'],data['conveyance'], data['medical'],
                  data['house_maintenance'],)
            res['appointment_template'] = strings.ho_letter.format(title, applicant.partner_name, so_do,
                                                                   applicant.father, applicant.mother,
                                                                   applicant.spouse_name,
                                                                   applicant.village, applicant.post_office,
                                                                   applicant.police_station,
                                                                   applicant.district, applicant.present_address, today,
                                                                   applicant.job_id.name,
                                                                   title, applicant.last_name, applicant.job_id.name,
                                                                   joining_date, salary, salary_in_word,
                                                                   data['basic'], data['house_rent'],
                                                                   data['conveyance'], data['medical'],
                                                                   data['house_maintenance'], salary_in_word,
                                                                   salary, reporting_person.position_name,
                                                                   )
        elif applicant.department_id.business_unit.code == "3000":
            print('elif')
            res['appointment_template'] = strings.plant_letter.format(title, applicant.partner_name, so_do,
                                                                      applicant.father, applicant.mother,
                                                                      applicant.spouse_name,
                                                                      applicant.village, applicant.post_office,
                                                                      applicant.police_station,
                                                                      applicant.district, applicant.present_address,
                                                                      today, applicant.job_id.name,
                                                                      title, applicant.last_name, applicant.job_id.name,
                                                                      joining_date, salary, salary_in_word,
                                                                      reporting_person.position_name)
        elif applicant.department_id.business_unit.code == "2000":
            print('elif')
            res['appointment_template'] = strings.sales_letter.format(title, applicant.partner_name, so_do,
                                                                      applicant.father, applicant.mother,
                                                                      applicant.spouse_name,
                                                                      applicant.village, applicant.post_office,
                                                                      applicant.police_station,
                                                                      applicant.district, applicant.present_address,
                                                                      today, applicant.job_id.name,
                                                                      title, applicant.last_name, applicant.job_id.name,
                                                                      joining_date, salary, salary_in_word,
                                                                      data['basic'], data['house_rent'],
                                                                      data['conveyance'], data['medical'],
                                                                      data['house_maintenance'], salary_in_word,
                                                                      salary, reporting_person.position_name,
                                                                      reporting_person.position_name, joining_date)
        else:
            print('else')
            res['appointment_template'] = strings.sister_concern.format(applicant.partner_name,
                                                                        applicant.father, applicant.mother,
                                                                        applicant.village, applicant.post_office,
                                                                        applicant.police_station,
                                                                        applicant.district, today,
                                                                        applicant.job_id.name, applicant.partner_name,
                                                                        applicant.job_id.name
                                                                        )

        return res

    def calculate_salary_structure(self, template_code, salary):
        if template_code == '01':
            print('salary', type(salary))
            basic = (salary * 45) / 100
            house_rent = (basic * 50) / 100
            conveyance = (basic * 30) / 100
            medical = (basic * 20) / 100
            house_maintenance = salary - (basic + house_rent + conveyance + medical)
        else:
            basic = 0
            house_rent = 0
            conveyance = 0
            medical = 0
            house_maintenance = 0
        return {
            'basic': basic,
            'house_rent': house_rent,
            'conveyance': conveyance,
            'medical': medical,
            'house_maintenance': house_maintenance
        }

    def print_appointment(self):
        active_id = self._context.get('active_id')
        confirmed_applicant = self.env['confirmed.applicant'].browse(active_id)
        applicant = confirmed_applicant.applicant_id
        name_list = []
        position_list = []
        for sig in self.signee:
            name_list.append(sig.full_name)
            position_list.append(sig.position_name)
        data = {
            'model_id': applicant.id,
            'appointment_template': self.appointment_template,
            'signee': name_list,
            'position': position_list,
            'unit': applicant.department_id.business_unit.name
        }
        return self.env.ref('recruitment_requests.report_appointment_pdf').report_action(self, data=data)

    def action_send_appointment_letter(self):
        active_id = self._context.get('active_id')
        confirmed_applicant = self.env['confirmed.applicant'].browse(active_id)
        applicant = confirmed_applicant.applicant_id

        # Attachment Start
        name_list = []
        position_list = []
        for sig in self.signee:
            name_list.append(sig.full_name)
            position_list.append(sig.position_name)
        data = {
            'model_id': applicant.id,
            'appointment_template': self.appointment_template,
            'signee': name_list,
            'position': position_list,
            'unit': applicant.department_id.business_unit.name
        }

        pdf = self.env.ref('recruitment_requests.report_appointment_pdf').render_qweb_pdf(self.id, data=data)
        print('PDF:----', pdf[0])
        data_id = self.env['ir.attachment'].create({
            'name': 'appointment_leeter_of_%s' % applicant.partner_name,
            'type': 'binary',
            'datas': base64.encodebytes(pdf[0]),
            'res_model': 'hr.applicant',
            'res_id': applicant.id,
            'mimetype': 'application/x-pdf'
        })
        # data_id = self.env['ir.attachment'].create(ir_values)

        template_id = self.env.ref('recruitment_requests.appointment_letter_email_template').id
        template = self.env['mail.template'].browse(template_id)
        template.attachment_ids = [(6, 0, [data_id.id])]
        template.send_mail(applicant.id, force_send=True)
