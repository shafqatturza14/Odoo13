# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from odoo.http import request
from odoo.exceptions import UserError


class HodApproval(models.TransientModel):
    _name = 'hod.approval'

    recruitment_id = fields.Many2one(
        'hr.recruitment.request',
        default=lambda self: self._default_recruitment(),
        required=True
    )
    hod_comment = fields.Text(string="Comments")

    current_user = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.user)

    def _default_recruitment(self):
        return self.env['hr.recruitment.request'].browse(self.env.context.get(
            'active_id'))

    def send_email(self):
        # send email to Second HOD

        # get department HOD
        send_to_second_hod_email_template = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                         'request_accepted_bt_hod')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('hr_recruitment',
                                                                       'menu_hr_recruitment_root')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                         'action_hr_recruitment_request')

        department_id = self.env['hr.department'].browse(self.recruitment_id.department_id.id)

        second_tier_hod_id = self.env['res.users'].browse(self.recruitment_id.second_tier_hod_id.id)

        if department_id:

            if second_tier_hod_id:

                values = send_to_second_hod_email_template.generate_email(self.recruitment_id.id)

                values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                                  request.httprequest.host_url + "web#id=" + str(
                                                                      self.recruitment_id.id) + "&view_type=form"
                                                                                                "&model=hr.recruitment.request&menu_id=" + str(
                                                                      recruitment_menu.id) + "&action=" + str(
                                                                      recruitment_action.id)).replace("_user_name_",
                                                                                                      second_tier_hod_id.name)

                values['email_to'] = second_tier_hod_id.login

                send_mail = self.env['mail.mail'].create(values)
                send_mail.send()
            else:
                raise UserError(_('Second Tier HoD not set for this request'))

        return self.recruitment_id.write({
            'hod_id': self.current_user,
            'state': 'hod_approved',
            'hod_comment': self.hod_comment
        })
