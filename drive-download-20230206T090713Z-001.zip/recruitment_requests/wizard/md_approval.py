# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from odoo.http import request
from odoo.exceptions import UserError


class MDApproval(models.TransientModel):
    _name = 'md.approval'
    _description = "MD Approval for recruitment"

    recruitment_id = fields.Many2one(
        'hr.recruitment.request',
        default=lambda self: self._default_recruitment(),
        required=True
    )
    md_comment = fields.Text(string="Comments")
    current_user = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.user)

    def _default_recruitment(self):
        return self.env['hr.recruitment.request'].browse(self.env.context.get(
            'active_id'))

    def send_email(self):
        # get department HOD
        send_to_hr_hod_and_second_hod_template = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                                             'request_accepted_by_md')

        recruitment_menu = self.env['ir.model.data'].sudo().get_object('hr_recruitment',
                                                                       'menu_hr_recruitment_root')
        recruitment_action = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                         'action_hr_recruitment_request')

        second_tier_hod_id = self.env['res.users'].browse(self.recruitment_id.second_tier_hod_id.id)
        hod_id = self.env['res.users'].browse(self.recruitment_id.hod_id.id)

        if second_tier_hod_id and hod_id:
            values = send_to_hr_hod_and_second_hod_template.generate_email(self.recruitment_id.id)
            # HR Manager

            values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                              request.httprequest.host_url + "web#id=" + str(
                                                                  self.recruitment_id.id) + "&view_type=form"
                                                                                            "&model=hr.recruitment.request&menu_id=" + str(
                                                                  recruitment_menu.id) + "&action=" + str(
                                                                  recruitment_action.id)).replace("_user_name_",
                                                                                                  'HR Manager')

            values['email_to'] = 'shz.hr.test@gmail.com'

            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()
            # Second Tier HOD

            values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                              request.httprequest.host_url + "web#id=" + str(
                                                                  self.recruitment_id.id) + "&view_type=form"
                                                                                            "&model=hr.recruitment.request&menu_id=" + str(
                                                                  recruitment_menu.id) + "&action=" + str(
                                                                  recruitment_action.id)).replace("_user_name_",
                                                                                                  second_tier_hod_id.name)

            values['email_to'] = second_tier_hod_id.login

            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()

            # HOD

            values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                              request.httprequest.host_url + "web#id=" + str(
                                                                  self.recruitment_id.id) + "&view_type=form"
                                                                                            "&model=hr.recruitment.request&menu_id=" + str(
                                                                  recruitment_menu.id) + "&action=" + str(
                                                                  recruitment_action.id)).replace("_user_name_",
                                                                                                  hod_id.name)

            values['email_to'] = hod_id.login

            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()

        return self.recruitment_id.write({
            'md_id': self.env.user,
            'state': 'md_approved',
            'md_comment': self.md_comment
        })
