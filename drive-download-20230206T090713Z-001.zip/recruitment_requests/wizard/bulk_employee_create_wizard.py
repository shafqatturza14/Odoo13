# -*- coding: utf-8 -*-
from odoo import fields, api, models, _, http
import requests, json
from datetime import datetime, date
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)


class BulkEmployeeCreateWizard(models.TransientModel):
    _name = 'bulk.employee.create.wizard'

    applicants = fields.Many2many('hr.applicant', string='Employee To Be Created', required=True)

    @api.model
    def default_get(self, fields):
        res = super(BulkEmployeeCreateWizard, self).default_get(fields)
        active_ids = self._context.get('active_ids', []) or []
        applicant_ids = []
        for record in self.env['bulk.employee.create'].browse(active_ids):
            applicant_ids.append(self.env['hr.applicant'].search([('nid_number', '=', record.nid),
                                                                  ('stage_id', '=', 4)]).id)
        res['applicants'] = [(6, 0, applicant_ids)]
        return res

    def create_employees(self):
        for applicant in self.applicants:
            emp_var_data = self.env['bulk.employee.create'].search([('nid', '=', applicant.nid_number)])
            action_type = self.env['hpl.action.type'].search([('code', '=', 'ZA')]).id
            group = self.env['hpl.employee.group'].search([('code', '=', 'B')]).id

            position_data = self.get_position_data(emp_var_data.position_code)
            name = str(applicant.partner_name).split(' ')
            fname = ''
            for i in range(0, len(name) - 1):
                fname += ' ' + str(name[i])

            # Address Line Data
            add_lines = []
            pres_add_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'address_type': self.env['hpl.address.type'].search([('code', '=', '3')]).id,
                'street_house': applicant.present_address,
            }
            add_lines.append((0, 0, pres_add_val))

            perm_add_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'address_type': self.env['hpl.address.type'].search([('code', '=', '1')]).id,
                'street_house': str(applicant.village) + ', ' + str(applicant.post_office) + ', ' +
                                str(applicant.police_station) + ', ' + str(applicant.district),
            }
            add_lines.append((0, 0, perm_add_val))

            print('lines: ', add_lines)
            # Address Line Data

            # Family Line
            family_lines = []
            father_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'family_type': self.env['hpl.family.type'].search([('code', '=', '11')]).id,
                'first_name': applicant.father,
                'gender': self.env['hpl.gender'].search([('code', '=', '1')]).id
            }
            family_lines.append((0, 0, father_val))

            mother_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'family_type': self.env['hpl.family.type'].search([('code', '=', '12')]).id,
                'first_name': applicant.mother,
                'gender': self.env['hpl.gender'].search([('code', '=', '2')]).id
            }
            family_lines.append((0, 0, mother_val))

            print('lines: ', family_lines)
            # Family Line

            # Education Line
            edu_lines = []
            ssc_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'education_establishment_type': self.env['hpl.educational.establishment.type'].search([
                    ('code', '=', '21')]).id,
                'result': applicant.ssc,
                'other_degree': applicant.ssc_subject,
                'institute': applicant.school,
                'certificate': self.env['hpl.certificate'].search([('code', '=', '01')]).id,
            }
            edu_lines.append((0, 0, ssc_val))

            hsc_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'education_establishment_type': self.env['hpl.educational.establishment.type'].search([
                    ('code', '=', '20')]).id,
                'result': applicant.hsc,
                'other_degree': applicant.hsc_subject,
                'institute': applicant.college,
                'certificate': self.env['hpl.certificate'].search([('code', '=', '01')]).id,
            }
            edu_lines.append((0, 0, hsc_val))

            grad_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'education_establishment_type': self.env['hpl.educational.establishment.type'].search([
                    ('code', '=', '10')]).id,
                'result': applicant.grad,
                'other_degree': applicant.subject,
                'institute': applicant.grad_university,
                'certificate': self.env['hpl.certificate'].search([('code', '=', '01')]).id,
            }
            edu_lines.append((0, 0, grad_val))
            if applicant.post_grad_university:
                post_grad_val = {
                    'start_date': emp_var_data.joining_date,
                    'end_date': None,
                    'education_establishment_type': self.env['hpl.educational.establishment.type'].search([
                        ('code', '=', '03')]).id,
                    'result': applicant.post_grad,
                    'other_degree': applicant.post_grad_subject,
                    'institute': applicant.post_grad_university,
                    'certificate': self.env['hpl.certificate'].search([('code', '=', '01')]).id,
                }
                edu_lines.append((0, 0, post_grad_val))

            print('lines: ', edu_lines)
            # Education Line

            # Communication Line
            com_lines = []
            mobile_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'communication_type': self.env['hpl.communication.type'].search([('code', '=', '0004')]).id,
                'value': applicant.partner_phone,
            }
            com_lines.append((0, 0, mobile_val))

            email_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'communication_type': self.env['hpl.communication.type'].search([('code', '=', '0030')]).id,
                'value': applicant.email_from,
            }
            com_lines.append((0, 0, email_val))

            print('lines: ', com_lines)
            # Communication Line

            # Planned Working Data
            work_lines = []
            work_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'working_schedule_rule': 'GNRL',
                'time_management_status': '1 1 - Time evaluation of actual times',
            }
            work_lines.append((0, 0, work_val))
            # Planned Working Data

            # Previous Experience
            prev_exp_lines = [(5, 0, 0)]
            exp = self.env['prev.exp'].sudo().search([('app_nid_no', '=', applicant.nid_number)])
            if exp:
                for val in exp:
                    companies = val.company_name
                    designations = val.designation
                    com_start_date = val.from_date
                    com_end_date = val.to_date
                    for i in range(0, len(companies)):
                        start_date = datetime.strptime(str(com_start_date[i]), '%Y-%m-%d')
                        end_date = datetime.strptime(str(com_end_date[i]), '%Y-%m-%d')
                        print(start_date, end_date)
                        exp_vals = {
                            'start_date': datetime.strptime(start_date.strftime('%Y/%m/%d'), '%Y/%m/%d'),
                            'end_date': datetime.strptime(end_date.strftime('%Y/%m/%d'), '%Y/%m/%d'),
                            'name_of_employer': companies[i],
                            'position': designations[i],
                        }
                        prev_exp_lines.append((0, 0, exp_vals))
            else:
                if applicant.company_name:
                    if applicant.company_name.find(','):
                        companies = applicant.company_name.split(',')
                        designations = applicant.company_designation.split(',')
                        com_start_date = applicant.company_start_date.split(',')
                        com_end_date = applicant.company_end_date.split(',')

                        for i in range(0, len(companies)):
                            start_date = datetime.strptime(com_start_date[i], '%Y-%m-%d')
                            end_date = datetime.strptime(com_end_date[i], '%Y-%m-%d')
                            print(start_date, end_date)
                            exp_vals = {
                                'start_date': datetime.strptime(start_date.strftime('%Y/%m/%d'), '%Y/%m/%d'),
                                'end_date': datetime.strptime(end_date.strftime('%Y/%m/%d'), '%Y/%m/%d'),
                                'name_of_employer': companies[i],
                                'position': designations[i],
                            }
                            prev_exp_lines.append((0, 0, exp_vals))
                    else:
                        print('else')
                        exp_vals = {
                            'start_date': applicant.company_start_date,
                            'end_date': applicant.company_end_date,
                            'name_of_employer': applicant.company_name,
                            'position': applicant.company_designation,
                        }
                        prev_exp_lines.append((0, 0, exp_vals))

            print(prev_exp_lines)
            # Previous Experience

            # Personal Ids
            ids_lines = []
            ids_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'id_type': self.env['hpl.id.type'].search([('code', '=', '02')]).id,
                'identity_number': applicant.nid_number,
            }
            ids_lines.append((0, 0, ids_val))

            print('lines: ', ids_lines)
            # Personal Ids

            # Reference Line
            reference = self.env['employee.reference'].search([('employee_id', '=', applicant.id)])
            ref_lines = []
            ref_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'company_name': reference.referee_occupation,
                'name_of_referee': reference.referee_name,
                'mobile': reference.referee_mobile,
                'email': str(reference.referee_email),
                'address': reference.referee_address,
            }
            print('ref val:', ref_val)
            ref_lines.append((0, 0, ref_val))

            print('lines: ', ref_lines)
            # Reference Line

            # Nominee Line
            nom_lines = []
            nominee = self.env['employee.nominee'].search([('employee_id', '=', applicant.id)])
            for nom in nominee.nominee_lines:
                nom_val = {
                    'start_date': emp_var_data.joining_date,
                    'end_date': None,
                    'name_of_nominee': nom.name,
                    'relation': nom.relation,
                    'percent_of_share': nom.proportion,
                    'address': nom.sign_and_address,
                    'birth_date': nom.birthday,
                }
                nom_lines.append((0, 0, nom_val))
            print(nom_lines)
            # Nominee Line

            # Internal Line
            internal_line = []
            internal_val = {
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'prev_personal_no': emp_var_data.legacy_id
            }
            internal_line.append((0, 0, internal_val))
            # Internal Line

            # Training Line
            train_lines = []
            training = self.env['employee.training'].search([('employee_id', '=', applicant.id)])
            for train in training.training_lines:
                train_val = {
                    'start_date': emp_var_data.joining_date,
                    'end_date': None,
                    'name_of_course': train.program,
                    'name_of_institution': train.institute,
                    'place_of_training': train.local,
                    'from_date': train.date_from,
                    'to_date': train.date_to,
                }
                train_lines.append((0, 0, train_val))
            print(train_lines)
            # Training Line

            self.env['hpl.employee'].create({
                'applicant': applicant.id,
                'employee_id': emp_var_data.employee_id,
                'start_date': emp_var_data.joining_date,
                'end_date': None,
                'action_type': action_type,
                'company_code': self.env['hpl.company.code'].search([('code', '=', '1000')]).id,
                'position': emp_var_data.position_code,
                'position_name': position_data['POSITION_NAME'],
                'job_key': position_data['JOB'],
                'org_unit': position_data['ORGUNIT'],
                'department': applicant.department_id.id,
                'business_unit': applicant.department_id.business_unit.id,
                'personal_area': self.env['hpl.personal.area'].search([('code', '=', emp_var_data.personal_area)]).id,
                'personal_sub_area': self.env['hpl.personal.sub.area'].search(
                    [('code', '=', emp_var_data.personal_sub_area)]).id,
                'reason_for_action': self.env['hpl.reason.for.action'].search(
                    [('code', '=', '01'), ('action_type', '=', action_type)]).id,
                'employment': self.env['hpl.employment'].search([('code', '=', '3')]).id,
                'special_payment': self.env['hpl.special.payment'].search([('code', '=', '1')]).id,
                'employee_group': group,
                'employee_sub_group': self.env['hpl.employee.sub.group'].search(
                    [('code', '=', '01'), ('employee_group', '=', group)]).id,
                'payroll_area': self.env['hpl.payroll.area'].search([('code', '=', 'Z1')]).id,
                'area': self.env['hpl.area'].search([('code', '=', '02')]).id,
                'last_name': name[-1],
                'first_name': fname,
                'gender': applicant.gender.id,
                'birth_date': applicant.date_of_birth,
                'medical_subtype': self.env['hpl.sub.type'].search([('code', '=', '0001')]).id,
                'blood_group': applicant.blood_group_hpl.id,
                'marital_status': applicant.marital_status.id,
                'religion': applicant.religion.id,
                'nationality': self.env['hpl.nationality'].search([('code', '=', 'BD')]).id,
                'address_line': add_lines,
                'family_line': family_lines,
                'education_line': edu_lines,
                'communication_line': com_lines,
                'working_line': work_lines,
                'previous_employment_line': prev_exp_lines,
                'personal_id_line': ids_lines,
                'reference_line': ref_lines,
                'nominee_line': nom_lines,
                'internal_line': internal_line,
                'training_line': train_lines
            })

    @staticmethod
    def check_server_url():
        server_url = http.request.env['ir.config_parameter'].get_param('web.base.url')
        _logger.info('server_url:')
        _logger.info(server_url)
        if server_url == 'http://192.168.8.212':
            return True
        else:
            return False

    def get_position_data(self, position):
        header_obj = Dictionary()
        header_obj.add('Content-Type', 'application/json')
        is_prod = self.check_server_url()
        if is_prod:
            url = 'http://hs4ciprd.hpl.com.bd:8000/zapidemo/webapidemo?POST_TYPE=POSITIONKEY&POSITION=' + str(position)
            auth = ('HPLHRIS', 'qwer@1234')
            r = requests.get(url, auth=auth, headers=header_obj)
            _logger.info("## Auth ##")
            _logger.info(auth)
        else:
            url = 'http://hs4cidev.hpl.com.bd:8000/zapidemo/webapidemo?POST_TYPE=POSITIONKEY&POSITION=' + str(position)
            r = requests.get(url, headers=header_obj)
        if r.status_code == 200:
            data = r.json()
            print('data:', data)
            _logger.info("** data **")
            _logger.info(data)
            if len(data) > 0:
                return data[0]
            else:
                raise ValidationError(_("No Position Found For this Code"))


class Dictionary(dict):

    # __init__ function
    def __init__(self):
        self = dict()

        # Function to add key:value

    def add(self, key, value):
        self[key] = value
