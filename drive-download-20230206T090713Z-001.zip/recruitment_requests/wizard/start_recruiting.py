# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from odoo.http import request
from odoo.exceptions import UserError


class StartRecruitingProcess(models.TransientModel):
    _name = 'start.recruiting.process'
    _description = "Start recruiting process"

    recruitment_id = fields.Many2one(
        'hr.recruitment.request',
        default=lambda self: self._default_recruitment(),
        required=True
    )
    hr_responsible = fields.Many2one('res.users', string='Hr Responsible for Position', required=True,
                                     domain=lambda self: [("groups_id", "=", self.env.ref(
                                         "recruitment_requests.hr_recruitment_hr_manager_group").id)])

    hr_confirmation_comment = fields.Text(string="Comments")
    current_user = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.user)

    def _default_recruitment(self):
        return self.env['hr.recruitment.request'].browse(self.env.context.get(
            'active_id'))

    def action_start_recruit(self):
        # approve_template = self.env.ref('recruitment_requests.approve_request_email_template')
        # assign_template =  self.env.ref('recruitment_requests.approve_request_manager_email_template')
        if self.recruitment_id.job_id:
            self.recruitment_id.job_id.write({

                'hr_responsible_id': self.hr_responsible.id,
                'no_of_recruitment': self.recruitment_id.expected_employees,
            })
            self.recruitment_id.write({
                'state': 'recruiting',
                'approver_id': self.env.user.id,
                'hr_confirmation_comment': self.hr_confirmation_comment
            })

            # get department HOD
            start_recruiting_template = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                                    'start_recruitment_template')

            recruitment_menu = self.env['ir.model.data'].sudo().get_object('hr_recruitment',
                                                                           'menu_hr_recruitment_root')
            recruitment_action = self.env['ir.model.data'].sudo().get_object('recruitment_requests',
                                                                             'action_hr_recruitment_request')

            second_tier_hod_id = self.env['res.users'].browse(self.recruitment_id.second_tier_hod_id.id)
            hod_id = self.env['res.users'].browse(self.recruitment_id.hod_id.id)
            md_id = self.env['res.users'].browse(self.recruitment_id.md_id.id)
            hr_id = self.env['res.users'].browse(self.recruitment_id.hr_id.id)

            if hr_id and md_id and second_tier_hod_id and hod_id:
                values = start_recruiting_template.generate_email(self.recruitment_id.id)
                employee = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)])
                # MD
                md_emp = self.env['hr.employee'].search([('user_id', '=', md_id.id)])

                print(f'MD EMployee email {md_emp.work_email}')

                values['email_from'] = employee.work_email
                values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                                  request.httprequest.host_url + "web#id=" + str(
                                                                      self.recruitment_id.id) + "&view_type=form"
                                                                                                "&model=hr.recruitment.request&menu_id=" + str(
                                                                      recruitment_menu.id) + "&action=" + str(
                                                                      recruitment_action.id)).replace("_user_name_",
                                                                                                      'Managing Director')

                values['email_to'] = 'shz.md.test@gmail.com'

                send_mail = self.env['mail.mail'].create(values)
                send_mail.send()

                # HR Manager

                values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                                  request.httprequest.host_url + "web#id=" + str(
                                                                      self.recruitment_id.id) + "&view_type=form"
                                                                                                "&model=hr.recruitment.request&menu_id=" + str(
                                                                      recruitment_menu.id) + "&action=" + str(
                                                                      recruitment_action.id)).replace("_user_name_",
                                                                                                      hr_id.name)

                values['email_to'] = hr_id.login

                send_mail = self.env['mail.mail'].create(values)
                send_mail.send()
                # Second Tier HOD

                values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                                  request.httprequest.host_url + "web#id=" + str(
                                                                      self.recruitment_id.id) + "&view_type=form"
                                                                                                "&model=hr.recruitment.request&menu_id=" + str(
                                                                      recruitment_menu.id) + "&action=" + str(
                                                                      recruitment_action.id)).replace("_user_name_",
                                                                                                      second_tier_hod_id.name)

                values['email_to'] = second_tier_hod_id.login

                send_mail = self.env['mail.mail'].create(values)
                send_mail.send()

                # HOD

                values['body_html'] = values['body_html'].replace("_ticket_url_",
                                                                  request.httprequest.host_url + "web#id=" + str(
                                                                      self.recruitment_id.id) + "&view_type=form"
                                                                                                "&model=hr.recruitment.request&menu_id=" + str(
                                                                      recruitment_menu.id) + "&action=" + str(
                                                                      recruitment_action.id)).replace("_user_name_",
                                                                                                      hod_id.name)

                values['email_to'] = hod_id.login

                send_mail = self.env['mail.mail'].create(values)
                send_mail.send()

            return self.recruitment_id.job_id.set_recruit()
