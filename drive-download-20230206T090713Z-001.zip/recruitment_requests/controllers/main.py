# -*- coding: utf-8 -*-
import json

from odoo import http
from odoo.addons.website_form.controllers.main import WebsiteForm
from odoo.http import request
from odoo import fields, models, api, _


class ApplyController(WebsiteForm):
    current_model_name = ''

    @http.route('/website_form/<string:model_name>', type='http', auth="public", methods=['POST'], website=True)
    def website_form(self, model_name, **kwargs):
        self.current_model_name = model_name
        return super(ApplyController, self).website_form(model_name, **kwargs)

    def extract_data(self, model, values):
        data = super(ApplyController, self).extract_data(model, values)
        print('data------------------', data)
        if self.current_model_name == 'hr.applicant':
            for field_name, field_value in values.items():
                if field_name in ['ssc', 'hsc', 'grad', 'post_grad',
                                  'subject', 'is_experienced', 'experience',
                                  'company_name', 'company_designation', 'nid_number', 'is_pharma',
                                  'pharma_experience', 'current_salary', 'salary_expected', 'date_of_birth',
                                  'father', 'mother', 'present_address', 'postal_code', 'spouse_name',
                                  'village', 'post_office', 'police_station', 'district',
                                  'grad_institute_type', 'company_start_date', 'company_end_date',
                                  'previous_application', 'previous_application_status', 'school', 'college']:
                    data['record'][field_name] = field_value

                if field_name == 'grad_university':
                    val = field_value.split(',')
                    if val[0] == 'Other University':
                        data['record'][field_name] = val[1]
                    else:
                        data['record'][field_name] = val[0]

                if field_name == 'post_grad_university':
                    val = field_value.split(',')
                    if val[0] == 'Other University':
                        data['record'][field_name] = val[1]
                    else:
                        data['record'][field_name] = val[0]

                if field_name == 'blood_group_hpl':
                    print("============================Field")
                    print(field_value)
                    blood_group_code = request.env['hpl.blood.group'].sudo().search([('name', '=', field_value)])
                    print(blood_group_code)
                    data['record'][field_name] = blood_group_code.id
                elif field_name == 'religion':
                    print("============================Field")
                    print(field_value)
                    religion = request.env['hpl.religion'].sudo().search([('code', '=', field_value)])
                    data['record'][field_name] = religion.id

                elif field_name == 'marital_status':
                    print("============================Field")
                    print(field_value)
                    marital_status = request.env['hpl.marital.status'].sudo().search([('code', '=', field_value)])
                    data['record'][field_name] = marital_status.id

                elif field_name == 'gender':
                    gender = request.env['hpl.gender'].sudo().search([('code', '=', field_value)])
                    data['record'][field_name] = gender.id

        return data
