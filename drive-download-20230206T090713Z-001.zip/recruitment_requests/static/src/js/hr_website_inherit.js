odoo.define('recruitment_requests.action_form', function (require) {
    var rpc = require('web.rpc');

    $("#search_div").hide();
    $(".is_applied").click(function () {
        console.log('I was clicked')
        $("#search_div").toggle();
    });

    $('#hr_recruitment_form').on('click', 'button.my-button', function (e) {
        e.preventDefault();
        var nid = $("input[name=nid_number]").val();
        rpc.query({

            model: 'hr.applicant',

            method: 'search_existing_applicant',
            args: [nid],
        }).then(function (data) {
            console.log(data);
            $("input[name=previous_application]").val(data.application);
            $("input[name=previous_application_status]").val(data.application_status);
            $("input[name=partner_name]").val(data.name);
            $("input[name=email_from]").val(data.email);
            $("input[name=partner_phone]").val(data.phone);
            $("input[name=ssc]").val(data.ssc);
            $("input[name=hsc]").val(data.hsc);
            $("input[name=grad]").val(data.grad);
            $("input[name=post_grad]").val(data.post_grad);
            $("input[name=grad_university]").val(data.grad_university);
            $("input[name=post_grad_university]").val(data.post_grad_university);
            $("input[name=subject]").val(data.subject);
            $("input[name=grad_institute_type]").val(data.grad_institute_type);
            $("input[name=is_experienced]").val(data.is_experienced);
            $("input[name=current_salary]").val(data.current_salary);
            $("input[name=salary_expected]").val(data.salary_expected);
            $("input[name=blood_group_hpl]").val(data.blood_group_web).change();
            $("input[name=date_of_birth]").val(data.date_of_birth);
            $("input[name=religion]").val(data.religion).change();
            $("input[name=gender]").val(data.gender).change();
            $("input[name=marital_status]").val(data.marital_status).change();
            $("input[name=father]").val(data.father);
            $("input[name=mother]").val(data.mother);
            $("input[name=spouse_name]").val(data.spouse);
            $("input[name=present_address]").val(data.present_address);
            $("input[name=school]").val(data.school);
            $("input[name=college]").val(data.college);
            $("input[name=village]").val(data.village);
            $("input[name=post_office]").val(data.post_office);
            $("input[name=police_station]").val(data.police_station);
            $("input[name=district]").val(data.district);
            $("input[name=postal_code]").val(data.postal_code);

        });
        // $("input[name=nid_number]").after(' - <a href="#">Are you sure  ?</a>');

    });
    var exp_no = 0
    //Add Experience
    $('#hr_recruitment_form').on('click', 'button.add-exp', function (e) {
        e.preventDefault();
        exp_no = Number($("button[name=add-exp]").val()) + 1;
        console.log(exp_no)
        var experience_div = '<div id="experience-' + exp_no + '"><div class="exp">\n' +
            '                    <div class="form-group row form-field">\n' +
            '                        <div class="col-lg-3 col-md-4 text-right">\n' +
            '                            <label class="col-form-label" for="company_name">Company Name</label>\n' +
            '                        </div>\n' +
            '                        <div class="col-lg-7 col-md-8">\n' +
            '                            <input id="company_name_' + exp_no + '" type="text" class="form-control o_website_form_input" name="company_name"\n' +
            '                                   required="True"/>\n' +
            '                        </div>\n' +
            '                    </div>\n' +
            '                    <div class="form-group row form-field">\n' +
            '                        <div class="col-lg-3 col-md-4 text-right">\n' +
            '                            <label class="col-form-label" for="company_designation">Company Designation</label>\n' +
            '                        </div>\n' +
            '                        <div class="col-lg-7 col-md-8">\n' +
            '                            <input  id="company_designation_' + exp_no +'" type="text" class="form-control o_website_form_input" name="company_designation"\n' +
            '                                   required="True"/>\n' +
            '                        </div>\n' +
            '                    </div>\n' +
            '                    <div class="form-group row form-field">\n' +
            '                        <div class="col-lg-3 col-md-4 text-right">\n' +
            '                            <label class="col-form-label" for="company_start_date">Start Date</label>\n' +
            '                        </div>\n' +
            '                        <div class="col-lg-7 col-md-8">\n' +
            '                            <input id= "company_start_date_' + exp_no + '" type="date" class="form-control o_website_form_input" name="company_start_date"\n' +
            '                                   required="True"/>\n' +
            '                        </div>\n' +
            '                    </div>\n' +
            '                    <div class="form-group row form-field">\n' +
            '                        <div class="col-lg-3 col-md-4 text-right">\n' +
            '                            <label class="col-form-label" for="company_end_date">End Date</label>\n' +
            '                        </div>\n' +
            '                        <div class="col-lg-7 col-md-8">\n' +
            '                            <input id= "company_end_date_' + exp_no + '" type="date" class="form-control o_website_form_input" name="company_end_date"\n' +
            '                                   required="True"/>\n' +
            '                        </div>\n' +
            '                    </div></div>\n' +
            '<button type="button" class="remove-exp btn-primary" name="remove-exp" value="1" style="margin-left:77%; margin-bottom: 1%">' +
            'Remove </button>\n' +
            '                </div>'
        console.log('Clicked')
        $('#experience-' + (exp_no - 1)).after(experience_div);
        $("button[name=add-exp]").val(exp_no)
        //Add Experience

        //Remove Experience
        var remove = function () {
            this.parentNode.remove();
            $("button[name=add-exp]").val(exp_no - 1)
        };

        var lis = document.querySelectorAll('div.exp');
        var button = document.querySelectorAll('button.remove-exp');

        for (var i = 0, len = lis.length; i < len; i++) {
            button[i].addEventListener('click', remove, false);
        }
        //Remove Experience

    });

    $(".pharma_experience_div").val(0);
    $(".pharma_experience_div").hide();
    $(".is_pharma").click(function () {
        $(".pharma_experience_div").toggle();
    });

    $(".work_exp_read").attr('readonly', 'readonly');
    $(".work_exp_read_button").prop('disabled', true);
    $(".is_experienced").click(function () {
        console.log('I was clicked')
        if ($(this).is(":checked")) {
            $(".work_exp_read").removeAttr('readonly');
            $(".work_exp_read_button").prop('disabled', false);
        } else {
            $(".work_exp_read").attr('readonly', 'readonly');
            $(".work_exp_read_button").prop('disabled', true);
        }
    });

    $(".till_now").click(function () {
        console.log('I was clicked')
        if ($(this).is(":checked")) {
            $(".com_end").val($.datepicker.formatDate('yy-mm-dd', new Date()));
            $(".company_end_date").hide();
        } else {
            $(".company_end_date").show();
        }
    });



    $('.o_website_form_send').hide();
    $('.o_website_form_send').after('<a href="#" role="button" id="preview"' +
        ' class="btn btn-lg btn-primary">Preview</a>');
    $('.o_website_form_send').after('<a href="#" role="button" id="edit"' +
        ' class="btn btn-lg btn-primary" style="margin-left: 40px">Edit</a>');
    $('#edit').hide();

    $("#preview").click(function () {
        console.log('I was clicked');
        $('#forms input').attr('readonly', 'readonly');
        $('#forms select').prop('disabled', true);
        $('#forms textarea').attr('readonly', 'readonly');
        $('.o_website_form_send').show();
        $('#edit').show();
        $('#preview').hide();
    });

    $("#edit").click(function () {
        console.log('I was clicked');
        $('#forms input').removeAttr('readonly');
        $('#forms select').prop('disabled', false);
        $('#forms textarea').removeAttr('readonly');
        $('.o_website_form_send').hide();
        $('#edit').hide();
        $('#preview').show();
    });

    $('.o_website_form_send').click(function () {

        for(var i=1;i<=exp_no;i++){
            var nid_no = $("input[name=nid_number]").val();
            var company_name = ($("#company_name_"+ i).val())
            var company_designation = ($("#company_designation_"+ i).val())
            var company_start_date = ($("#company_start_date_"+ i).val())
            var company_end_date = ($("#company_end_date_"+ i).val())
            console.log(company_name)
            console.log(company_designation)
            console.log(company_start_date)
            console.log(company_end_date)
            rpc.query({

            model: 'prev.exp',

            method: 'add_experience',
            args: [nid_no, company_name, company_designation,company_start_date,company_end_date],
        }).then(function (data) {
            console.log(data);
        });
        }
        var nid = $("input[name=nid_number]").val();
        var job = $('h2').children('span').text();
        console.log(job)
        rpc.query({

            model: 'hr.applicant',

            method: 'duplicate_applicant_in_same_job',
            args: [nid, job],
        }).then(function (data) {
            console.log(data);
        });
        $('#forms select').prop('disabled', false);
        $('#forms input').removeAttr('readonly');
        $('#forms textarea').removeAttr('readonly');
        if(!$('#is_experienced').is(':checked')){
            $(".work_exp_read").attr('readonly', 'readonly');
        };
        $('#edit').hide();
    });

    $(".spouse_div").hide();
    $('#marital_status').on('change', function(){
    	if ($(this).val() == '0'){
    	    $(".spouse_div").show();
        }else{
    	    $(".spouse_div").hide()
        };

    });

    $("#other_university").hide()
    $('#grad_university').on('change', function(){
    	if ($(this).val() == 'Other University'){
    	    $("#other_university").show();
        }else{
    	    $("#other_university").hide()
        };

    });

    $("#other_university_post").hide()
    $('#post_grad_university').on('change', function(){
    	if ($(this).val() == 'Other University'){
    	    $("#other_university_post").show();
        }else{
    	    $("#other_university_post").hide()
        };

    });

});