# -*- coding: utf-8 -*-
# from odoo import http


# class HplEmployee(http.Controller):
#     @http.route('/hpl_employee/hpl_employee/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hpl_employee/hpl_employee/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('hpl_employee.listing', {
#             'root': '/hpl_employee/hpl_employee',
#             'objects': http.request.env['hpl_employee.hpl_employee'].search([]),
#         })

#     @http.route('/hpl_employee/hpl_employee/objects/<model("hpl_employee.hpl_employee"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hpl_employee.object', {
#             'object': obj
#         })
