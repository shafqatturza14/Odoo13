# API AUTH
prod_username = 'HPLHRIS'
prod_password = 'qwer@1234'

test_username = '31144'
test_password = 'HPL@1234'
# API AUTH

# Test Server URLS
test_position_get = 'http://hs4cidev.hpl.com.bd:8000/zapidemo/webapidemo?POST_TYPE=POSITIONKEY&POSITION='
test_csrf_get = 'http://hs4cidev.hpl.com.bd:8000/zapidemo/webapidemo'
test_base_post = 'http://hs4cidev.hpl.com.bd:8000/zapidemo/webapidemo?POST_TYPE='
# Test Server URLS

# Production Server URLS
prod_position_get = 'http://hs4ciprd.hpl.com.bd:8000/zapidemo/webapidemo?POST_TYPE=POSITIONKEY&POSITION='
prod_csrf_get = 'http://hs4ciprd.hpl.com.bd:8000/zapidemo/webapidemo'
prod_base_post = 'http://hs4ciprd.hpl.com.bd:8000/zapidemo/webapidemo?POST_TYPE='
# Production Server URLS

# IRISH Server Tests URLS
test_nominee_irish_url = 'http://192.168.8.191/HIRS_API/Handler1.ashx'
test_employee_insert_irish_url = 'http://192.168.8.191/HIRS_API/Handler1.ashx'

# IRISH Server Prod URLS
prod_nominee_irish_url = 'http://192.168.8.191/HIRS_API/Handler1.ashx'
prod_employee_insert_irish_url = 'http://192.168.8.191/HIRS_API/Handler1.ashx'

