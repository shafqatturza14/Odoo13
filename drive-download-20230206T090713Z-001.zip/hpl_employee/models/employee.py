# -*- coding: utf-8 -*-
from odoo import models, fields, api, _, http
from datetime import datetime, date
import requests, json
from odoo.exceptions import ValidationError
from . import api_urls
import logging
import base64

_logger = logging.getLogger(__name__)


class HplEmployee(models.Model):
    _name = 'hpl.employee'
    _description = 'HPL Employee'

    name = fields.Char(compute='_compute_rec_name')
    employee_id = fields.Char(string="Personal No", required=False, index=True)
    login_id = fields.Char(string='Login Id', compute='_compute_login_id')

    @api.depends('internal_line')
    def _compute_login_id(self):
        for res in self:
            if res.internal_line.prev_personal_no:
                print()
                res.login_id = res.internal_line.prev_personal_no
            else:
                res.login_id = 'prev'

    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    action_type = fields.Many2one('hpl.action.type', string='Action Type', required=False)
    action_type_change = fields.Boolean(default=False)
    reason_for_action = fields.Many2one('hpl.reason.for.action', string='Reason For Action')
    reference_person_no = fields.Char(string='Reference Person Nos.')
    employment = fields.Many2one('hpl.employment', string='Employment')
    user_id = fields.Many2one('res.users', required=False, string='User')
    applicant = fields.Many2one('hr.applicant', required=False, string='Applicant')
    # applicant_id = fields.Char(required=False, string='Applicant')
    # employment = fields.Many2one('hpl.employment', string='Employment')
    special_payment = fields.Many2one('hpl.special.payment', string='Special Payment')
    # employment = fields.Char(string='Employment')
    # special_payment = fields.Char(string='Special Payment')

    # Organizational Assignment
    position = fields.Char(string='Position')
    position_name = fields.Char(string='Position Name')
    personal_area = fields.Many2one('hpl.personal.area', string='Personnel Area')
    personal_sub_area = fields.Many2one('hpl.personal.sub.area', string='Personnel Sub Area')
    employee_group = fields.Many2one('hpl.employee.group', string='Employee Group')
    employee_sub_group = fields.Many2one('hpl.employee.sub.group', string='Employee Sub Group')
    payroll_area = fields.Many2one('hpl.payroll.area', string='Payroll Area')
    work_contract = fields.Many2one('hpl.work.contract', string='Work Contract')
    area = fields.Many2one('hpl.area', string='Area')
    job_key = fields.Char(string='Job Key')
    percentage = fields.Char(string='Percentage', default=100)
    company_code = fields.Many2one('hpl.company.code', string='Company Code')
    org_unit = fields.Char(string='Organization Unit')
    org_key = fields.Char(string='Organization Key')

    # Personal Information
    full_name = fields.Char(string='Full Name', default=' ', compute='_compute_full_name', store=True)
    title = fields.Many2one('hpl.title', string='Title')
    last_name = fields.Char(string='Last Name', required=False)
    middle_name = fields.Char(string='Middle Name', required=False)
    first_name = fields.Char(string='First Name', required=False)
    name_format = fields.Many2one('hpl.name.format', string='Name Format')
    gender = fields.Many2one('hpl.gender', string='Gender')
    marital_status = fields.Many2one('hpl.marital.status', string='Marital Status')
    since = fields.Date(string='Since', required=False)
    birth_date = fields.Date(string='Birth Date', required=False)
    birth_place = fields.Char(string='Birth Place', required=False)
    no_of_child = fields.Integer(string='No of Child', required=False)
    country_of_birth = fields.Many2one('hpl.country', string='Country of Birth')
    division = fields.Many2one('hpl.division', string='Division')
    nationality = fields.Many2one('hpl.nationality', string='Nationality')
    religion = fields.Many2one('hpl.religion', string='Religion')
    language = fields.Char(string='Language')
    birth_place = fields.Char(string='Birth Place')
    sign = fields.Image(string='Signature')
    image_1920 = fields.Image(string='Image')
    business_unit = fields.Many2one('business.unit', string='Business Unit')
    department = fields.Many2one('hr.department', string='Department')
    section = fields.Many2one('hr.section', string='Section')

    institute_type = fields.Selection([('public', 'Public'),
                                       ('private', 'Private'),
                                       ('national', 'National')
                                       ], string='Institute Type')

    # Internal Medical Data
    exam_date = fields.Date(string='Examination Date', required=False)
    last_exam_date = fields.Date(string='Last Examination Date', required=False)
    medical_subtype = fields.Many2one('hpl.sub.type', string='Sub Type')
    result = fields.Char(string='Result')
    blood_group = fields.Many2one('hpl.blood.group', string='Blood Group')
    diagnosis_number = fields.Char(string='Diagnosis Number', required=False)
    value = fields.Float(string='Value', required=False)

    # Relational Table fields
    reference_line = fields.One2many('hpl.employee.reference', 'ref_id',
                                     string='Reference Line', required=False)
    nominee_line = fields.One2many('hpl.employee.nominee', 'nom_id',
                                   string='Nominee Line', required=False)
    education_line = fields.One2many('hpl.employee.education', 'edu_id',
                                     string='Education Line', required=False)
    previous_employment_line = fields.One2many('hpl.employee.previous.employment', 'prev_employment_id',
                                               string='Previous Employment Line', required=False)
    personal_id_line = fields.One2many('hpl.employee.personal.ids', 'personal_id',
                                       string='Personal Ids Line', required=False)
    address_line = fields.One2many('hpl.employee.address', 'address_id',
                                   string='Address Line', required=False)
    family_line = fields.One2many('hpl.employee.family', 'family_id',
                                  string='Family Line', required=False)
    communication_line = fields.One2many('hpl.employee.communication', 'comm_id',
                                         string='Communication Line', required=False)
    date_line = fields.One2many('hpl.employee.date.specification', 'date_spec_id',
                                string='Date Specification Line', required=False)
    training_line = fields.One2many('hpl.employee.training', 'training_id',
                                    string='Training Line', required=False)
    internal_line = fields.One2many('hpl.employee.internal.data', 'internal_id',
                                    string='Internal Data Line', required=False)
    working_line = fields.One2many('hpl.employee.working.schedule', 'working_id',
                                   string='Working Schedule Line', required=False)

    _sql_constraints = [('employee_id', 'unique(employee_id)', 'Employee Id must be unique')]

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = str(emp.full_name) + '(' + str(emp.employee_id) + ')'

    @api.depends('title', 'last_name', 'middle_name', 'first_name')
    def _compute_full_name(self):
        for emp in self:
            if emp.last_name:
                if emp.title:
                    if emp.middle_name:
                        emp.full_name = str(emp.title.name) + ' ' + str(emp.first_name) + ' ' + str(emp.middle_name) \
                                        + ' ' + str(emp.last_name)
                    else:
                        emp.full_name = str(emp.title.name) + ' ' + str(emp.first_name) + ' ' + str(emp.last_name)
                else:
                    if emp.middle_name:
                        emp.full_name = str(emp.first_name) + ' ' + str(emp.middle_name) \
                                        + ' ' + str(emp.last_name)
                    else:
                        emp.full_name = str(emp.first_name) + ' ' + str(emp.last_name)
            else:
                if emp.title:
                    if emp.middle_name:
                        emp.full_name = str(emp.title.name) + ' ' + str(emp.first_name) + ' ' + str(emp.middle_name)

                    else:
                        emp.full_name = str(emp.title.name) + ' ' + str(emp.first_name)
                else:
                    if emp.middle_name:
                        emp.full_name = str(emp.first_name) + ' ' + str(emp.middle_name)
                    else:
                        emp.full_name = str(emp.first_name)

    @api.onchange('action_type')
    def onchange_action_type(self):
        for res in self:
            res.action_type_change = True

    @staticmethod
    def check_server_url():
        server_url = http.request.env['ir.config_parameter'].get_param('web.base.url')
        _logger.info('server_url:')
        _logger.info(server_url)
        if server_url == 'http://192.168.8.212':
            return True
        else:
            return False

    @api.onchange('position')
    def onchange_position(self):
        if self.position:
            header_obj = Dictionary()
            header_obj.add('Content-Type', 'application/json')
            is_prod = self.check_server_url()
            if is_prod:
                url = api_urls.prod_position_get + str(self.position)
                auth = (api_urls.prod_username, api_urls.prod_password)
                r = requests.get(url, auth=auth, headers=header_obj)
                _logger.info("## Auth ##")
                _logger.info(auth)
            else:
                url = api_urls.test_position_get + str(self.position)
                r = requests.get(url, headers=header_obj)
            if r.status_code == 200:
                data = r.json()
                print('data:', data)
                _logger.info("** data **")
                _logger.info(data)
                if len(data) > 0:
                    self.position_name = data[0]['POSITION_NAME']
                    self.job_key = data[0]['JOB']
                    self.org_unit = data[0]['ORGUNIT']
                else:
                    raise ValidationError(_("No Position Found For this Code"))
            else:
                raise ValidationError(_("Something went Wrong"))

    @api.onchange('applicant')
    def onchange_applicant(self):
        for res in self:
            applicant = res.applicant
            if applicant:
                # General Data
                res.action_type = self.env['hpl.action.type'].search([('code', '=', 'ZA')]).id
                res.department = applicant.department_id.id
                res.business_unit = applicant.department_id.business_unit.id
                res.reason_for_action = self.env['hpl.reason.for.action'].search(
                    [('code', '=', '01'), ('action_type', '=', res.action_type.id)]).id
                res.employment = self.env['hpl.employment'].search([('code', '=', '3')]).id
                res.special_payment = self.env['hpl.special.payment'].search([('code', '=', '1')]).id
                res.employee_group = self.env['hpl.employee.group'].search([('code', '=', 'B')]).id
                res.employee_sub_group = self.env['hpl.employee.sub.group'].search(
                    [('code', '=', '01'), ('employee_group', '=', res.employee_group.id)]).id
                res.payroll_area = self.env['hpl.payroll.area'].search([('code', '=', 'Z1')]).id
                res.area = self.env['hpl.area'].search([('code', '=', '02')]).id

                # General Data
                # Personal Information
                name = str(applicant.partner_name).split(' ')
                res.last_name = name[-1]
                fname = ''
                for i in range(0, len(name) - 1):
                    fname += ' ' + str(name[i])
                res.first_name = fname
                res.gender = applicant.gender.id
                res.birth_date = applicant.date_of_birth
                res.medical_subtype = self.env['hpl.sub.type'].search([('code', '=', '0001')]).id
                res.blood_group = applicant.blood_group_hpl
                res.marital_status = applicant.marital_status
                res.religion = applicant.religion
                res.nationality = self.env['hpl.nationality'].search([('code', '=', 'BD')]).id
                # Personal Information

                # Address Line
                add_lines = [(5, 0, 0)]
                pres_add_val = {
                    'address_type': self.env['hpl.address.type'].search([('code', '=', '3')]).id,
                    'street_house': applicant.present_address,
                }
                add_lines.append((0, 0, pres_add_val))

                perm_add_val = {
                    'address_type': self.env['hpl.address.type'].search([('code', '=', '1')]).id,
                    'street_house': str(applicant.village) + ', ' + str(applicant.post_office) + ', ' +
                                    str(applicant.police_station) + ', ' + str(applicant.district),
                }
                add_lines.append((0, 0, perm_add_val))

                print('lines: ', add_lines)
                res.address_line = add_lines
                # Address Line

                # Family Line
                family_lines = [(5, 0, 0)]
                father_val = {
                    'family_type': self.env['hpl.family.type'].search([('code', '=', '11')]).id,
                    'first_name': applicant.father,
                    'gender': self.env['hpl.gender'].search([('code', '=', '1')]).id
                }
                family_lines.append((0, 0, father_val))

                mother_val = {
                    'family_type': self.env['hpl.family.type'].search([('code', '=', '12')]).id,
                    'first_name': applicant.mother,
                    'gender': self.env['hpl.gender'].search([('code', '=', '2')]).id
                }
                family_lines.append((0, 0, mother_val))

                print('lines: ', family_lines)
                res.family_line = family_lines
                # Family Line

                # Education Line
                edu_lines = [(5, 0, 0)]
                ssc_val = {
                    'education_establishment_type': self.env['hpl.educational.establishment.type'].search([
                        ('code', '=', '21')]).id,
                    'result': applicant.ssc,
                    'other_degree': applicant.ssc_subject,
                    'institute': applicant.school,
                    'certificate': self.env['hpl.certificate'].search([('code', '=', '01')]).id,
                }
                edu_lines.append((0, 0, ssc_val))

                hsc_val = {
                    'education_establishment_type': self.env['hpl.educational.establishment.type'].search([
                        ('code', '=', '20')]).id,
                    'result': applicant.hsc,
                    'other_degree': applicant.hsc_subject,
                    'institute': applicant.college,
                    'certificate': self.env['hpl.certificate'].search([('code', '=', '01')]).id,
                }
                edu_lines.append((0, 0, hsc_val))

                grad_val = {
                    'education_establishment_type': self.env['hpl.educational.establishment.type'].search([
                        ('code', '=', '10')]).id,
                    'result': applicant.grad,
                    'other_degree': applicant.subject,
                    'institute': applicant.grad_university,
                    'certificate': self.env['hpl.certificate'].search([('code', '=', '01')]).id,
                }
                edu_lines.append((0, 0, grad_val))
                if applicant.post_grad_university:
                    post_grad_val = {
                        'education_establishment_type': self.env['hpl.educational.establishment.type'].search([
                            ('code', '=', '03')]).id,
                        'result': applicant.post_grad,
                        'other_degree': applicant.post_grad_subject,
                        'institute': applicant.post_grad_university,
                        'certificate': self.env['hpl.certificate'].search([('code', '=', '01')]).id,
                    }
                    edu_lines.append((0, 0, post_grad_val))

                print('lines: ', edu_lines)
                res.education_line = edu_lines
                # Education Line
                #
                # Communication Line
                com_lines = [(5, 0, 0)]
                mobile_val = {
                    'communication_type': self.env['hpl.communication.type'].search([('code', '=', '0004')]).id,
                    'value': applicant.partner_phone,
                }
                com_lines.append((0, 0, mobile_val))

                email_val = {
                    'communication_type': self.env['hpl.communication.type'].search([('code', '=', '0030')]).id,
                    'value': applicant.email_from,
                }
                com_lines.append((0, 0, email_val))

                print('lines: ', com_lines)
                res.communication_line = com_lines
                # Communication Line

                # Planned Working Data
                work_lines = [(5, 0, 0)]
                work_val = {
                    'working_schedule_rule': 'GNRL',
                    'time_management_status': '1 1 - Time evaluation of actual times',
                }
                work_lines.append((0, 0, work_val))
                res.working_line = work_lines
                # Planned Working Data

                # Previous Experience
                prev_exp_lines = [(5, 0, 0)]
                exp = self.env['prev.exp'].sudo().search([('app_nid_no', '=', applicant.nid_number)])
                if exp:
                    for val in exp:
                        companies = val.company_name
                        designations = val.designation
                        com_start_date = val.from_date
                        com_end_date = val.to_date
                        for i in range(0, len(companies)):
                            start_date = datetime.strptime(str(com_start_date[i]), '%Y-%m-%d')
                            end_date = datetime.strptime(str(com_end_date[i]), '%Y-%m-%d')
                            print(start_date, end_date)
                            exp_vals = {
                                'start_date': datetime.strptime(start_date.strftime('%Y/%m/%d'), '%Y/%m/%d'),
                                'end_date': datetime.strptime(end_date.strftime('%Y/%m/%d'), '%Y/%m/%d'),
                                'name_of_employer': companies[i],
                                'position': designations[i],
                            }
                            prev_exp_lines.append((0, 0, exp_vals))
                else:
                    if applicant.company_name:
                        if applicant.company_name.find(','):
                            companies = applicant.company_name.split(',')
                            designations = applicant.company_designation.split(',')
                            com_start_date = applicant.company_start_date.split(',')
                            com_end_date = applicant.company_end_date.split(',')

                            for i in range(0, len(companies)):
                                start_date = datetime.strptime(com_start_date[i], '%Y-%m-%d')
                                end_date = datetime.strptime(com_end_date[i], '%Y-%m-%d')
                                print(start_date, end_date)
                                exp_vals = {
                                    'start_date': datetime.strptime(start_date.strftime('%Y/%m/%d'), '%Y/%m/%d'),
                                    'end_date': datetime.strptime(end_date.strftime('%Y/%m/%d'), '%Y/%m/%d'),
                                    'name_of_employer': companies[i],
                                    'position': designations[i],
                                }
                                prev_exp_lines.append((0, 0, exp_vals))
                        else:
                            print('else')
                            exp_vals = {
                                'start_date': applicant.company_start_date,
                                'end_date': applicant.company_end_date,
                                'name_of_employer': applicant.company_name,
                                'position': applicant.company_designation,
                            }
                            prev_exp_lines.append((0, 0, exp_vals))
                print(prev_exp_lines)
                res.previous_employment_line = prev_exp_lines
                # Previous Experience

                # Personal Ids
                ids_lines = [(5, 0, 0)]
                ids_val = {
                    'id_type': self.env['hpl.id.type'].search([('code', '=', '02')]).id,
                    'identity_number': applicant.nid_number,
                }
                ids_lines.append((0, 0, ids_val))

                print('lines: ', ids_lines)
                res.personal_id_line = ids_lines
                # Personal Ids

                # Reference Line
                reference = self.env['employee.reference'].search([('employee_id', '=', applicant.id)])
                ref_lines = [(5, 0, 0)]
                ref_val = {
                    'company_name': reference.referee_occupation,
                    'name_of_referee': reference.referee_name,
                    'mobile': reference.referee_mobile,
                    'email': str(reference.referee_email),
                    'address': reference.referee_address,
                }
                print('ref val:', ref_val)
                ref_lines.append((0, 0, ref_val))

                print('lines: ', ref_lines)
                res.reference_line = ref_lines
                # Reference Line

                # Nominee Line
                nom_lines = [(5, 0, 0)]
                nominee = self.env['employee.nominee'].search([('employee_id', '=', applicant.id)])
                for nom in nominee.nominee_lines:
                    nom_val = {
                        'name_of_nominee': nom.name,
                        'relation': nom.relation,
                        'percent_of_share': nom.proportion,
                        'address': nom.sign_and_address,
                        'birth_date': nom.birthday,
                    }
                    nom_lines.append((0, 0, nom_val))
                print(nom_lines)
                res.nominee_line = nom_lines
                # Nominee Line

                # Training Line
                train_lines = [(5, 0, 0)]
                training = self.env['employee.training'].search([('employee_id', '=', applicant.id)])
                for train in training.training_lines:
                    train_val = {
                        'name_of_course': train.program,
                        'name_of_institution': train.institute,
                        'place_of_training': train.local,
                        'from_date': train.date_from,
                        'to_date': train.date_to,
                    }
                    train_lines.append((0, 0, train_val))
                print(train_lines)
                res.training_line = train_lines
                # Training Line
                print('i am here')

    @api.model
    def create(self, vals):
        if self.env['hpl.company.code'].search([('id', '=', vals['company_code'])]).code == '1000' \
                and self.env['hpl.employee.group'].search([('id', '=', vals['employee_group'])]).code != 'I':
            status = self.create_hpl_employee_api(vals)
        else:
            status = True

        if not status:
            raise ValidationError(_("Employee Not created in SAP."))

        irish_employee_status = self.create_irish_employee_api(vals)

        if not irish_employee_status:
            raise ValidationError(_("Employee Not created in IRISH Employee."))

        irish_nominee_status = self.create_irish_nominee_api(vals)
        if not irish_nominee_status:
            raise ValidationError(_("Employee Not created in IRISH Nominee."))

        res = super(HplEmployee, self).create(vals)
        lines = [(5, 0, 0)]
        val = {
            'action_date': self.env['hpl.action.date'].search([('action_type', '=', res.action_type.id)]).code,
            'date_type': res.action_type.id,
            'date_of_action': res.start_date,
        }
        lines.append((0, 0, val))
        res.date_line = lines
        res.action_type_change = False
        res.applicant.is_employee_created = True

        self.env['bulk.employee.create'].search([]).unlink()

        return res

    def create_hpl_employee_api(self, rec):
        header_post = Dictionary()
        header_post.add('Content-Type', 'application/json')
        is_prod = self.check_server_url()
        if is_prod:
            base_url = api_urls.prod_base_post
            header_post.add('Authorization',
                            'Basic' + ' ' + (base64.b64encode(bytes("HPLHRIS:qwer@1234".encode()))).decode())

        else:
            base_url = api_urls.test_base_post
            header_post.add('Authorization',
                            'Basic' + ' ' + (base64.b64encode(bytes("31144:HPL@1234".encode()))).decode())

        # # Organisational Assignment
        # org_url = base_url + 'ORGASG'
        # full_name = str(rec['first_name']) + ' ' + str(rec['last_name'])
        # org_data = [{
        #     "PERNR": rec['employee_id'],
        #     "ENDDA": rec['end_date'] if rec['end_date'] else '99991231' if 'end_date' in rec else '99991231',
        #     "BEGDA": str(rec['start_date']),
        #     "PLANS": rec['position'],
        #     "WERKS": self.env['hpl.personal.area'].search([('id', '=', rec['personal_area'])]).code,
        #     "PERSG": self.env['hpl.employee.group'].search([('id', '=', rec['employee_group'])]).code,
        #     "PERSK": self.env['hpl.employee.sub.group'].search([('id', '=', rec['employee_sub_group'])]).code,
        #     "BTRTL": self.env['hpl.personal.sub.area'].search([('id', '=', rec['personal_sub_area'])]).code,
        #     "ABKRS": self.env['hpl.payroll.area'].search([('id', '=', rec['payroll_area'])]).code,
        #     "ORGEH": rec['org_unit'],
        #     "VDSK1": self.env['hpl.personal.area'].search([('id', '=', rec['personal_area'])]).code,
        #     "STELL": rec['job_key'],
        #     "ZAREA": self.env['hpl.area'].search([('id', '=', rec['area'])]).code,
        #     "ENAME": full_name,
        #     "BUKRS": "1000",
        #     "SBMOD": self.env['hpl.personal.area'].search([('id', '=', rec['personal_area'])]).code,
        #     "KOKRS": "1000",
        #     "OTYPE": "S"
        # }]
        # print('data:', org_data)
        # r = requests.post(org_url, data=json.dumps(org_data), headers=header_post)
        # _logger.info("** org_status**")
        # _logger.info(r.text)
        # if r.status_code != 200:
        #     raise ValidationError(_("Something went Wrong in Organizational Assignment"))
        # # Organisational Assignment
        #
        # # Personal Information
        # gender = self.env['hpl.gender'].search([('id', '=', rec['gender'])]).code
        # if gender == '1':
        #     title = '1'
        # else:
        #     title = '4'
        # personal_url = base_url + 'PDATA'
        # personal_data = [{
        #     "PERNR": rec['employee_id'],
        #     "ENDDA": rec['end_date'] if rec['end_date'] else '99991231' if 'end_date' in rec else '99991231',
        #     "BEGDA": str(rec['start_date']),
        #     "ANRED": title,
        #     "NACHN": rec['last_name'],
        #     "NAME2": rec['middle_name'] if 'middle_name' in rec else '',
        #     "VORNA": rec['first_name'],
        #     "KNZNM": rec['name_format'] if 'name_format' in rec else '',
        #     "GESCH": self.env['hpl.gender'].search([('id', '=', rec['gender'])]).code,
        #     "GBDAT": rec['birth_date'],
        #     "GBORT": rec['birth_place'] if 'birth_place' in rec else '',
        #     "FAMST": self.env['hpl.marital.status'].search([('id', '=', rec['marital_status'])]).code,
        #     "FAMDT": rec['since'] if 'since' in rec else '',
        #     "GBLND": self.env['hpl.country'].search(
        #         [('id', '=', rec['country_of_birth'])]).code if 'country_of_birth' in rec else '',
        #     "ANZKD": rec['no_of_child'] if 'no_of_child' in rec else '',
        #     "GBDEP": self.env['hpl.division'].search([('id', '=', rec['division'])]).code if 'division' in rec else '',
        #     "KONFE": self.env['hpl.religion'].search([('id', '=', rec['religion'])]).code,
        #     "NATIO": self.env['hpl.nationality'].search([('id', '=', rec['nationality'])]).code,
        #     "SPRSL": "EN"
        # }]
        # print('personal_data: ', personal_data)
        # r = requests.post(personal_url, data=json.dumps(personal_data), headers=header_post)
        # _logger.info("** personal_status**")
        # _logger.info(r.text)
        # if r.status_code != 200:
        #     raise ValidationError(_("Something went Wrong in Personal Data"))
        # # Personal Information

        # Medical Data
        medical_url = base_url + 'INTMED'
        medical_data = [{
            "PERNR": rec['employee_id'],
            "ENDDA": rec['end_date'] if rec['end_date'] else '99991231' if 'end_date' in rec else '99991231',
            "BEGDA": str(rec['start_date']),
            "SUBTY": "0001",
            "EXDAT": rec['exam_date'] if 'exam_date' in rec else '',
            "LXDAT": rec['last_exam_date'] if 'last_exam_date' in rec else '',
            "RESUL": rec['result'] if 'result' in rec else '',
            "DIANR": rec['diagnosis_number'] if 'diagnosis_number' in rec else '',
            "SBJ01": "08",
            "NMF01": "",
            "WTF01": self.env['hpl.blood.group'].search([('id', '=', rec['blood_group'])]).code
        }]
        print('medical_data', medical_data)
        r = requests.post(medical_url, data=json.dumps(medical_data), headers=header_post)
        _logger.info("** medical status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Medical Data"))
        # Medical Data

        # Reference Data
        ref_url = base_url + 'REF'
        ref_data = []
        for ref in rec['reference_line']:
            data = {
                "PERNR": rec['employee_id'],
                "ENDDA": ref[-1]['end_date'] if ref[-1]['end_date'] else '99991231',
                "BEGDA": str(ref[-1]['start_date']),
                "ZREFER_NAME": ref[-1]['name_of_referee'],
                "ZRELATION": ref[-1]['relation'] if 'relation' in ref[-1] else '',
                "ZCOMPANY": ref[-1]['company_name'],
                "ZDESIG": ref[-1]['designation'] if 'designation' in ref[-1] else '',
                "ZMOBILE": ref[-1]['mobile'],
                "ZEMAIL": ref[-1]['email'],
                "ZADDRESS": ref[-1]['address']
            }
            ref_data.append(data)
        print('reference_data:', ref_data)
        r = requests.post(ref_url, data=json.dumps(ref_data), headers=header_post)
        _logger.info("** reference**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Reference Data"))
        # Reference Data

        # Education Data
        edu_url = base_url + 'EDUDET'
        edu_data = []
        for edu in rec['education_line']:
            data = {
                "PERNR": rec['employee_id'],
                "SUBTY": self.env['hpl.educational.establishment.type'].search(
                    [('id', '=', edu[-1]['education_establishment_type'])]).code,
                "ENDDA": edu[-1]['end_date'] if edu[-1]['end_date'] else '99991231',
                "BEGDA": str(edu[-1]['start_date']),
                "SLART": self.env['hpl.educational.establishment.type'].search(
                    [('id', '=', edu[-1]['education_establishment_type'])]).code,
                "AUSBI": "",
                "INSTI": edu[-1]['institute'],
                "SLAND": self.env['hpl.country'].search([('id', '=', edu[-1]['country'])]).code if 'country' in edu[
                    -1] else 'BD',
                "SLABS": self.env['hpl.certificate'].search([('id', '=', edu[-1]['certificate'])]).code,
                "EMARK": edu[-1]['result'],
                "ZPASS_YEAR": edu[-1]['passing_year'] if 'passing_year' in edu[-1] else '',
                "ZOTHER_DEGREE": edu[-1]['other_degree']
            }
            edu_data.append(data)
        print('edu_data:', edu_data)
        r = requests.post(edu_url, data=json.dumps(edu_data), headers=header_post)
        _logger.info("** edu_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Educational Data"))
        # Education Data

        # Address Data
        add_url = base_url + 'ADDRESS'
        add_data = []
        for add in rec['address_line']:
            data = {
                "PERNR": rec['employee_id'],
                "SUBTY": self.env['hpl.address.type'].search([('id', '=', add[-1]['address_type'])]).code,
                "ENDDA": add[-1]['end_date'] if add[-1]['end_date'] else '99991231',
                "BEGDA": str(add[-1]['start_date']),
                "ANSSA": self.env['hpl.address.type'].search([('id', '=', add[-1]['address_type'])]).code,
                "NAME2": add[-1]['care_of'] if 'care_of' in add[-1] else '',
                "STRAS": add[-1]['street_house'],
                "ORT01": add[-1]['city'] if 'city' in add[-1] else 'N/A',
                "PSTLZ": add[-1]['postal_code'] if 'postal_code' in add[-1] else '9999',
                "LAND1": self.env['hpl.country'].search([('id', '=', add[-1]['country'])]).code if 'country' in add[
                    -1] else 'BD',
                "TELNR": add[-1]['telephone_no'] if 'telephone_no' in add[-1] else '',
                "LOCAT": add[-1]['address_line_two'] if 'address_no' in add[-1] else '',
                "STATE": self.env['hpl.division'].search([('id', '=', add[-1]['division'])]).code if 'division' in add[
                    -1] else ''
            }
            add_data.append(data)
        print('add_data:', add_data)
        r = requests.post(add_url, data=json.dumps(add_data), headers=header_post)
        _logger.info("** address_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Address Data"))
        # Address Data

        # Family Data
        fam_url = base_url + 'FAMILY'
        fam_data = []
        for fam in rec['family_line']:
            data = {
                "PERNR": rec['employee_id'],
                "SUBTY": self.env['hpl.family.type'].search([('id', '=', fam[-1]['family_type'])]).code,
                "ENDDA": fam[-1]['end_date'] if fam[-1]['end_date'] else '99991231',
                "BEGDA": str(fam[-1]['start_date']),
                "FAMSA": self.env['hpl.family.type'].search([('id', '=', fam[-1]['family_type'])]).code,
                "FGBDT": str(fam[-1]['birth_date']) if 'birth_date' in fam[-1] else '19000101',
                "FGBLD": self.env['hpl.country'].search(
                    [('id', '=', fam[-1]['country_of_birth'])]).code if 'country_of_birth' in fam[-1] else '',
                "FANAT": self.env['hpl.nationality'].search(
                    [('id', '=', fam[-1]['nationality'])]).code if 'nationality' in fam[-1] else '',
                "FAVOR": fam[-1]['first_name'],
                "FANAM": fam[-1]['last_name'] if 'last_name' in fam[-1] else '.',
                "FGBOT": fam[-1]['birth_place'] if 'birth_place' in fam[-1] else '',
                "FGBNA": fam[-1]['middle_name'] if 'middle_name' in fam[-1] else ''
            }
            fam_data.append(data)
        _logger.info('fam_data')
        _logger.info(fam_data)
        r = requests.post(fam_url, data=json.dumps(fam_data), headers=header_post)
        _logger.info("** family_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Family Data"))
        # Family Data

        # Nominee Data
        nom_url = base_url + 'NOMINEE'
        nom_data = []
        flag = 1
        for nom in rec['nominee_line']:
            data = {
                "PERNR": rec['employee_id'],
                "SUBTY": "002",
                "ENDDA": nom[-1]['end_date'] if nom[-1]['end_date'] else '99991231',
                "SEQNR": str(flag),
                "BEGDA": str(nom[-1]['start_date']),
                "ZNMAE": nom[-1]['name_of_nominee'] if 'name_of_nominee' in nom[-1] else '',
                "ZADDRESS": nom[-1]['address'] if 'address' in nom[-1] else '',
                "ZSHARE": nom[-1]['percent_of_share'] if 'percent_of_share' in nom[-1] else '',
                "ZDOB": str(nom[-1]['birth_date']) if 'birth_date' in nom[-1] else '',
                "ZRELATION": nom[-1]['relation'] if 'relation' in nom[-1] else '',
                "ZNID": nom[-1]['nid_birth_certificate'] if 'nid_birth_certificate' in nom[-1] else '',
                "ZWITNESS1": nom[-1]['witness_one_name'] if 'witness_one_name' in nom[-1] else '',
                "ZWIT1_ADD1": nom[-1]['witness_one_address_one'] if 'witness_one_address_one' in nom[-1] else '',
                "ZWIT1_ADD2": nom[-1]['witness_one_address_two'] if 'witness_one_address_two' in nom[-1] else '',
                "ZWITNESS2": nom[-1]['witness_two_name'] if 'witness_two_name' in nom[-1] else '',
                "ZWIT2_ADD1": nom[-1]['witness_two_address_one'] if 'witness_two_address_one' in nom[-1] else '',
                "ZWIT2_ADD2": nom[-1]['witness_two_address_two'] if 'witness_two_address_two' in nom[-1] else ''
            }
            flag += 1
            nom_data.append(data)
        print('nom_data:', nom_data)
        _logger.info('nom_data')
        _logger.info(nom_data)
        r = requests.post(nom_url, data=json.dumps(nom_data), headers=header_post)
        _logger.info("** nominee_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Nominee Data"))
        # Nominee Data

        # Previous Employer
        prev_emp_url = base_url + 'OTHREMP'
        prev_emp_data = []
        if 'previous_employment_line' in rec:
            for prev in rec['previous_employment_line']:
                data = {
                    "PERNR": rec['employee_id'],
                    "ENDDA": str(prev[-1]['end_date']) if prev[-1]['end_date'] else '99991231',
                    "BEGDA": str(prev[-1]['start_date']),
                    "ARBGB": prev[-1]['name_of_employer'],
                    "LAND1": self.env['hpl.country'].search([
                        ('id', '=', prev[-1]['country'])]).code if 'country' in prev[-1] else '',
                    "ZPOSITION": prev[-1]['position'],
                    "ZDEPARTMENT": prev[-1]['department'] if 'department' in prev[-1] else ''
                }
                prev_emp_data.append(data)
        print('Prev_emp_data:', prev_emp_data)
        r = requests.post(prev_emp_url, data=json.dumps(prev_emp_data), headers=header_post)
        _logger.info("** prev_employment_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Previous Employer Data"))
        # Previous Employer

        # Personal IDS
        personal_ids_url = base_url + 'PERID'
        personal_ids_data = []
        for ids in rec['personal_id_line']:
            data = {
                "PERNR": rec['employee_id'],
                "SUBTY": self.env['hpl.id.type'].search([('id', '=', ids[-1]['id_type'])]).code,
                "ENDDA": ids[-1]['end_date'] if ids[-1]['end_date'] else '99991231',
                "BEGDA": str(ids[-1]['start_date']),
                "ICTYP": self.env['hpl.id.type'].search([('id', '=', ids[-1]['id_type'])]).code,
                "ICNUM": ids[-1]['identity_number'],
                "ICOLD": ids[-1]['previous_identity_number'] if 'previous_identity_number' in ids[-1] else ''
            }
            personal_ids_data.append(data)
        print('prev_ids_data:', personal_ids_data)
        r = requests.post(personal_ids_url, data=json.dumps(personal_ids_data), headers=header_post)
        _logger.info("** personal_ids_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Personal ID Data"))
        # Personal IDS

        # Communication Data
        com_url = base_url + 'COMM'
        com_data = []
        for comm in rec['communication_line']:
            com_type = self.env['hpl.communication.type'].search([('id', '=', comm[-1]['communication_type'])]).code
            data = {
                "PERNR": rec['employee_id'],
                "SUBTY": com_type,
                "ENDDA": comm[-1]['end_date'] if comm[-1]['end_date'] else '99991231',
                "BEGDA": str(comm[-1]['start_date']),
                "USRTY": com_type,
                "USRID": comm[-1]['value'] if com_type == '0004' else "",
                "USRID_LONG": comm[-1]['value'] if com_type == '0030' else ""
            }
            com_data.append(data)
        print('comm_data:', com_data)
        r = requests.post(com_url, data=json.dumps(com_data), headers=header_post)
        _logger.info("** communication_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Communication Data"))
        # Communication Data

        # Date Specification
        date_url = base_url + 'DATESPEC'
        date_data = [{
            "PERNR": rec['employee_id'],
            "ENDDA": rec['end_date'] if rec['end_date'] else '99991231' if 'end_date' in rec else '99991231',
            "BEGDA": str(rec['start_date']),
            "DAR01": self.env['hpl.action.date'].search([('action_type', '=', rec['action_type'])]).code,
            "DAT01": str(rec['start_date'])
        }]
        print('date_data:', date_data)
        r = requests.post(date_url, data=json.dumps(date_data), headers=header_post)
        _logger.info("** Date Spec**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Date Spec Data"))
        # Date Specification

        # Planned Working Schedule
        work_url = base_url + 'PLNWOR'
        work_data = [{
            "PERNR": rec['employee_id'],
            "ENDDA": "99991231",
            "BEGDA": str(rec['start_date']),
            "SCHKZ": "GNRL",
            "ZTERF": "9 9",
            "ARBST": "8.50",
            "EMPCT": "100.00",
            "WOSTD": "51.00",
            "MOSTD": "204.00",
            "JRSTD": "2448.00",
            "WKWDY": "6.00"
        }]
        print('work_data:', date_data)
        r = requests.post(work_url, data=json.dumps(work_data), headers=header_post)
        _logger.info("** Work Status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Work Data"))
        # Planned Working Schedule

        # Internal Data
        internal_url = base_url + 'INDATA'
        internal_data = []
        for internal in rec['internal_line']:
            data = {
                "PERNR": rec['employee_id'],
                "ENDDA": internal[-1]['end_date'] if internal[-1]['end_date'] else '99991231',
                "BEGDA": str(internal[-1]['start_date']),
                "PNALT": internal[-1]['prev_personal_no']
            }
            internal_data.append(data)
        print('internal_data:', internal_data)
        r = requests.post(internal_url, data=json.dumps(internal_data), headers=header_post)
        _logger.info("** internal_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Internal Data"))
        # Internal Data

        # Action Data
        action_url = base_url + 'ACTION'
        action_data = [{
            "PERNR": rec['employee_id'],
            "ENDDA": rec['end_date'] if rec['end_date'] else '99991231' if 'end_date' in rec else '99991231',
            "BEGDA": str(rec['start_date']),
            "MASSN": self.env['hpl.action.type'].search([('id', '=', rec['action_type'])]).code,
            "MASSG": self.env['hpl.reason.for.action'].search([('id', '=', rec['reason_for_action'])]).code,
            "STAT1": "1",
            "STAT2": self.env['hpl.employment'].search([('id', '=', rec['employment'])]).code,
            "STAT3": "1"
        }]
        print('Action Data:', action_data)
        r = requests.post(action_url, data=json.dumps(action_data), headers=header_post)
        _logger.info("** action_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Action Data"))
        # Action Data

        # Training Data
        training_url = base_url + 'TRAINING'
        training_data = []
        if 'training_line' in rec:
            for train in rec['training_line']:
                data = {
                    "PERNR": rec['employee_id'],
                    "ENDDA": train[-1]['end_date'] if train[-1]['end_date'] else '99991231',
                    "BEGDA": str(train[-1]['start_date']),
                    "ZTRAINING_NO": train[-1]['no_of_course'] if 'no_of_course' in train[-1] else '',
                    "ZTRAINING_NAME": train[-1]['name_of_course'],
                    "ZINSTITUTE_NAME": train[-1]['name_of_institution'],
                    "ZPLACE": train[-1]['place_of_training'],
                    "ZDURATION": str(train[-1]['from_date']) + '-' + str(train[-1]['to_date']),
                    "ZTIME": "Days"
                }
                training_data.append(data)
        print('training_data:', training_data)
        r = requests.post(training_url, data=json.dumps(training_data), headers=header_post)
        _logger.info("** training_status**")
        _logger.info(r.text)
        if r.status_code != 200:
            raise ValidationError(_("Something went Wrong in Training Data"))
        # Training Data

        # Additional Action
        # add_action_url = base_url + 'ADDACTION'
        # add_action_data = [{
        #     "PERNR": rec['employee_id'],
        #     "ENDDA": rec['end_date'] if rec['end_date'] else '99991231' if 'end_date' in rec else '99991231',
        #     "BEGDA": str(rec['start_date']),
        #     "MASSN": self.env['hpl.action.type'].search([('id', '=', rec['action_type'])]).code,
        #     "MASSG": self.env['hpl.reason.for.action'].search([('id', '=', rec['reason_for_action'])]).code
        # }]
        # print('Additional Action:', add_action_data)
        # r = requests.post(add_action_url, data=json.dumps(add_action_data), headers=header_post)
        # _logger.info("** Add Action**")
        # _logger.info(r.text)
        # if r.status_code != 200:
        #     raise ValidationError(_("Something went Wrong in Add Action Data"))
        # # Additional Action

        return True

    def create_irish_nominee_api(self, rec):
        is_prod = self.check_server_url()
        if is_prod:
            irish_nominee_url = api_urls.prod_nominee_irish_url
        else:
            irish_nominee_url = api_urls.test_nominee_irish_url
        sl = 1
        if 'nominee_line' in rec:
            for line in rec['nominee_line']:
                dob = (datetime.strptime(str(line[2]['birth_date']), '%Y-%m-%d')).strftime("%d/%m/%Y")
                irish_nominee_data = {
                    "interface": "RestAPI",
                    "method": "Insert_into_HRIS_Employee_Nominee",
                    "parameters": {
                        "empnominee": {
                            "NomineeSL": sl,
                            "SAPEmpCode": rec['employee_id'],
                            "NomineeName": line[2]['name_of_nominee'],
                            "NomineeDOB": dob,
                            "Relation": line[2]['relation'],
                            "ProportionPercentOfPayable": line[2]['percent_of_share'],
                            "NomineeAddress": line[2]['address'],
                            "CreatedBy": self.env.user.name
                        }
                    }
                }
                sl += 1
                r = requests.post(irish_nominee_url, data=json.dumps(irish_nominee_data))
                _logger.info("** Nominee status**")
                _logger.info(r.text)
                if r.status_code != 200:
                    raise ValidationError(_("Something went Wrong in IRISH Nominee Data"))

            return True

    def create_irish_employee_api(self, rec):
        print('create_irish_employee_api')
        is_prod = self.check_server_url()
        if is_prod:
            irish_employee_url = api_urls.prod_employee_insert_irish_url
        else:
            irish_employee_url = api_urls.test_employee_insert_irish_url

        employee_f_name = str(rec['first_name']) if 'first_name' in rec else ''
        employee_s_name = str(rec['middle_name']) if 'middle_name' in rec else ''
        employee_t_name = str(rec['last_name']) if 'last_name' in rec else ''
        full_name = employee_f_name + employee_s_name + employee_t_name
        legacy_id = ''
        if 'internal_line' in rec:
            for line in rec['internal_line']:
                if line[2]['prev_personal_no']:
                    legacy_id = line[2]['prev_personal_no']
                    break

        father_name = ''
        mother_name = ''
        email = ''  # 0030
        off_email = ''  # 0010
        cell_phone = ''  # 0020
        nid = ''
        present_address = ''
        permanent_address = ''
        if 'family_line' in rec:
            for family in rec['family_line']:
                if 'family_type' in family[2]:
                    if family[2]['family_type'] == 11:
                        father_name_first = family[2]['first_name'] if 'first_name' in family[2] else ''
                        father_name_middle = family[2]['first_name'] if 'middle_name' in family[2] else ''
                        father_name_last = family[2]['first_name'] if 'last_name' in family[2] else ''
                        father_name += father_name_first + father_name_middle + father_name_last

                    elif family[2]['family_type'] == 12:
                        mother_name_first = family[2]['first_name'] if 'first_name' in family[2] else ''
                        mother_name_middle = family[2]['first_name'] if 'middle_name' in family[2] else ''
                        mother_name_last = family[2]['first_name'] if 'last_name' in family[2] else ''
                        mother_name += mother_name_first + mother_name_middle + mother_name_last

        if 'address_line' in rec:
            for address in rec['address_line']:
                if 'address_type' in address[2]:
                    if 'address_type' in address[2]:
                        if address[2]['address_type'] == 3:
                            if address[2]['street_house']:
                                present_address = address[2]['street_house']

                        elif address[2]['address_type'] == 4:
                            if address[2]['street_house']:
                                permanent_address = address[2]['street_house']

        if 'communication_line' in rec:
            for comm in rec['communication_line']:
                co = self.env['hpl.communication.type'].search(
                    [('id', '=', int(comm[2]['communication_type']))]).code,
                for communication_type_code in co:
                    if 'value' in comm[2]:
                        if communication_type_code == '0030':
                            email = comm[2]['value']
                        elif communication_type_code == '0010':
                            off_email = comm[2]['value']
                        elif communication_type_code == '0004':
                            cell_phone = comm[2]['value']

        if 'personal_id_line' in rec:
            for info in rec['personal_id_line']:
                id_type = self.env['hpl.id.type'].search([('id', '=', info[2]['id_type'])]).code,
                for ids in id_type:
                    if ids == '02':
                        nid = info[2]['identity_number']

        join_date = ((datetime.strptime(str(rec['start_date']), '%Y-%m-%d')).strftime("%d/%m/%Y")) if 'start_date' in rec else ''
        birth_date = ((datetime.strptime(str(rec['birth_date']), '%Y-%m-%d')).strftime("%d/%m/%Y")) if 'end_date' in rec else ''
        irish_employee_data = {
            "interface": "RestAPI",
            "method": "Insert_into_HRIS_Employee",
            "parameters": {
                "empinfo": {
                    "LegacyEmpCode": legacy_id,
                    "SAPEmpCode": rec['employee_id'],
                    "FullName": full_name,
                    "DateOfJoin": join_date,
                    "Designation": rec['position_name'],
                    "Department": self.env['hr.department'].search([('id', '=', rec['department'])]).name,
                    "FatherName": father_name,
                    "MotherName": mother_name,
                    "Gender": self.env['hpl.gender'].search([('id', '=', rec['gender'])]).name,
                    "DateOfBirth": birth_date,
                    "Nationality": 'Bangladeshi',
                    "Religion": self.env['hpl.religion'].search([('id', '=', rec['religion'])]).name,
                    "BloodGroup": self.env['hpl.blood.group'].search([('id', '=', rec['blood_group'])]).name,
                    "IsMarried": 'Y' if self.env['hpl.marital.status'].search(
                        [('id', '=', rec['marital_status'])]) else 'N',
                    "PlaceofBirth":  rec['birth_place'] if 'birth_place' in rec else '',
                    "PresentAddress": present_address,
                    "PermanentAddress": permanent_address,
                    "MailingAddress": permanent_address,
                    "CellPhone": cell_phone,
                    "Email": email,
                    "OfficialEmail": off_email,
                    "EmployeeType": self.env['hpl.employee.sub.group'].search(
                        [('id', '=', rec['employee_sub_group'])]).name,
                    "NID": nid,
                    "CreatedBy": self.env.user.name
                }
            }
        }
        print("IRISH Employee Data:", irish_employee_data)
        r = requests.post(irish_employee_url, data=json.dumps(irish_employee_data))
        _logger.info("** IRISH  Employee status**")
        _logger.info(r.text)
        print("r", r.status_code)
        print("r_type", type(r))
        if r.status_code != 200:
            print("---------wrong---------")
            raise ValidationError(_("Something went Wrong in IRISH Employee Data"))
        else:
            return True

    def write(self, vals):
        res = super(HplEmployee, self).write(vals)
        return res

    def update_employee_daily(self):
        print("Daily Update Started")
        header_obj = Dictionary()
        header_obj.add('Content-Type', 'application/json')
        is_prod = self.check_server_url()

        if is_prod:
            auth = (api_urls.prod_username, api_urls.prod_password)

            url = api_urls.prod_base_post + 'ORGASG'
            r_org = requests.get(url, auth=auth, headers=header_obj)

            url_action = api_urls.prod_base_post + 'ADDACTION'
            r_action = requests.get(url_action, auth=auth, headers=header_obj)

            url_spec = api_urls.prod_base_post + 'DATESPEC'
            r_spec = requests.get(url_spec, auth=auth, headers=header_obj)

        else:
            url = api_urls.test_base_post + 'ORGASG'
            r_org = requests.get(url, headers=header_obj)

            url_action = api_urls.test_base_post + 'ADDACTION'
            r_action = requests.get(url_action, headers=header_obj)

            url_spec = api_urls.test_base_post + 'DATESPEC'
            r_spec = requests.get(url_spec, headers=header_obj)

        if r_org.status_code == 200 and r_action.status_code == 200 and r_spec.status_code == 200:
            org_data = r_org.json()
            print('data:', org_data)
            _logger.info("** data **")
            _logger.info(org_data)

        else:
            raise ValidationError(_("Something went Wrong"))


class Dictionary(dict):

    # __init__ function
    def __init__(self):
        self = dict()

        # Function to add key:value

    def add(self, key, value):
        self[key] = value


class HplEmployeeAddress(models.Model):
    _name = 'hpl.employee.address'
    _description = 'HPL Employee Address'

    address_id = fields.Many2one('hpl.employee', string='Address ID')
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    address_type = fields.Many2one('hpl.address.type', string='Address Type')
    # address_type = fields.Char(string='Address Type')
    city = fields.Char(string='City')
    division = fields.Many2one('hpl.division', string='Division')
    country = fields.Many2one('hpl.country', string='Country Key')
    care_of = fields.Char(string='Care of')
    street_house = fields.Text(string='Street And House No')
    address_line_two = fields.Text(string='Address Line Two')
    postal_code = fields.Char(string='Postal Code')
    district = fields.Char(string='District')
    telephone_no = fields.Char(string='Telephone No')


class HplEmployeeFamily(models.Model):
    _name = 'hpl.employee.family'
    _description = 'HPL Employee Family'

    family_id = fields.Many2one('hpl.employee', string='Family ID')
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    family_type = fields.Many2one('hpl.family.type', string='Family Member Type')
    # family_type = fields.Char(string='Family Member')
    initial = fields.Char(string='Initial', required=False)
    last_name = fields.Char(string='Last Name', required=False)
    middle_name = fields.Char(string='Middle Name', required=False)
    first_name = fields.Char(string='First Name', required=False)
    name_format = fields.Many2one('hpl.name.format', string='Name Format')
    gender = fields.Many2one('hpl.gender', string='Gender')
    birth_date = fields.Date(string='Birth Date', required=False)
    birth_place = fields.Char(string='Birth Place', required=False)
    country_of_birth = fields.Many2one('hpl.country', string='Country of Birth')
    nationality = fields.Many2one('hpl.nationality', string='Nationality')
    full_name = fields.Char(string='Full Name', default='', compute='_compute_full_name')

    @api.depends('last_name', 'middle_name', 'first_name')
    def _compute_full_name(self):
        for emp in self:
            if emp.middle_name:
                emp.full_name = str(emp.first_name) + ' ' + str(emp.middle_name) \
                                + ' ' + str(emp.last_name)
            else:
                emp.full_name = str(emp.first_name) + ' ' + str(emp.last_name)


class HplEmployeeReference(models.Model):
    _name = 'hpl.employee.reference'
    _description = 'HPL Employee Reference'

    ref_id = fields.Many2one('hpl.employee', string='Ref ID')
    # employee_id = fields.Many2one(related='ref_id.employee_id', string='Employee ID', readonly=True)
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    name_of_referee = fields.Char(string='Name of Referee', required=False)
    relation = fields.Char(string='Relation', required=False)
    company_name = fields.Char(string='Company', required=False)
    designation = fields.Char(string='Designation', required=False)
    mobile = fields.Char(string='Mobile Number', required=False)
    email = fields.Char(string='Email Address', required=False)
    address = fields.Text(string='Address', required=False)


class HplEmployeeNominee(models.Model):
    _name = 'hpl.employee.nominee'
    _description = 'HPL Employee Nominee'

    nom_id = fields.Many2one('hpl.employee', string='Nom ID')
    # employee_id = fields.Many2one(related='ref_id.employee_id', string='Employee ID', readonly=True)
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    name_of_nominee = fields.Char(string='Name of Nominee', required=False)
    address = fields.Text(string='Address', required=False)
    relation = fields.Char(string='Relation', required=False)
    birth_date = fields.Date(string='Birth Date', required=False)
    percent_of_share = fields.Char(string='Percent of Share', required=False)
    nid_birth_certificate = fields.Char(string='NID/Birth Certificate', required=False)
    witness_one_name = fields.Char(string='Witness One Name', required=False)
    witness_one_address_one = fields.Char(string='Witness One Address One', required=False)
    witness_one_address_two = fields.Char(string='Witness One Address Two', required=False)
    witness_two_name = fields.Char(string='Witness Two Name', required=False)
    witness_two_address_one = fields.Char(string='Witness Two Address One', required=False)
    witness_two_address_two = fields.Char(string='Witness Two Address Two', required=False)


class HplEmployeeEducation(models.Model):
    _name = 'hpl.employee.education'
    _description = 'HPL Employee Education'

    edu_id = fields.Many2one('hpl.employee', string='Edu ID')
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    education_establishment_type = fields.Many2one('hpl.educational.establishment.type',
                                                   string='Education Establishment Type')
    education_training = fields.Char(string='Education And Training', required=False)
    institute = fields.Char(string='Institute/Location of Training', required=False)
    country = fields.Many2one('hpl.country', string='Country')
    certificate = fields.Many2one('hpl.certificate', string='Certificate')
    result = fields.Char(string='Final Result')
    passing_year = fields.Char(string='Passing Year', required=False)
    other_degree = fields.Char(string='Other Degree', required=False)


class HplEmployeePreviousEmployment(models.Model):
    _name = 'hpl.employee.previous.employment'
    _description = 'HPL Employee Previous Employment'

    prev_employment_id = fields.Many2one('hpl.employee', string='Prev Employment ID')
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    name_of_employer = fields.Char(string='Name of Employer', required=False)
    country = fields.Many2one('hpl.country', string='Country')
    city = fields.Char(string='City')
    position = fields.Char(string='Position', required=False)
    department = fields.Char(string='Department', required=False)
    postal_code = fields.Char(string='Postal Code', required=False)
    contact_details = fields.Char(string='Contact Details', required=False)
    address = fields.Text(string='Address', required=False)


class HplEmployeePersonalIds(models.Model):
    _name = 'hpl.employee.personal.ids'
    _description = 'HPL Employee Personal Ids'

    personal_id = fields.Many2one('hpl.employee', string='Personal ID')
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    id_type = fields.Many2one('hpl.id.type', string='Id Type')
    identity_number = fields.Char(string='ID Number', required=False)
    color = fields.Char(string='ID Color', required=False)
    previous_identity_number = fields.Char(string='Previous ID Number', required=False)
    author = fields.Char(string='Author', required=False)
    place_of_issue = fields.Char(string='Plcae Of Issue', required=False)
    issue_number = fields.Char(string='Issuing Number', required=False)
    date_of_issue = fields.Date(string='Date Of Issue')
    valid_to = fields.Date(string='Valid To')
    country = fields.Many2one('hpl.country', string='Country')


class HplEmployeeCommunication(models.Model):
    _name = 'hpl.employee.communication'
    _description = 'HPL Employee Communication'

    comm_id = fields.Many2one('hpl.employee', string='Communication ID')
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    communication_type = fields.Many2one('hpl.communication.type', string='Communication Type')
    communication_type_code = fields.Char(string='Communication Type code', compute='_compute_communication_type_code')
    value = fields.Char(string='Value')

    @api.depends('communication_type')
    def _compute_communication_type_code(self):
        for emp in self:
            emp.communication_type_code = emp.communication_type.code


class HplDateSpecification(models.Model):
    _name = 'hpl.employee.date.specification'
    _description = 'HPL Employee Date Specification'

    date_spec_id = fields.Many2one('hpl.employee', string='Date Spec ID')
    action_date = fields.Many2one('hpl.action.date', string='Date Type')
    date_type = fields.Many2one('hpl.action.type', string='Action Type')
    date_of_action = fields.Date(string='Date Of Action', required=False)


class HplTrainingSchedule(models.Model):
    _name = 'hpl.employee.training'
    _description = 'HPL Employee Training'

    training_id = fields.Many2one('hpl.employee', string='Training ID')
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    no_of_course = fields.Char(string='No Of Course')
    name_of_course = fields.Char(string='Name Of Course')
    name_of_institution = fields.Char(string='Name Of Institution')
    place_of_training = fields.Char(string='Place Of Training')
    from_date = fields.Date(string='Course Start Date', required=False)
    to_date = fields.Date(string='Course End Date', required=False)


class HplEmployeeInternalData(models.Model):
    _name = 'hpl.employee.internal.data'
    _description = 'HPL Employee Internal Data'

    internal_id = fields.Many2one('hpl.employee', string='Internal ID')
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    prev_personal_no = fields.Char(string='Previous Personal No')


class HplEmployeeWorkingSchedule(models.Model):
    _name = 'hpl.employee.working.schedule'
    _description = 'HPL Employee Working Data'

    working_id = fields.Many2one('hpl.employee', string='Internal ID')
    start_date = fields.Date(string='Start Date', required=False, default=datetime.today())
    end_date = fields.Date(string='End Date', required=False)
    working_schedule_rule = fields.Char(string='Working Schedule Rule', default='GNRL')
    time_management_status = fields.Char(string='Time Management Status',
                                         default='1 1 - Time evaluation of actual times')
    employment_percent = fields.Float(string='Employment Percent', default=100.00)
    daily_working_hours = fields.Float(string='Daily Working Hours', default=8.50)
    weekly_working_hours = fields.Float(string='Weekly Working Hours', default=51.00)
    monthly_working_hours = fields.Float(string='Monthly Working Hours', default=204.00)
    annual_working_hours = fields.Float(string='Annual Working Hours', default=2448.00)
    weekly_workdays = fields.Float(string='Weekly Workdays', default=6.00)
