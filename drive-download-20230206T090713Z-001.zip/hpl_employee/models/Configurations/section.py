# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class Section(models.Model):
    _name = 'hr.section'
    _description = 'Section Name'
    # _rec_name = 'rec_section'

    department_id = fields.Many2one('hr.department', string='Department')
    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Section Name', required=True)
    rec_section = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_section = str(res.name) + ' (' + str(res.code) + ')'

