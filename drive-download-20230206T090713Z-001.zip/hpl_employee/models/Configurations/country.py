# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class Country(models.Model):
    _name = 'hpl.country'
    _description = 'Country'
    # _rec_name = 'rec_country'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    rec_country = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_country = str(res.name) + ' (' + str(res.code) + ')'
