# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class PersonalArea(models.Model):
    _name = 'hpl.personal.area'
    _description = 'Personal Area'
    # _rec_name = 'rec_per_area'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    rec_per_area = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_per_area = str(res.name) + ' (' + str(res.code) + ')'
