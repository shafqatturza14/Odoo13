# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class HPLEmployment(models.Model):
    _name = 'hpl.employment'
    _description = 'HPL Employment'
    # _rec_name = 'rec_employment'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    rec_employment = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_employment = str(res.name) + ' (' + str(res.code) + ')'

