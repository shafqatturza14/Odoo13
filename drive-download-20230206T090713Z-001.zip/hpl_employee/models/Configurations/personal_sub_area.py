# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class PersonalSubArea(models.Model):
    _name = 'hpl.personal.sub.area'
    _description = 'Personal Sub Area'
    # _rec_name = 'rec_sub_area'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    personal_area = fields.Many2one('hpl.personal.area', string='Personal Area', required=True)
    rec_sub_area = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_sub_area = str(res.name) + ' (' + str(res.code) + ')'
