# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class ActionDate(models.Model):
    _name = 'hpl.action.date'
    _description = 'Hpl Action Date'
    # _rec_name = 'rec_action'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    action_type = fields.Many2one('hpl.action.type', string='Action Type', required=True)
    rec_action = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_action = str(res.name) + ' (' + str(res.code) + ')'
