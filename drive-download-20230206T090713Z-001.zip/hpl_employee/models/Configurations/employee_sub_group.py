# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class EmployeeSubGroup(models.Model):
    _name = 'hpl.employee.sub.group'
    _description = 'Employee Sub Group'
    # _rec_name = 'rec_sub_group'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    employee_group = fields.Many2one('hpl.employee.group', string='Employee Group', required=True)
    rec_sub_group = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_sub_group = str(res.name) + ' (' + str(res.code) + ')'

