# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class PayrollArea(models.Model):
    _name = 'hpl.payroll.area'
    _description = 'Payroll Area'
    # _rec_name = 'rec_pay_area'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    rec_pay_area = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_pay_area = str(res.name) + ' (' + str(res.code) + ')'
