# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class City(models.Model):
    _name = 'hpl.reason.for.action'
    _description = 'Hpl Reason For Action'
    # _rec_name = 'rec_rfa'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    action_type = fields.Many2one('hpl.action.type', string='Action Code', required=True)
    rec_rfa = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_rfa = str(res.name) + ' (' + str(res.code) + ')'
