# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class HPLAddressType(models.Model):
    _name = 'hpl.address.type'
    _description = 'HPL Address Type'
    # _rec_name = 'rec_add_type'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    rec_add_type = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_add_type = str(res.name) + ' (' + str(res.code) + ')'
