# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class BusinessUnit(models.Model):
    _name = 'business.unit'
    _description = 'Business Unit'
    # _rec_name = 'rec_business'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Business Unit', required=True)
    rec_business = fields.Char(string='Search', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_business = str(res.name) + ' (' + str(res.code) + ')'
