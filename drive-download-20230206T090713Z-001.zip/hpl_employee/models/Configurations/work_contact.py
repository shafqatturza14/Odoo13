# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class WorkContract(models.Model):
    _name = 'hpl.work.contract'
    _description = 'Hpl Work Contract'
    # _rec_name = 'rec_wc'

    code = fields.Char(string='Code', required=True)
    name = fields.Char(string='Name', required=True)
    rec_wc = fields.Char(string='Search', default='', compute='_compute_fields_search', store=True)

    @api.depends('code', 'name')
    def _compute_fields_search(self):
        for res in self:
            if res.name and res.code:
                res.rec_wc = str(res.name) + ' (' + str(res.code) + ')'
