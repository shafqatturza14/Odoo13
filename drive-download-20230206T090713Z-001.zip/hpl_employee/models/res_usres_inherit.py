from odoo import fields, models, api


class User(models.Model):
    _inherit = 'res.users'

    selected_company = fields.Many2one('company.list', string='Selected Company')

    @api.model
    def create(self, values):
        res = super(User, self).create(values)
        if self.selected_company:
            company = self.env['res.company'].search([], limit=1)
            company.write({
                'selected_sister': company.id
            })

        return res

    def write(self, values):
        res = super(User, self).write(values)
        print(self.selected_company)
        if self.selected_company:
            company = self.env['res.company'].search([], limit=1)
            company.write({
                'selected_sister': self.selected_company.id
            })
            print('selected:', company.selected_sister)
        return res
