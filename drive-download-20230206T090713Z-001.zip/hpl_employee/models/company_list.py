# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class CompanyList(models.Model):
    _name = 'company.list'
    _description = 'Company List'

    name = fields.Char(string='Company Name')
    company_address = fields.Char(string='Company Address')
    logo = fields.Image(string='Logo')


class ResCompany(models.Model):
    _inherit = 'res.company'
    
    selected_sister = fields.Many2one('company.list', string='Company Selected', store=True)
