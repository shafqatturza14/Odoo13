from odoo import models
from datetime import datetime, timedelta, date

class IDCArdReportXLSX(models.AbstractModel):
    _name = 'report.hpl_employee.report_id_card_xlx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, rows):
        report_name = 'Sheet1'
        sheet = workbook.add_worksheet(report_name)
        bold = workbook.add_format({'font_size': 12, 'align': 'center', 'bold': True, 'text_wrap': True})
        bold.set_align('vcenter')
        normal = workbook.add_format({'font_size': 12})

        # sheet.write(1, 3, 'Employee Name', bold)

        label_names = [
            'SL',
            'Legacy ID',
            'SAP ID',
            'Name',
            'Designation',
            'Department',
            'Date of Joining',
            'Blood Group',
            'National ID',
            'Nature of Work (Permanent / Contractual)',
            'Posting Place',
            'Permanent Address',
            'Emergency Contact No'
        ]

        for i, label in enumerate(label_names):
            sheet.write(0, i, label, bold)
            sheet.set_row(0, 50)
            sheet.set_column(0, 0, 5)
            sheet.set_column(1, 2, 15)
            sheet.set_column(3, 3, 40)
            sheet.set_column(4, 10, 20)
            sheet.set_column(11, 11, 40)
            sheet.set_column(12, 12, 20)

        for i, item in enumerate(rows, start=1):
            name = item.full_name
            date_of_join = item.start_date
            posting_place = item.personal_area.name
            addr_flag = 0
            for address in item.address_line:
                if address.address_type.code == '1' and addr_flag == 0:
                    parm_address = address.street_house  # parm address code = 1
                    addr_flag += 1

            id_flag = 0
            nid = ''
            for ids in item.personal_id_line:
                if ids.id_type.code == '02' and id_flag == 0:
                    nid = ids.identity_number  # NID No code = 1
                    id_flag += 1
            phone_flag = 0
            phone = ''
            for communication in item.communication_line:
                if communication.communication_type_code == '0003' and phone_flag == 0:
                    phone = communication.value
                    phone_flag += 1
            join_date = date_of_join.strftime("%b %d %Y")
            data_list = [
                    i or '',  # 'Sl. No.'
                    item.employee_id or '',  # 'Emp ID'
                    item.employee_id or '',  # 'SAP ID'
                    name or '',  # 'Employee Name'
                    item.position or '',  # 'Designation'
                    item.department.name or '',  # 'Department'
                    join_date or '',  # 'Date of Joining'
                    item.blood_group.name or '',  # 'Blood Group'
                    nid or '',  # 'NID'
                    item.employee_group.name or '',  # 'Nature of Work'
                    posting_place or '',  # 'Posting Place'
                    parm_address or '',  # 'Permanent Address'
                    phone or '',  # 'Emergency Contact No'
                ]

            for j, data_item in enumerate(data_list):
                sheet.write(i, j, data_item, normal)
