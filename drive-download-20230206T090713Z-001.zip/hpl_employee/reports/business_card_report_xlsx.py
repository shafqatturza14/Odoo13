from odoo import models


class HRReportXLSX(models.AbstractModel):
    _name = 'report.hpl_employee.report_business_card_xlx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, rows):
        report_name = 'Sheet1'
        sheet = workbook.add_worksheet(report_name)
        bold = workbook.add_format({'font_size': 12, 'align': 'center', 'bold': True, 'text_wrap': True})
        bold.set_align('vcenter')
        normal = workbook.add_format({'font_size': 12})

        # sheet.write(1, 3, 'Employee Name', bold)

        label_names = [
            'SL',
            'E-ID',
            'SAP ID',
            'Name',
            'Last Academic Degree ',
            'Designation',
            'Department',
            'Cell Number',
            'Email',
            'Depo Address',
            'Posting Place',
            'Card Format (Oncology, Biotec, Lilly, Vaccine)',
            'QR Code(Required/Not Required) '
        ]

        for i, label in enumerate(label_names):
            sheet.write(0, i, label, bold)
            sheet.set_row(0, 50)
            sheet.set_column(0, 0, 5)
            sheet.set_column(1, 2, 15)
            sheet.set_column(3, 3, 40)
            sheet.set_column(8, 8, 30)
            sheet.set_column(4, 7, 20)
            sheet.set_column(9, 13, 20)

        for i, item in enumerate(rows, start=1):
            name = item.full_name
            # depo_address = "Depo Adress"
            phone_flag=0
            email_flag=0
            phone = ''
            email = ''
            for communication in item.communication_line:
                 if communication.communication_type_code == '0010' and email_flag==0:
                     email = communication.value
                     email_flag+=1

                 if communication.communication_type_code == 'CELL' and phone_flag ==0:
                    phone = communication.value
                    phone_flag +=1
            addr_flag = 0
            depo_address = ''
            for address in item.address_line:
                if address.address_type.name == '4' and addr_flag==0:
                    depo_address = address.street_house
                    addr_flag +=1
            last_deg = ''
            last_deg_code = 9999999
            for education in item.education_line:
                if int(education.education_establishment_type.code) < last_deg_code:
                    last_deg = education.education_establishment_type.name
                    last_deg_code = int(education.education_establishment_type.code)
                else:
                    pass

            posting_place = item.personal_area.name
            data_list = [
                    i or '',  # 'Sl. No.'
                    item.employee_id or '',  # 'Emp ID'
                    item.employee_id or '',  # 'SAP ID'
                    name or '',  # 'Employee Name'
                    last_deg or '',  # 'Last Academic Degree'
                    item.position or '',  # 'Designation'
                    item.department.name or '',  # 'Department'
                    phone or '',  # 'Cell Number'
                    email or '',  # 'Email'
                    depo_address or '',  # 'Depo Adress'
                    posting_place or '',  # 'Posting Place'
                    '' or '',  # 'Card Format'
                    '' or '',  # 'QR Code'
                ]

            for j, data_item in enumerate(data_list):
                sheet.write(i, j, data_item, normal)
