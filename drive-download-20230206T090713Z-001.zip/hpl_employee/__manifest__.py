# -*- coding: utf-8 -*-
{
    'name': "hpl_employee",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'hr', 'web'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'data/sequence.xml',
        'data/employee_update_cron.xml',
        'views/hpl_employee.xml',
        'views/sub_type.xml',
        'views/educational_establishment_type.xml',
        'views/country.xml',
        'views/certificate.xml',
        'views/nationality.xml',
        'views/religion.xml',
        'views/division.xml',
        'views/marital_status.xml',
        'views/gender.xml',
        'views/name_format.xml',
        'views/personal_area.xml',
        'views/personal_sub_area.xml',
        'views/payroll_area.xml',
        'views/employee_group.xml',
        'views/employee_sub_group.xml',
        'views/reason_for_action.xml',
        'views/exam_area.xml',
        'views/action_type.xml',
        'views/action_date.xml',
        'views/blood_group.xml',
        'views/address_type.xml',
        'views/title.xml',
        'views/employment.xml',
        'views/family_type.xml',
        'views/id_type.xml',
        'views/communication_type.xml',
        'views/company_code.xml',
        'views/area.xml',
        'views/work_contract.xml',
        'views/special_payment.xml',
        'views/user_inherit.xml',
        'views/business_unit.xml',
        'views/section.xml',


        'views/hpl_employee_menu.xml',
        'reports/report.xml',
        'reports/hpl_header.xml',

    ],
}
