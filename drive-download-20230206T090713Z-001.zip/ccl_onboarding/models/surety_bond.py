from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
from odoo.http import request


class SuretyBond(models.Model):
    _name = 'employee.surety.bond'
    _description = 'Employee Surety Bond'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_id = fields.Many2one('hr.applicant', default=lambda self: self.env.user.applicant_id, readonly=True,
                                  domain="[('stage_id', '=', 5)]", required=True, string="Select Applicant")
    employee_name = fields.Char('Applicant Name', compute='_compute_emp_name')
    guarantor_name = fields.Char('Guarantor')
    guarantor_nid = fields.Char('NID')
    batch_no = fields.Integer(string='Batch', default=0, readonly=False, store=True, compute='_compute_batch')
    # father = fields.Char('Father Name')
    present_address = fields.Char('Present Address')
    permanent_address = fields.Char('Permanent Address')
    guarantor_relation = fields.Char('Relationship')
    candidate_relation = fields.Char('Relationship')
    guarantor_contact = fields.Char('Contact No')
    company_id = fields.Many2one('company.list', 'Company', compute='_compute_company', store=True)

    first_witness_name = fields.Char('Name')
    second_witness_name = fields.Char('Name')
    first_witness_address = fields.Char('Address')
    second_witness_address = fields.Char('Address')
    first_witness_relation = fields.Char('Relationship')
    second_witness_relation = fields.Char('Relationship')
    first_witness_contact = fields.Char('Contact No')
    second_witness_contact = fields.Char('Contact No')
    first_witness_nid = fields.Char('NID No')
    second_witness_nid = fields.Char('NID No')

    _sql_constraints = [
        ('employee_id', 'unique (employee_id)', 'You can not create multiple record for the same user!'),
    ]

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            emp.employee_name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0

    @api.depends('employee_id')
    def _compute_company(self):
        for emp in self:
            if emp.employee_id:
                user = self.env['res.users'].search([('applicant_id', '=', emp.employee_id.id)])
                print("user-------", user)
                emp.company_id = user.selected_company
                 
            else:
                emp.company_id = None

