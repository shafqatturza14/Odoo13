from odoo import fields, models, api, _


class CommitmentLetter(models.Model):
    _name = 'employee.commitment.letter'
    _description = 'Employee Commitment Letter'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_id = fields.Many2one('hr.applicant', domain="[('stage_id', '=', 5)]", required=True, string="Select Applicant")
    employee_name = fields.Char('Applicant Name', required=True, readonly=False, compute='_compute_emp_name')
    job_id = fields.Many2one('hr.job', 'Responsible Designation')
    department_id = fields.Many2one('hr.department', 'Responsible Department')
    company_address = fields.Text('Company Address')
    batch_no = fields.Integer(string='Batch', default=0, readonly=False, store=True, compute='_compute_batch')
    date = fields.Date('Date',  default=fields.date.today())
    date_str = fields.Char('Date',  compute='_compute_date_formate')
    father_name = fields.Char('Father', readonly=False, compute='_compute_employee_father')
    village = fields.Char('Permanent address', readonly=False, default='', compute='_compute_village')
    post_office = fields.Char('Post Office', readonly=False, default='', compute='_compute_post_office')
    police_station = fields.Char('Police Station', readonly=False, default='', compute='_compute_police_station')
    district = fields.Char('District', readonly=False, default='', compute='_compute_district')
    phone = fields.Char('Mobile No.', readonly=False, compute='_compute_mobile_no')

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            if emp.employee_id.partner_name:
                emp.employee_name = emp.employee_id.partner_name
            else:
                emp.employee_name = ''

    @api.depends('employee_id')
    def _compute_employee_father(self):
        for emp in self:
            if emp.employee_id.father:
                emp.father_name = emp.employee_id.father
            else:
                emp.father_name = ''

    @api.depends('employee_id')
    def _compute_village(self):
        for emp in self:
            if emp.employee_id.village:
                emp.village = emp.employee_id.village
            else:
                emp.village = ''

    @api.depends('date')
    def _compute_date_formate(self):
        for rec in self:
            rec.date_str = rec.date.strftime("%d %b %Y")

    @api.depends('employee_id')
    def _compute_post_office(self):
        for emp in self:
            if emp.employee_id.post_office:
                emp.post_office = emp.employee_id.post_office
            else:
                emp.post_office = ''

    @api.depends('employee_id')
    def _compute_police_station(self):
        for emp in self:
            if emp.employee_id.police_station:
                emp.police_station = emp.employee_id.police_station
            else:
                emp.police_station = ''

    @api.depends('employee_id')
    def _compute_district(self):
        for emp in self:
            if emp.employee_id.partner_name:
                emp.district = emp.employee_id.district
            else:
                emp.district = ''

    @api.depends('employee_id')
    def _compute_mobile_no(self):
        for emp in self:
            if emp.employee_id.partner_phone:
                emp.phone = emp.employee_id.partner_phone
            else:
                emp.phone = ''
