import base64
from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.modules.module import get_module_resource


class EmployeeNomineeOfSales(models.Model):
    _name = 'employee.nominee.for.sales'
    _description = 'Nominee of Sales'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']
    _rec_name = "name"

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_code = fields.Char(string='Employee ID')
    employee_id = fields.Many2one('hr.applicant', default=lambda self: self.env.user.applicant_id, readonly=True,
                                  domain="[('stage_id', '=', 5)]", required=True, string="Select Applicant")
    employee_name = fields.Char('Applicant Name', required=True, readonly=False, compute='_compute_emp_name')
    zone_id = fields.Char('Zone')
    region = fields.Char('Region')
    batch_no = fields.Integer(string='Batch', default=0, readonly=False, store=True, compute='_compute_batch')
    department_id = fields.Many2one('hr.department', 'Department', required=True, readonly=False,
                                    compute='_compute_employee_department')
    job_id = fields.Char('Designation', required=True, readonly=False, compute='_compute_employee_designation')
    father = fields.Char(string='Father’s Name', required=True, readonly=False, compute='_compute_father_name')
    mother = fields.Char(string='Mother’s Name', required=True, readonly=False, compute='_compute_mother_name')
    permanent_address = fields.Char(string='Address', required=True, readonly=False, compute='_compute_emp_address')
    nominee_lines = fields.One2many('employee.nominee.for.sales.line', 'nominee_id', string='Nominees line')
    witness_name = fields.Char('Witness Name')
    witness_nid = fields.Char('Witness NID')

    _sql_constraints = [
        ('employee_id', 'unique (employee_id)', 'You can not create multiple record for the same user!'),
    ]

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            if emp.employee_id.partner_name:
                emp.employee_name = emp.employee_id.partner_name
            else:
                emp.employee_name = ''

    @api.depends('employee_id')
    def _compute_employee_department(self):
        for emp in self:
            if emp.employee_id.department_id:
                emp.department_id = emp.employee_id.department_id.id
            else:
                emp.department_id = ''

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0

    @api.depends('employee_id')
    def _compute_employee_designation(self):
        for emp in self:
            if emp.employee_id.job_id:
                emp.job_id = emp.employee_id.job_id.name
            else:
                emp.job_id = ""

    @api.depends('employee_id')
    def _compute_father_name(self):
        for emp in self:
            if emp.employee_id.father:
                emp.father = emp.employee_id.father
            else:
                emp.father = ''

    @api.depends('employee_id')
    def _compute_mother_name(self):
        for emp in self:
            if emp.employee_id.mother:
                emp.mother = emp.employee_id.mother
            else:
                emp.mother = ''

    @api.depends('employee_id')
    def _compute_emp_address(self):
        for emp in self:
            if emp.employee_id.village and emp.employee_id.police_station and emp.employee_id.district:
                emp.permanent_address = emp.employee_id.village + ', ' + emp.employee_id.police_station + ', ' \
                                        + emp.employee_id.district
            elif emp.employee_id.village and emp.employee_id.police_station:
                emp.permanent_address = emp.employee_id.village + ', ' + emp.employee_id.police_station

            elif emp.employee_id.village and emp.employee_id.district:
                emp.permanent_address = emp.employee_id.village + ', ' + emp.employee_id.district

            elif emp.employee_id.police_station and emp.employee_id.district:
                emp.permanent_address = emp.employee_id.police_station + ', ' + emp.employee_id.district
            else:
                emp.permanent_address = ''


class NomineeOFSalesLine(models.Model):
    _name = 'employee.nominee.for.sales.line'
    _description = 'Employee Nominee of Sales Line'

    @api.model
    def _default_image(self):
        image_path = get_module_resource('hr', 'static/src/img', 'default_image.png')
        return base64.b64encode(open(image_path, 'rb').read())

    nominee_id = fields.Many2one('employee.nominee.for.sales', string="Nominee")
    sl = fields.Integer(string='Sl', compute='_compute_get_number', store=True)
    name = fields.Char(string='Name of the Nominee(s)', required=True)
    birthday = fields.Date(string='Date of Birth')
    relation = fields.Char(string='Relation', required=True)
    proportion = fields.Char(string='Proportion of Payable (%)')
    nominee_nid = fields.Char(string='National ID No of Nominee')
    sign_and_address = fields.Text(string='Address of Nominee ')
    nominee_image = fields.Image(string='Image for Nominee-1', default=_default_image)

    @api.depends('nominee_id')
    def _compute_get_number(self):
        for order in self.mapped('nominee_id'):
            number = 1
            for line in order.nominee_lines:
                line.sl = number
                number += 1
