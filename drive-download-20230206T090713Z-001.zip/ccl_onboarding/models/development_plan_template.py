from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


# Acces Template
class AccessTemplate(models.Model):
    _name = 'access.template'
    _description = 'Access Template for Employee Development'

    name = fields.Char(string='Name', required=True)
    template_lines = fields.One2many('access.template.load.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):

        length = len(vals['template_lines'])

        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['particulars']}")
            if not vals['template_lines'][i][2]['particulars']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(AccessTemplate, self).create(vals)

        return rec


class AccessTemplateLoadLine(models.Model):
    _name = 'access.template.load.line'
    _description = 'Template Load Line'

    template_id = fields.Many2one('access.template')
    particulars = fields.Char(string='Particulars', required=True)
    communicate_to = fields.Many2one('hr.department', 'Communicate To')
    time = fields.Char(string='Time')

#
# # Workplace Template
class WorkplaceTemplate(models.Model):
    _name = 'workplace.template'
    _description = 'Workplace Template for Employee Development'

    name = fields.Char(string='Name', required=True)
    template_lines = fields.One2many('workplace.template.load.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):

        length = len(vals['template_lines'])

        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['particulars']}")
            if not vals['template_lines'][i][2]['particulars']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(WorkplaceTemplate, self).create(vals)

        return rec


class WorkplaceTemplateLoadLine(models.Model):
    _name = 'workplace.template.load.line'
    _description = 'Workplace Template Load Line'

    template_id = fields.Many2one('workplace.template')
    particulars = fields.Char(string='Particulars', required=True)
    communicate_to = fields.Many2one('hr.department', 'Communicate To')
    time = fields.Char(string='Time')


# Provide information Template
class ProvideInformationTemplate(models.Model):
    _name = 'provide.information.template'
    _description = 'Provide Information Employee Development'

    name = fields.Char(string='Name', required=True)
    template_lines = fields.One2many('provide.information.template.load.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):

        length = len(vals['template_lines'])

        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['particulars']}")
            if not vals['template_lines'][i][2]['particulars']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(ProvideInformationTemplate, self).create(vals)

        return rec


class ProvideTemplateLoadLine(models.Model):
    _name = 'provide.information.template.load.line'
    _description = 'Provide Information Load Line'

    template_id = fields.Many2one('provide.information.template')
    particulars = fields.Char(string='Particulars', required=True)
    communicate_to = fields.Many2one('hr.department', 'Communicate To')
    time = fields.Char(string='Time')


# Training Program Template
class TrainingProgramTemplate(models.Model):
    _name = 'training.program.template'
    _description = 'Training Program Template'

    name = fields.Char(string='Name', required=True)
    template_lines = fields.One2many('training.program.template.line', 'template_id', string='Template line',
                                     required=True)

    @api.model
    def create(self, vals):
        length = len(vals['template_lines'])
        for i in range(length):
            print(f"value of {i} is {vals['template_lines'][i][2]['training_name']}")
            if not vals['template_lines'][i][2]['training_name']:
                raise UserError(_('You cannot leave a line blank'))

        rec = super(TrainingProgramTemplate, self).create(vals)
        return rec


class TrainingProgramTemplateLine(models.Model):
    _name = 'training.program.template.line'
    _description = 'Training Program Template Line'

    template_id = fields.Many2one('training.program.template')
    training_name = fields.Char(string='Training Name', required=True)
    responsible = fields.Many2one('hr.department', 'Responsible')
    time = fields.Char(string='Time')
    duration = fields.Char(string='Duration')