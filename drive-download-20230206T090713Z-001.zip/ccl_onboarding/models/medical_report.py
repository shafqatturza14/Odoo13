from odoo import fields, models, api, _
import base64
from odoo.modules.module import get_module_resource

class EmployeeMedicalReport(models.Model):
    _name = 'employee.medical.report'
    _description = 'Employee Medical Report'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', store=True,compute='_compute_rec_name')
    employee_id = fields.Many2one('hr.applicant', default=lambda self: self.env.user.applicant_id,
                                  domain="[('stage_id', '=', 5)]", required=True, string="Select Applicant")
    employee_name = fields.Char('Applicant Name', required=True, readonly=False, compute='_compute_emp_name')
    add_medical_report = fields.Many2many('ir.attachment', string="Add Your Medical Report")
    signature = fields.Image(string='Signature')
    nid = fields.Char(string='NID Number', help='Please write your National ID card Number')
    emergency_contact = fields.Char(string='Emergency Contact No.')
    batch_no = fields.Integer(string='Batch', default=0, readonly=False, store=True, compute='_compute_batch')
    _sql_constraints = [
        ('employee_id', 'unique (employee_id)', 'You can not create multiple record for the same user!'),
    ]

    @api.model
    def _default_image(self):
        image_path = get_module_resource('hr', 'static/src/img', 'default_image.png')
        return base64.b64encode(open(image_path, 'rb').read())

    image_1920 = fields.Image(string='Your Image', default=_default_image)

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            if emp.employee_id.partner_name:
                emp.employee_name = emp.employee_id.partner_name
            else:
                emp.employee_name = ''