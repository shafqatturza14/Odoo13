
from odoo import fields, models, api, _


class OrientationPlace(models.Model):
    _name = 'orientation.place'
    _description = 'Orientation Place'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']

    name = fields.Char(string="Name", required=True)
