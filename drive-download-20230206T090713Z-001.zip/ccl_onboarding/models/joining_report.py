from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.modules.module import get_module_resource
from datetime import datetime, timedelta
from odoo.http import request
from . import strings
import base64


class JoiningReport(models.Model):
    _name = 'employee.joining.report'
    _description = 'Employee Joining Report'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_id = fields.Many2one('hr.applicant', domain="[('stage_id', '=', 5)]", required=True,
                                  string="Select Applicant")
    batch_no = fields.Integer(string='Batch', default=0, readonly=False, store=True, compute='_compute_batch')
    employee_name = fields.Char('Applicant Name', required=True, readonly=False, compute='_compute_emp_name')
    job_id = fields.Many2one('hr.job', 'Designation', readonly=False, compute='_compute_employee_job_position')
    department_id = fields.Many2one('hr.department', 'Department', readonly=False, compute='_compute_employee_dept')
    emp_joining_date = fields.Date('Joining Date',  default=fields.date.today())
    date = fields.Date('Date',  default=fields.date.today())
    appointment_date = fields.Date('Appointment Date',  default=fields.date.today())
    date_str = fields.Char('Date',  compute='_compute_date_formate')
    appointment_date_str = fields.Char('Date',  compute='_compute_appointment_date_formate')
    emp_joining_date_str = fields.Char('Date',  compute='_compute_joining_date_formate')
    formalities_mail_template = fields.Text(required=True, string="Joining Formalities Email Body",
                                            default=lambda self: strings.joining_formalities_template_body)

    joining_letter_mail_body = fields.Text(required=True, string="Joining Letter Email Body",
                                           default=lambda self: strings.joining_letter_template_body)
    add_appointment_letter = fields.Many2many('ir.attachment', string="Add Appointment Letter")
    # Reporting To
    reporting_employee_id = fields.Many2one('hpl.employee', required=True, string="Reporting To")
    officer_job_id = fields.Char('Designation', readonly=False, compute='_compute_officer_job_position')
    officer_department_id = fields.Many2one('hr.department', 'Department', readonly=False,
                                            compute='_compute_officer_department')
    company_address = fields.Text('Company Address')
    email_id = fields.Char('E-mail ID', compute='_compute_email_id')
    phone_no = fields.Char('Mobile Number', compute='_compute_phone_no')
    pabx_id = fields.Char('PABX', compute='_compute_pabx_id')

    # Joining Announcement Info
    @api.model
    def _default_image(self):
        image_path = get_module_resource('hr', 'static/src/img', 'default_image.png')
        return base64.b64encode(open(image_path, 'rb').read())
    mail_to = fields.Char('Mail To', required=True)
    email_cc = fields.Char('Email-CC')
    image_1920 = fields.Image(string='Image', compute='_compute_image', default=_default_image)
    total_experience = fields.Char('Total Experience', compute='_compute_total_experience')
    last_job_position = fields.Char('Job position', compute='_compute_last_job_position')
    last_company = fields.Char('Last Work At', compute='_compute_last_company')

    # Educational Info
    education_title = fields.Char('Education Title', default='Graduation')
    subject = fields.Char('Subject', compute='_compute_subject')
    institute = fields.Char('Institute', compute='_compute_institute_name')
    masters = fields.Boolean('Add Masters', default=False)
    masters_education_title = fields.Char('Education Title')
    masters_subject = fields.Char('Subject', compute='_compute_masters_subject')
    masters_institute = fields.Char('Institute', compute='_compute_masters_institute')

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0

    @api.depends('date')
    def _compute_date_formate(self):
        for rec in self:
            rec.date_str = rec.date.strftime("%b %d, %Y")

    @api.depends('appointment_date')
    def _compute_appointment_date_formate(self):
        for rec in self:
            if rec.appointment_date:
                rec.appointment_date_str = rec.appointment_date.strftime("%b %d, %Y")
            else:
                rec.appointment_date_str = ''


    @api.depends('emp_joining_date')
    def _compute_joining_date_formate(self):
        for rec in self:
            rec.emp_joining_date_str = rec.emp_joining_date.strftime("%b %d, %Y")

    @api.depends('employee_id')
    def _compute_total_experience(self):
        for rec in self:
            applicant = self.env['hr.applicant'].search([('id', '=', rec.employee_id.id)])
            if applicant.experience:
                rec.total_experience = applicant.experience
            else:
                rec.total_experience = ''

    @api.depends('employee_id')
    def _compute_image(self):
        for rec in self:
            medical_obj = self.env['employee.medical.report'].search([('employee_id', '=', rec.employee_id.id)],
                                                                     limit=1)
            if medical_obj.image_1920:
                rec.image_1920 = medical_obj.image_1920
            else:
                image_path = get_module_resource('hr', 'static/src/img', 'default_image.png')
                rec.image_1920 = base64.b64encode(open(image_path, 'rb').read())

    @api.depends('employee_id')
    def _compute_last_job_position(self):
        for rec in self:
            applicant = self.env['hr.applicant'].search([('id', '=', rec.employee_id.id)])
            if applicant.company_designation:
                if applicant.company_designation.find(','):
                    designation = applicant.company_designation.split(',')
                    last_designation = str(designation[-1])
                    rec.last_job_position = last_designation
                else:
                    rec.last_job_position = applicant.company_designation
            else:
                rec.last_job_position = ''

    @api.depends('employee_id')
    def _compute_last_company(self):
        for rec in self:
            applicant = self.env['hr.applicant'].search([('id', '=', rec.employee_id.id)])
            # company = []
            if applicant.company_name:
                if applicant.company_name.find(','):
                    company = applicant.company_name.split(',')
                    last_company = str(company[-1])
                    rec.last_company = last_company
                else:
                    rec.last_company = applicant.company_name
            else:
                rec.last_company = ''

    @api.depends('employee_id')
    def _compute_email_id(self):
        for rec in self:
            dev_plan = self.env['employee.development.plan'].search([('employee_id', '=', rec.employee_id.id)], limit=1)
            for line in dev_plan.access_template_lines_remarks:
                if line.particulars == 'E-mail set up':
                    rec.email_id = line.remarks
                    break
                else:
                    rec.email_id = ''
            else:
                rec.email_id = ''

    @api.depends('employee_id')
    def _compute_phone_no(self):
        for rec in self:
            dev_plan = self.env['employee.development.plan'].search([('employee_id', '=', rec.employee_id.id)], limit=1)
            if dev_plan:
                for line in dev_plan.access_template_lines_remarks:
                    if line.particulars == 'Mobile SIM & Set requirement':
                        rec.phone_no = line.remarks
                        break
                    else:
                        rec.phone_no = ''
            else:
                rec.phone_no = ''

    @api.depends('employee_id')
    def _compute_pabx_id(self):
        for rec in self:
            dev_plan = self.env['employee.development.plan'].search([('employee_id', '=', rec.employee_id.id)], limit=1)
            for line in dev_plan.workplace_template_lines_remarks:
                if line.particulars == 'IP Phone':
                    rec.pabx_id = line.remarks
                    break
                else:
                    rec.pabx_id = ''
            else:
                rec.pabx_id = ''

    @api.depends('employee_id')
    def _compute_education_title(self):
        for rec in self:
            applicant = self.env['hr.applicant'].search([('id', '=', rec.employee_id.id)])
            if applicant.company_name:
                rec.last_company = applicant.company_name
            else:
                rec.last_company = ''

    @api.depends('employee_id')
    def _compute_subject(self):
        for rec in self:
            applicant = self.env['hr.applicant'].search([('id', '=', rec.employee_id.id)])
            if applicant.subject:
                rec.subject = applicant.subject
            else:
                rec.subject = ''

    @api.depends('employee_id')
    def _compute_institute_name(self):
        for rec in self:
            applicant = self.env['hr.applicant'].search([('id', '=', rec.employee_id.id)])
            if applicant.grad_university:
                rec.institute = applicant.grad_university
            else:
                rec.institute = ''

    @api.depends('employee_id')
    def _compute_masters_subject(self):
        for rec in self:
            applicant = self.env['hr.applicant'].search([('id', '=', rec.employee_id.id)])
            if applicant.post_grad_subject:
                rec.masters_subject = applicant.post_grad_subject
            else:
                rec.masters_subject = ''

    @api.depends('employee_id')
    def _compute_masters_institute(self):
        for rec in self:
            applicant = self.env['hr.applicant'].search([('id', '=', rec.employee_id.id)])
            if applicant.post_grad_university:
                rec.masters_institute = applicant.post_grad_university
            else:
                rec.masters_institute = ''

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            if emp.employee_id.partner_name:
                emp.employee_name = emp.employee_id.partner_name
            else:
                emp.employee_name = ''

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        self.joining_letter_mail_body = strings.joining_letter_template_body.replace('{emp_name}', self.employee_name)
        if self.employee_name and self.job_id and self.department_id:
            user = self.env['res.users'].search([('applicant_id', '=', self.employee_id.id)]).login
            print("user-----------", user)
            self.formalities_mail_template = strings.joining_formalities_template_body.replace(
                '{emp_name}', self.employee_name).replace('{designation}', self.job_id.name).replace(
                '{dept}', self.department_id.name).replace('{_email_}', user)

    @api.depends('employee_id')
    def _compute_employee_job_position(self):
        for emp in self:
            if emp.employee_id.job_id:
                emp.job_id = emp.employee_id.job_id.id
            else:
                emp.job_id = ''

    @api.depends('reporting_employee_id')
    def _compute_officer_job_position(self):
        for emp in self:
            if emp.reporting_employee_id.position_name:
                emp.officer_job_id = emp.reporting_employee_id.position_name
            else:
                emp.officer_job_id = ''

    @api.depends('employee_id')
    def _compute_employee_dept(self):
        for emp in self:
            if emp.employee_id.department_id:
                emp.department_id = emp.employee_id.department_id.id
            else:
                emp.department_id = ''

    @api.depends('reporting_employee_id')
    def _compute_officer_department(self):
        for emp in self:
            if emp.reporting_employee_id.department:
                emp.officer_department_id = emp.reporting_employee_id.department.id
            else:
                emp.officer_department_id = ''

    # Sending email with joining letter in button click
    def action_send_joining_letter(self):
        template_id = self.env.ref('ccl_onboarding.joining_letter_email_template').id
        template = self.env['mail.template'].browse(template_id)
        template['body_html'] = self.joining_letter_mail_body
        template.send_mail(self.id, force_send=True)

    # Sending email with joining letter in button click
    def action_send_joining_formalities(self):

        template_id = self.env.ref('ccl_onboarding.joining_formalities_email_template').id
        template = self.env['mail.template'].browse(template_id)
        template['body_html'] = self.formalities_mail_template
        print(template['body_html'])
        # template.attachment_ids = [(6, 0, [data_id.id])]
        if self.add_appointment_letter:
            template.attachment_ids = self.add_appointment_letter
        template.send_mail(self.id, force_send=True)

    # Sending email with joining announcements in button click
    def action_send_joining_announcements(self):
        template_id = self.env.ref('ccl_onboarding.joining_announcement_email_template').id
        template = self.env['mail.template'].browse(template_id)
        template['email_to'] = self.mail_to
        template['email_cc'] = self.email_cc
        template.send_mail(self.id, force_send=True)
