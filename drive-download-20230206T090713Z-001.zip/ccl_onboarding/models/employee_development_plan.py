from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
from odoo.http import request


class EmployeeDevelopmentPlan(models.Model):
    _name = 'employee.development.plan'
    _description = 'Employee Development Plan'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_id = fields.Many2one('hr.applicant', domain="[('stage_id', '=', 5)]",
                                  required=True, string="Applicant")
    employee_code = fields.Char(string='Employee ID', required=True)
    plant_area = fields.Char(string='Plant Area', required=True)
    batch = fields.Integer(string='Batch', default=0)
    joining_date = fields.Char('Joining Date', compute='_compute_joining_date')

    access_template_lines = fields.One2many('access.template.line', 'dev_plan_id',
                                             string='Access Template Line')
    workplace_template_lines = fields.One2many('workplace.template.line', 'dev_plan_id',
                                             string='Access Template Line')
    provide_template_lines = fields.One2many('provide.information.template.line', 'dev_plan_id',
                                             string='Provide Template Line')
    training_lines = fields.One2many('training.program', 'dev_plan_id',
                                             string='Training Program')

    access_template_lines_remarks = fields.One2many('access.template.line.remarks', 'dev_plan_id',
                                            string='Access Template Line Remarks')
    workplace_template_lines_remarks = fields.One2many('workplace.template.line.remarks', 'dev_plan_id',
                                               string='Access Template Line Remarks')
    provide_template_lines_remarks = fields.One2many('provide.information.template.line.remarks', 'dev_plan_id',
                                             string='Provide Template Line Remarks')

    access_template_id = fields.Many2one('access.template', required=True, string='Access Template')
    workplace_template_id = fields.Many2one('workplace.template', required=True, string='Workplace Template')
    provide_info_template_id = fields.Many2one('provide.information.template', required=True, string='Provide Information Template')
    training_template_id = fields.Many2one('training.program.template', required=True, string='Training Program Template')

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch = emp.employee_id.batches.batches
            else:
                emp.batch = 0

    @api.depends('employee_id')
    def _compute_joining_date(self):
        for rec in self:
            joining_objects = self.env['employee.joining.report'].search([('employee_id', '=',rec.employee_id.id)],limit=1)
            if joining_objects:
                if joining_objects.date_str:
                    rec.joining_date = joining_objects.emp_joining_date_str
            else:
                rec.joining_date = ''

    @api.onchange('access_template_id')
    def onchange_access_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            remarks_lines = [(5, 0, 0)]
            for line in self.access_template_id.template_lines:
                val = {
                    'particulars': line.particulars,
                    'communicate_to': line.communicate_to,
                    'time': line.time,
                }
                val_remarks = {
                    'particulars': line.particulars,
                }
                lines.append((0, 0, val))
                remarks_lines.append((0, 0, val_remarks))
            rec.access_template_lines = lines
            rec.access_template_lines_remarks = remarks_lines

    @api.onchange('workplace_template_id')
    def onchange_workplace_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            remarks_lines = [(5, 0, 0)]
            for line in self.workplace_template_id.template_lines:
                val = {
                    'particulars': line.particulars,
                    'communicate_to': line.communicate_to,
                    'time': line.time,
                }
                val_remarks = {
                    'particulars': line.particulars,
                }
                lines.append((0, 0, val))
                remarks_lines.append((0, 0, val_remarks))
            rec.workplace_template_lines = lines
            rec.workplace_template_lines_remarks = remarks_lines

    @api.onchange('provide_info_template_id')
    def onchange_provide_info_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            remarks_lines = [(5, 0, 0)]
            for line in self.provide_info_template_id.template_lines:
                val = {
                    'particulars': line.particulars,
                    'communicate_to': line.communicate_to,
                    'time': line.time,
                }
                val_remarks = {
                    'particulars': line.particulars,
                }
                lines.append((0, 0, val))
                remarks_lines.append((0, 0, val_remarks))

            rec.provide_template_lines = lines
            rec.provide_template_lines_remarks = remarks_lines

    @api.onchange('training_template_id')
    def onchange_training_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.training_template_id.template_lines:
                val = {
                    'training_name': line.training_name,
                    'responsible': line.responsible,
                    'time': line.time,
                    'duration': line.duration,
                }
                lines.append((0, 0, val))
            rec.training_lines = lines

    def action_send_development_plan(self):
        global str
        emp_id_list = []
        for access_line in self.access_template_lines:
            if access_line.employee_id.id not in emp_id_list:
                emp_id_list.append(access_line.employee_id.id)

        for wp in self.workplace_template_lines:
            if wp.employee_id.id not in emp_id_list:
                emp_id_list.append(wp.employee_id.id)

        for pti in self.provide_template_lines:
            if pti.employee_id.id not in emp_id_list:
                emp_id_list.append(pti.employee_id.id)

        for tl in self.training_lines:
            if tl.employee_id.id not in emp_id_list:
                emp_id_list.append(tl.employee_id.id)

        for id in emp_id_list:
            vals = []
            cc_mail = []
            for access_line in self.access_template_lines:
                if access_line.employee_id.id == id:
                    vals.append({
                        'particulars': access_line.particulars
                    })
                    if access_line.email_cc:
                        cc_mail.append(access_line.email_cc)

            for wp in self.workplace_template_lines:
                if wp.employee_id.id == id:
                    vals.append({
                        'particulars': wp.particulars
                    })
                    if wp.email_cc:
                        cc_mail.append(wp.email_cc)
            for pti in self.provide_template_lines:
                if pti.employee_id.id == id:
                    vals.append({
                        'particulars': pti.particulars
                    })
                    if pti.email_cc:
                      cc_mail.append(pti.email_cc)
            for tl in self.training_lines:
                if tl.employee_id.id == id:
                    vals.append({
                        'particulars': tl.training_name,
                        'time': '('+ tl.time + ')'
                    })
                    if tl.email_cc:
                        cc_mail.append(tl.email_cc)
            template_id = self.env.ref('ccl_onboarding.development_plan_email_template')
            print("template------190---", template_id)
            template = self.env['mail.template'].browse(template_id)
            values = template_id.generate_email(self.id)
            print("values------193---", values)
            str = ''
            sl = 1
            for val in vals:
                strn = f""" {sl}. {val}, """
                str1 = strn.replace("{'particulars': '", "").replace("'}", "")
                str_update = str1.replace("', 'time': '", "").replace("'}", "")
                str += str_update
                sl = sl+1

            # if self.employee_id.gender:
            if self.employee_id.gender.name == 'Male':
                gender = 'Mr.'
            elif self.employee_id.gender.name == 'Female':
                gender = 'Ms.'
            values['body_html'] = values['body_html'].replace("_tittle_", gender).replace("_ticket_url_", str)
            applicant = self.env['hpl.employee'].search([('id', '=', id)])
            print("body_html-----------", values['body_html'])
            flag = 0
            for communication in applicant.communication_line:
                if communication.communication_type_code == '0010' and flag == 0:
                    email = communication.value
                    flag += 1

            if cc_mail:
                email_cc = cc_mail[0]
            else:
                email_cc = ''
            values['email_to'] = email
            values['email_cc'] = email_cc
            # template.send_mail(self.id, force_send=True)
            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()


class AccessTemplateLine(models.Model):
    _name = 'access.template.line'
    _description = 'Access Template Line'

    dev_plan_id = fields.Many2one('employee.development.plan', string="Development Plan")
    particulars = fields.Char(string='Particulars', required=True)
    communicate_to = fields.Many2one('hr.department', 'Communicate To')
    employee_id = fields.Many2one('hpl.employee', required=True, string="Assign To")
    email_cc = fields.Char(string='Email-CC')
    time = fields.Char(string='Time')


class WorkplaceTemplateLine(models.Model):
    _name = 'workplace.template.line'
    _description = 'Workplace Template Line'

    dev_plan_id = fields.Many2one('employee.development.plan', string="Development Plan")
    particulars = fields.Char(string='Particulars', required=True)
    communicate_to = fields.Many2one('hr.department', 'Communicate To')
    employee_id = fields.Many2one('hpl.employee',required=True, string="Assign To")
    email_cc = fields.Char(string='Email-CC')
    time = fields.Char(string='Time')


class ProvideInformationTemplateLine(models.Model):
    _name = 'provide.information.template.line'
    _description = 'Provide Template Line'

    dev_plan_id = fields.Many2one('employee.development.plan', string="Development Plan")
    particulars = fields.Char(string='Particulars', required=True)
    communicate_to = fields.Many2one('hr.department', 'Communicate To')
    employee_id = fields.Many2one('hpl.employee', required=True, string="Assign To")
    email_cc = fields.Char(string='Email-CC')
    time = fields.Char(string='Time')


class TrainingProgram(models.Model):
    _name = 'training.program'
    _description = 'Training Program:'

    dev_plan_id = fields.Many2one('employee.development.plan', string="Development Plan")
    training_name = fields.Char(string='Training Name', required=True)
    responsible = fields.Many2one('hr.department', 'Responsible')
    employee_id = fields.Many2one('hpl.employee', required=True, string="Assign To")
    email_cc = fields.Char(string='Email-CC')
    time = fields.Char(string='Time')
    duration = fields.Char(string='Duration')


class AccessTemplateLineRemarks(models.Model):
    _name = 'access.template.line.remarks'
    _description = 'Access Template Line Remarks'

    dev_plan_id = fields.Many2one('employee.development.plan', string="Development Plan")
    particulars = fields.Char(string='Particulars', required=True)
    remarks = fields.Char(string='Remarks')


class WorkplaceTemplateLineRemarks(models.Model):
    _name = 'workplace.template.line.remarks'
    _description = 'Workplace Template Line Remarks'

    dev_plan_id = fields.Many2one('employee.development.plan', string="Development Plan")
    particulars = fields.Char(string='Particulars', required=True)
    remarks = fields.Char(string='Remarks')


class ProvideInformationTemplateLineRemarks(models.Model):
    _name = 'provide.information.template.line.remarks'
    _description = 'Provide Template Line Remarks'

    dev_plan_id = fields.Many2one('employee.development.plan', string="Development Plan")
    particulars = fields.Char(string='Particulars', required=True)
    remarks = fields.Char(string='Remarks')