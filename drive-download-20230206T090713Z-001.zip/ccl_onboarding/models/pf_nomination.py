import base64
from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.modules.module import get_module_resource


class EmployeePFNomination(models.Model):
    _name = 'employee.pf.nomination'
    _description = 'Employee PF Nomination'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']
    _rec_name = "name"

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_code = fields.Char(string='Employee ID')
    employee_id = fields.Many2one('hr.applicant', default=lambda self: self.env.user.applicant_id, readonly=True,
                                  domain="[('stage_id', '=', 5)]", required=True, string="Select Applicant")
    employee_name = fields.Char('Applicant Name', required=True, readonly=False, compute='_compute_emp_name')
    first_witness_id = fields.Many2one('hpl.employee', required=False, string="Name")
    second_witness_id = fields.Many2one('hpl.employee', required=False, string="Name")
    first_witness_job_id = fields.Char('Designation', required=False, readonly=False,
                                       compute='_compute_first_witness_designation')
    first_witness_address = fields.Text(string='Address', readonly=False, default=None,
                                        compute='_compute_first_witness_address')
    second_witness_job_id = fields.Char('Designation', required=False, readonly=False,
                                        compute='_compute_second_witness_designation')
    second_witness_address = fields.Text(string='Address', readonly=False, default=None,
                                         compute='_compute_second_witness_address')
    nominee_lines = fields.One2many('pf.nomination.line', 'nominee_id', string='Nominees line')
    # user_id = fields.Many2one('hr.applicant', 'User', compute='_compute_user', store=True)
    company_id = fields.Many2one('company.list', 'Company', compute='_compute_company', store=True)
    _sql_constraints = [
        ('employee_id', 'unique (employee_id)', 'You can not create multiple record for the same user!'),
    ]
    batch_no = fields.Integer(string='Batch', default=0, readonly=False, store=True, compute='_compute_batch')

    @api.depends('employee_id', 'employee_code')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            if emp.employee_id.partner_name:
                emp.employee_name = emp.employee_id.partner_name
            else:
                emp.employee_name = ''

    @api.depends('employee_id')
    def _compute_company(self):
        for emp in self:
            if emp.employee_id:
                user = self.env['res.users'].search([('applicant_id', '=', emp.employee_id.id)])
                company = user.selected_company
                emp.company_id = company
            else:
                emp.company_id = None

    @api.depends('first_witness_id')
    def _compute_first_witness_designation(self):
        for emp in self:
            if emp.first_witness_id.position_name:
                emp.first_witness_job_id = emp.first_witness_id.position_name
            else:
                emp.first_witness_job_id = ''

    @api.depends('second_witness_id')
    def _compute_second_witness_designation(self):
        for emp in self:
            if emp.second_witness_id.position_name:
                emp.second_witness_job_id = emp.second_witness_id.position_name
            else:
                emp.second_witness_job_id = ''

    @api.depends('first_witness_id')
    def _compute_first_witness_address(self):
        for emp in self:
            addr_flag = 0
            if emp.first_witness_id:
                for address in emp.first_witness_id.address_line:
                    if address.address_type.code == '1' and addr_flag == 0:
                        if address.street_house:
                            emp.first_witness_address = address.street_house  # Parmanent address code = 1
                            addr_flag += 1
                            break
                        else:
                            emp.first_witness_address = ''
            else:
                emp.first_witness_address = ''

    @api.depends('second_witness_id')
    def _compute_second_witness_address(self):
        for emp in self:
            addr_flag = 0
            if emp.second_witness_id:
                for address in emp.second_witness_id.address_line:
                    if address.address_type.code == '1' and addr_flag == 0:
                        if address.street_house:
                            emp.second_witness_address = address.street_house  # Parmanent address code = 1
                            addr_flag += 1
                            break
                        else:
                            emp.second_witness_address = ''
            else:
                emp.second_witness_address = ''


class PFNominationLine(models.Model):
    _name = 'pf.nomination.line'
    _description = 'PF Nomination Line'

    @api.model
    def _default_image(self):
        image_path = get_module_resource('hr', 'static/src/img', 'default_image.png')
        return base64.b64encode(open(image_path, 'rb').read())

    nominee_id = fields.Many2one('employee.pf.nomination', string="PF Nomination")
    sl = fields.Integer(string='Sl', compute='_compute_get_number', store=True)
    name = fields.Char(string='Name of the Nominee(s)', required=True)
    birthday = fields.Date(string='Date of Birth')
    relation = fields.Char(string='Relation', required=True)
    share_amount = fields.Float(string='Amount of share(%)')
    address = fields.Char(string='Address')
    minor_nominee_details = fields.Text(string='Name and address for minor nominee')
    nominee_image = fields.Image(string='Image for Nominee', default=_default_image)

    @api.depends('nominee_id')
    def _compute_get_number(self):
        for order in self.mapped('nominee_id'):
            number = 1
            for line in order.nominee_lines:
                line.sl = number
                number += 1

