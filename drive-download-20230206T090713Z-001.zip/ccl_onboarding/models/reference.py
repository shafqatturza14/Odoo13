import base64
from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.modules.module import get_module_resource


class EmployeeReference(models.Model):
    _name = 'employee.reference'
    _description = 'Reference'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_id = fields.Many2one('hr.applicant', default=lambda self: self.env.user.applicant_id, readonly=True,
                                  required=True, string="Select Applicant")
    employee_name = fields.Char('Applicant Name', readonly=False, compute='_compute_emp_name')
    father = fields.Char(string="Father",  compute='_compute_father_name')
    mother = fields.Char(string="Mother",  compute='_compute_mother_name')
    text2 = fields.Char(string="Known to me since")
    referee_name = fields.Char(string="Name", required=True,)
    referee_occupation = fields.Char(string="Occupation", required=True)
    referee_nid = fields.Char(string="NID")
    referee_address = fields.Char(string="Permanent Address", required=True)
    referee_email = fields.Char(string="E-mail Address")
    referee_mobile = fields.Char(string="Cell", required=True)
    referee_phone = fields.Char(string="Land phone")

    documents = fields.Binary(string="Photocopy of NID")
    document_name = fields.Char(string="File Name")
    date = fields.Date('Date', default=fields.date.today())
    date_str = fields.Char('Date',  compute='_compute_date_formate')
    batch_no = fields.Integer(string='Batch', default=0, readonly=False, store=True, compute='_compute_batch')

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.name

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            if emp.employee_id.partner_name:
                emp.employee_name = emp.employee_id.partner_name
            else:
                emp.employee_name = ''

    @api.depends('date')
    def _compute_date_formate(self):
        for rec in self:
            rec.date_str = rec.date.strftime("%b %d, %Y")

    @api.depends('employee_id')
    def _compute_father_name(self):
        for emp in self:
            if emp.employee_id.father:
                emp.father = emp.employee_id.father
            else:
                emp.father = ''

    @api.depends('employee_id')
    def _compute_mother_name(self):
        for emp in self:
            if emp.employee_id.mother:
                emp.mother = emp.employee_id.mother
            else:
                emp.mother = ''

