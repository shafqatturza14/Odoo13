
from odoo import fields, models, api, _


class EmployeeTraining(models.Model):
    _name = 'employee.training'
    _description = 'Training'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']
    _rec_name = "name"

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_id = fields.Many2one('hr.applicant', default=lambda self: self.env.user.applicant_id, readonly=True,
                                  domain="[('stage_id', '=', 5)]", required=True, string="Select Applicant")
    # employee_name = fields.Char('Applicant Name', required=True, compute='_compute_emp_name')
    training_lines = fields.One2many('employee.training.line', 'training_id', string='Training line')
    batch_no = fields.Integer(string='Batch', default=0)

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            if emp.employee_id.partner_name:
                emp.employee_name = emp.employee_id.partner_name
            else:
                emp.employee_name = ''

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0


class TrainingLine(models.Model):
    _name = 'employee.training.line'
    _description = 'Employee Training Line'

    training_id = fields.Many2one('employee.training', string="Onboarding")
    sl = fields.Integer(string='Sl', compute='_compute_get_number', store=True)
    program = fields.Char(string='Program', required=True)
    institute = fields.Char(string='Institute Name/Address')
    local = fields.Char(string='Local/Overseas')
    date_from = fields.Date(string='Date From')
    date_to = fields.Date(string='Date To')

    _sql_constraints = [
        ('employee_id', 'unique (employee_id)', 'You can not create multiple record for the same user!'),
    ]

    @api.depends('training_id')
    def _compute_get_number(self):
        for order in self.mapped('training_id'):
            number = 1
            for line in order.training_lines:
                line.sl = number
                number += 1
