import base64
from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.modules.module import get_module_resource
from . import strings

class OrientationSchedule(models.Model):
    _name = 'employee.orientation.schedule'
    _description = 'Orientation Schedule'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']
    _rec_name = "name"

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_id = fields.Many2one('hr.applicant', domain="[('stage_id', '=', 5)]", required=True, string="Applicant")
    employee_name = fields.Char('Applicant Name', required=True, readonly=False, compute='_compute_emp_name')
    department_id = fields.Many2one('hr.department', 'Department', readonly=True, compute='_compute_department')
    designation = fields.Char('Designation', readonly=True, compute='_compute_employee_designation')
    emp_joining_date = fields.Date('Joining Date', compute='_compute_joining_date')
    emp_supervisor = fields.Many2one('hpl.employee', 'Reporting to', required=True, compute='_compute_emp_supervisor')
    issued_by = fields.Many2one('hpl.employee', string="Issued by", required=True, readonly=False)
    issue_date = fields.Date('Issue Date', readonly=True, default=fields.Date.today())
    issue_date_str = fields.Char('Date', compute='_compute_issue_date_str')
    emp_joining_date_str = fields.Char('Date', compute='_compute_joining_date_str')
    email_template = fields.Text(required=True, string="Email Body", default=lambda self: strings.template_body)
    schedule_lines = fields.One2many('employee.orientation.schedule.line', 'schedule_id', string='Schedule line')
    batch_no = fields.Integer(string='Batch', default=0, readonly=False, store=True, compute='_compute_batch')
    state = fields.Selection(
        [('draft', 'Draft'),
         ('confirmed', 'Confirmed'),
         ], string='State',
        default='draft')

    @api.depends('employee_id')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            if emp.employee_id.partner_name:
                emp.employee_name = emp.employee_id.partner_name
            else:
                emp.employee_name = ''

    @api.depends('employee_id')
    def _compute_department(self):
        for emp in self:
            if emp.employee_id.department_id:
                emp.department_id = emp.employee_id.department_id.id
            else:
                emp.department_id = ''

    @api.depends('employee_id')
    def _compute_employee_designation(self):
        for emp in self:
            if emp.employee_id.job_id:
                emp.designation = emp.employee_id.job_id.name
            else:
                emp.designation = ''

    @api.depends('employee_id')
    def _compute_emp_supervisor(self):
        for rec in self:
            joining_obj = self.env['employee.joining.report'].search([('employee_id', '=', rec.employee_id.id)],
                                                                     limit=1)
            if joining_obj.reporting_employee_id:
                rec.emp_supervisor = joining_obj.reporting_employee_id.id
            else:
                rec.emp_supervisor = ''

    @api.depends('employee_id')
    def _compute_joining_date(self):
        for rec in self:
            joining_obj = self.env['employee.joining.report'].search([('employee_id', '=', rec.employee_id.id)],
                                                                     limit=1)
            if joining_obj.emp_joining_date:
                rec.emp_joining_date = joining_obj.emp_joining_date
            else:
                rec.emp_joining_date = ''

    @api.depends('emp_joining_date')
    def _compute_joining_date_str(self):
        for rec in self:
            if rec.emp_joining_date:
                rec.emp_joining_date_str = rec.emp_joining_date.strftime("%b %d, %Y")

    @api.depends('issue_date')
    def _compute_issue_date_str(self):
        for rec in self:
            rec.issue_date_str = rec.issue_date.strftime("%b %d, %Y")

    def action_confirm(self):
        self.write({
            'state': 'confirmed',
        })

    def action_send_mail(self):
        template_id = self.env.ref('ccl_onboarding.orientation_schedule_email_template_for_responsible')
        template = self.env['mail.template'].browse(template_id)
        values = template_id.generate_email(self.id)
        for line in self.schedule_lines:
            time = ''
            date = line.date.strftime("%b %d, %Y")
            if line.time:
              time = line.time
            values['body_html'] = values['body_html'].replace("{_date_}", date).replace(
                "{_venue_}", line.place.name).replace("{_agenda_}", line.description).replace(
                "{_time_}", time)
            values['email_to'] = line.email
            send_mail = self.env['mail.mail'].create(values)
            send_mail.send()

          # mail to employee
        template_id = self.env.ref('ccl_onboarding.orientation_schedule_email_template').id
        template = self.env['mail.template'].browse(template_id)
        template['email_to'] = self.employee_id.email_from
        # print("template['body_html']---------", template['body_html'])
        template.send_mail(self.id, force_send=True)


class OrientationScheduleLine(models.Model):
    _name = 'employee.orientation.schedule.line'
    _description = 'Orientation Schedule Line'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']

    schedule_id = fields.Many2one('employee.orientation.schedule', string="Orientation Schedule")
    date = fields.Date('Date')
    time = fields.Char('Time')
    place = fields.Many2one('orientation.place', required=True, string="Place")
    description = fields.Text(string="Orientation Description")
    employee_id = fields.Many2one('hpl.employee', required=True, string="Name")
    designation = fields.Char('Designation')
    cell = fields.Char(string="Cell No.", readonly=False, required=False)
    email = fields.Char(string="Email ID", readonly=False, required=False)
    status = fields.Selection(
        [('pending', 'Pending'),
         ('done', 'Done'),
         ], string='Status')

    @api.onchange('employee_id')
    def onchange_employee_cell(self):
        phone_flag = 0
        email_flag = 0
        for emp in self:
            if emp.employee_id:
                if emp.employee_id.position_name:
                    emp.designation = emp.employee_id.position_name
                if emp.employee_id.communication_line:
                    for communication in emp.employee_id.communication_line:
                        # if communication.communication_type_code == 'CELL' or communication.communication_type_code == '0004':
                        if communication.communication_type_code == 'CELL':
                            emp.cell = communication.value
                            # phone_flag += 1
                        elif communication.communication_type_code == '0004':
                            emp.cell = communication.value
                            # phone_flag += 1

                        if communication.communication_type_code == '0010':
                            emp.email = communication.value
                            # email_flag += 1
