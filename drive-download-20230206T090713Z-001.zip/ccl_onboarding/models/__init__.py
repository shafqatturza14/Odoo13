# -*- coding: utf-8 -*-

from . import reference
from . import nominee
from . import nominee_for_sales
from . import orientation_schedule
from . import place
from . import pf_declaration
from . import pf_nomination
from . import employee_development_plan
from . import joining_report
from . import development_plan_template
from . import surety_bond
from . import strings
from . import employee_training
from . import employee_commitment_letter
from . import medical_report