import base64
from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.modules.module import get_module_resource


class EmployeePFDeclaration(models.Model):
    _name = 'employee.pf.declaration'
    _description = 'Employee PF Declaration'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'image.mixin']
    _rec_name = "name"

    name = fields.Char(string='Name', store=True, compute='_compute_rec_name')
    employee_code = fields.Char(string='Employee ID', readonly=False)
    employee_id = fields.Many2one('hr.applicant', default=lambda self: self.env.user.applicant_id, readonly=True,
                                  domain="[('stage_id', '=', 5)]", required=True, string="Select Applicant")
    employee_name = fields.Char('Applicant Name', readonly=False, compute='_compute_emp_name')
    emp_joining_date = fields.Date('Date of Appointment')
    joining_str = fields.Char('Date',  compute='_compute_joining_str')
    emp_resignation_date = fields.Date('Date of Confirmation')
    resignation_str = fields.Char('Date',  compute='_compute_resignation_str')
    permanent_address = fields.Char(string='Address')
    first_witness_id = fields.Many2one('hpl.employee', required=False, string="Name")
    second_witness_id = fields.Many2one('hpl.employee', required=False, string="Name")
    first_witness_job_id = fields.Char('Designation', required=False, readonly=False)
    first_witness_address = fields.Text(string='Address', readonly=False, default=None)
    second_witness_job_id = fields.Char('Designation', required=False, readonly=False)
    second_witness_address = fields.Text(string='Address', readonly=False, default=None)
    batch_no = fields.Integer(string='Batch', default=0, readonly=False, store=True, compute='_compute_batch')
    witness_lines = fields.One2many('employee.witness.line', 'witness_id', string='Witness line')
    company_id = fields.Many2one('company.list', 'Company', compute='_compute_company', store=True)
    _sql_constraints = [
        ('employee_id', 'unique (employee_id)', 'You can not create multiple record for the same user!'),
    ]

    @api.depends('employee_id', 'employee_code')
    def _compute_rec_name(self):
        for emp in self:
            emp.name = emp.employee_id.name

    @api.depends('employee_id')
    def _compute_batch(self):
        for emp in self:
            if emp.employee_id.batches:
                print("-----------", emp.employee_id.batches)
                emp.batch_no = emp.employee_id.batches.batches
            else:
                emp.batch_no = 0

    @api.depends('employee_id')
    def _compute_emp_name(self):
        for emp in self:
            emp.employee_name = emp.employee_id.partner_name

    @api.depends('employee_id')
    def _compute_company(self):
        for emp in self:
            if emp.employee_id:
                user = self.env['res.users'].search([('applicant_id', '=', emp.employee_id.id)])
                company = user.selected_company
                emp.company_id = company
            else:
                emp.company_id = None

    @api.depends('emp_joining_date')
    def _compute_joining_str(self):
        for rec in self:
            if rec.emp_joining_date:
                rec.joining_str = rec.emp_joining_date.strftime("%b %d, %Y")
            else:
                rec.joining_str = ''

    @api.depends('emp_resignation_date')
    def _compute_resignation_str(self):
        for rec in self:
            if rec.emp_resignation_date:
                rec.resignation_str = rec.emp_resignation_date.strftime("%b %d, %Y")

    @api.onchange('first_witness_id')
    def _onchange_first_witness_id(self):
        for emp in self:
            if emp.first_witness_id.position_name:
                emp.first_witness_job_id = emp.first_witness_id.position_name
            addr_flag = 0
            if emp.first_witness_id:
                for address in emp.first_witness_id.address_line:
                    if address.address_type.code == '1' and addr_flag == 0:
                        if address.street_house:
                            emp.first_witness_address = address.street_house  # Parmanent address code = 1
                            addr_flag += 1
                        else:
                            emp.first_witness_address = ''

    @api.onchange('second_witness_id')
    def _onchange_second_witness_id(self):
        for emp in self:
            if emp.second_witness_id.position_name:
                emp.second_witness_job_id = emp.second_witness_id.position_name
            addr_flag = 0
            if emp.second_witness_id:
                for address in emp.second_witness_id.address_line:
                    if address.address_type.code == '1' and addr_flag == 0:
                        if address.street_house:
                            emp.second_witness_address = address.street_house  # Parmanent address code = 1
                            addr_flag += 1
                        else:
                            emp.second_witness_address =''

class WitnessLine(models.Model):
    _name = 'employee.witness.line'
    _description = 'Employee Witness Line'


    witness_id = fields.Many2one('employee.pf.declaration', string="PF Declaration")
    sl = fields.Integer(string='Sl', compute='_compute_get_number', store=True)
    employee_id = fields.Many2one('hpl.employee', required=True, string="Name")
    job_id = fields.Char('Designation', readonly=True, compute='_compute_employee_designation')
    address = fields.Text(string='Address')
    sign = fields.Image(string='Signature')

    @api.depends('witness_id')
    def _compute_get_number(self):
        for order in self.mapped('witness_id'):
            number = 1
            for line in order.witness_lines:
                line.sl = number
                number += 1

    @api.depends('employee_id')
    def _compute_employee_designation(self):
        for emp in self:
            if emp.employee_id.position_name:
                emp.job_id = emp.employee_id.position_name
            else:
                emp.job_id = None