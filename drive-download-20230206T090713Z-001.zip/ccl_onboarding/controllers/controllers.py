# -*- coding: utf-8 -*-
# from odoo import http


# class CclOnboarding(http.Controller):
#     @http.route('/ccl_onboarding/ccl_onboarding/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/ccl_onboarding/ccl_onboarding/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('ccl_onboarding.listing', {
#             'root': '/ccl_onboarding/ccl_onboarding',
#             'objects': http.request.env['ccl_onboarding.ccl_onboarding'].search([]),
#         })

#     @http.route('/ccl_onboarding/ccl_onboarding/objects/<model("ccl_onboarding.ccl_onboarding"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('ccl_onboarding.object', {
#             'object': obj
#         })
