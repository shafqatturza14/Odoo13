# -*- coding: utf-8 -*-
{
    'name': "Onboarding",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Md Sohanur Rahman",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'mail', 'hr', 'hr_recruitment','hpl_employee'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/menu_views.xml',
        'views/nominee_views.xml',
        'views/nominee_for_sales_views.xml',
        'views/reference_views.xml',
        'views/orientation_schedule_views.xml',
        'views/orientation_place_views.xml',
        'views/pf_declaration_views.xml',
        'views/pf_nomination_views.xml',
        'views/employee_development_plan_views.xml',
        'views/joining_report_views.xml',
        'views/access_template_views.xml',
        'views/workplace_template_views.xml',
        'views/provide_information_template_views.xml',
        'views/training_program_template_views.xml',
        'views/surety_bond_views.xml',
        'views/employee_training_views.xml',
        'views/commitment_letter_views.xml',
        'views/medical_report_views.xml',
        'report/nominee_form_pdf.xml',
        'report/nominee_form_pdf_for_sales.xml',
        'report/reference_pdf.xml',
        'report/orientation_schedule_pdf.xml',
        'report/pf_declaration_report_pdf.xml',
        'report/pf_nomination_report_pdf.xml',
        'report/joinning_report_pdf.xml',
        'report/joining_announcement_pdf.xml',
        'report/emp_dev_plan_report_pdf.xml',
        'report/surety_bond_pdf.xml',
        'report/commitment_letter_pdf.xml',
        'data/mail_template.xml',
    ],
}
