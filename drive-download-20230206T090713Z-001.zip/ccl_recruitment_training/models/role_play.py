# -*- coding: utf-8 -*-
from datetime import datetime

from odoo import api, fields, models, _


class RolePlay(models.Model):
    _name = 'role.play'
    _description = 'Role Play '
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    batch_id = fields.Many2one('trainee.details.main', string='Batch', required=True, ondelete='cascade')
    subject = fields.Char(string='Subject', required=False)
    trainee_lines = fields.One2many('trainee.lines',
                                          'line_id',
                                          string='Tracker Line')

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                    }
                    lines.append((0, 0, val))
            rec.trainee_lines = lines

class TraineeLines(models.Model):
    _name = 'trainee.lines'
    _description = 'Trainee Lines'

    line_id = fields.Many2one('role.play', string='', required=False, ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='', required=False, ondelete='cascade')
    trainee_name = fields.Char('Trainee Name', required=False)
    trainee_code = fields.Char('Trainee ID')
    grooming = fields.Float('Grooming', required=False)
    role_play = fields.Float('Role Play', required=False)
    remarks = fields.Char('Remarks', required=False, store=True, default='')

    @api.onchange('trainee_id')
    def _compute_name(self):
        for emp in self:
            if emp.trainee_id:
                emp.trainee_code = emp.trainee_id.t_id
