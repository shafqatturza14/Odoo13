# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from datetime import datetime

class MIOBatch(models.Model):
    _name = 'mio.batch'
    _description = 'MIO Batch Setting'
    _rec_name = 'mio_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    @api.model
    def create(self, vals):
        if vals.get('mio_id', 'New') == 'New':
            vals['mio_id'] = self.env['ir.sequence'].next_by_code('mio.batch.sequence')

        # vals['state'] = 'draft'

        res = super(MIOBatch, self).create(vals)
        return res

    mio_name = fields.Char(string='MIO Name', required=True)

    mio_id = fields.Char(string="MIO Batch ID", required=False, copy=False, readonly=True, index=True,
                       default=lambda self: _('New'))

    trainee_id = fields.Many2many('trainee.details', string='Trainee')
