# -*- coding: utf-8 -*-

from odoo import fields, models, api, _


class FieldLogisticsTracker(models.Model):
    _name = 'field.logistic.tracker'
    _description = 'Field Logistics Tracker'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    batch_id = fields.Many2one('trainee.details.main', string='Batch', required=True, ondelete='cascade')
    trainees_lines = fields.One2many('trainees.lines', 'batch_track_id', string='Trainee List')
    items = fields.Many2one('logistic.items', string="Items")
    sig_1 = fields.Many2one('hpl.employee', 'Signature Name(1)')
    sig_1_designation = fields.Char('Signature Designation(1)')
    sig_2 = fields.Many2one('hpl.employee', 'Signature Name(2)')
    sig_2_designation = fields.Char('Signature Designation(2)')

    @api.onchange('sig_1')
    def _compute_sig1(self):
        self.sig_1_designation = self.sig_1.position_name

    @api.onchange('sig_2')
    def _compute_sig2(self):
        self.sig_2_designation = self.sig_2.position_name

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                    }
                    lines.append((0, 0, val))
            rec.trainees_lines = lines

    @api.onchange('items')
    def onchange_item_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.items.item_lines:
                val = {
                    'trainee_element_id': line.line_id.id,
                    'element': line.item_name,
                }
                lines.append((0, 0, val))
            rec.trainees_lines.element_id = lines

class Trainees(models.Model):
    _name = 'trainees.lines'
    _description = 'Trainees Lines'

    batch_track_id = fields.Many2one('field.logistic.tracker', ondelete='cascade')
    element_id = fields.One2many('element.list', 'trainee_element_id')
    trainee_id = fields.Many2one('trainee.details', string='Trainee Name')
    trainee_name = fields.Char(string='Name', store=True)
    trainee_code = fields.Char('Trainee ID', store=True)


class ElementListLine(models.Model):
    _name = 'element.list'
    _description = 'Element List'

    trainee_element_id = fields.Many2one('trainees.lines', ondelete='cascade')
    element = fields.Char(string='Element')
    quantity = fields.Integer(string='Quantity', default=1)
