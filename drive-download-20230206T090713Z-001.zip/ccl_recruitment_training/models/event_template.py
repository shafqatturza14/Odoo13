
from odoo import api, fields, models, _

class EventTemplate(models.Model):
    _name = 'event.template'
    _description = "Event Template"
    _inherit = ['mail.thread', 'mail.activity.mixin']


    name = fields.Char('Event Template Name')
    event_lines = fields.One2many('event.template.line', 'event_line_id', string="Template Line")


class EventTemplateLines(models.Model):
    _name = 'event.template.line'
    _description = "Event Template Line"

    event_line_id = fields.Many2one('event.template', ondelete='cascade')
    event = fields.Char('Event')
