# -*- coding: utf-8 -*-
from datetime import datetime

from odoo import api, fields, models, _


class TraineeEvaluation(models.Model):
    _name = 'trainee.evaluation'
    _description = 'Field Training'
    _rec_name = 'batch'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    batch = fields.Many2one('field.visit.list', 'Batch No')
    trainee_id = fields.Many2one('trainee.details', string='Name of Trainee', required=False)
    trainee_name = fields.Char(string='Trainee', required=False, store=True)
    trainee_code = fields.Char(string='Trainee ID', required=False, store=True)
    trainee_cell = fields.Char(string='Trainee cell no', required=False, store=True)
    mio_batch_id = fields.Many2one('trainee.details.main', string='MIO Batch', store=True, required=False)
    mio_code = fields.Char('MIO Batch Number', required=False, store=True)
    name_of_mio = fields.Char('Name of MIO', required=False)
    mio_cell = fields.Char(string='MIO cell no', required=False, store=True)
    name_am_rm = fields.Char('Name of AM/RM', required=False, store=True, default='')
    am_rm_cell = fields.Char(string='AM/RM cell no', required=False, store=True)
    name_of_territory = fields.Char('Name of Territory', required=False)
    name_of_region = fields.Char('Region', required=False, store=True, default='')
    reporting_place = fields.Char('Reporting Place', required=False, store=True, default='')
    reporting_time = fields.Char('Reporting Time', required=False, store=True, default='00:00')
    f_date = fields.Date('First Date', required=False, store=True)
    se_date = fields.Date('Second Date', required=False, store=True)
    third_date = fields.Date('Third Date', required=False, store=True)

    observation_lines = fields.One2many('observation.lines',
                                          'observation_id',
                                          string='Observation Line')

    findings = fields.Text('Any other findings or comments of AM/RM', required=False)
    signature_of_trainee_mio = fields.Char('Signature of Trainee MIO', required=False)
    signature_of_attached_mio = fields.Char('Signature of Attached MIO', required=False)
    signature_of_am_rm = fields.Char('Signature of AM/RM', required=False)
    dgm_name = fields.Many2one('hpl.employee', string="Name", required=True)
    dgm_designation = fields.Char('Designation', required=False, store=True)
    dgm_full_name = fields.Char('Full Name', required=False, store=True)

    event_template_id = fields.Many2one('event.template', string='Event Template')

    @api.onchange('batch')
    def dates(self):
        if self.batch.start_date:
            self.f_date = self.batch.start_date
        if self.batch.middle_date:
            self.se_date = self.batch.middle_date
        if self.batch.end_date:
            self.third_date = self.batch.end_date

    @api.onchange('dgm_name')
    def _compute_dgm(self):
        self.dgm_designation = self.dgm_name.position_name

    @api.onchange('trainee_id')
    def _compute_name(self):
        for trainee in self:
            if trainee.trainee_id:
                trainee.trainee_name = trainee.trainee_id.name
                trainee.trainee_code = trainee.trainee_id.t_id
                trainee.trainee_cell = trainee.trainee_id.phone_number

    @api.onchange('mio_batch_id')
    def _compute_mio_batch_code(self):
        for batch in self:
            if batch.mio_batch_id:
                batch.mio_code = batch.mio_batch_id.batch_no
                print(batch.mio_code)

    @api.onchange('event_template_id')
    def onchange_event_template_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.event_template_id.event_lines:
                val = {
                    'event_id': line.event_line_id.id,
                    'event': line.event,
                }
                lines.append((0, 0, val))
            rec.observation_lines = lines


class ObservationLine(models.Model):
    _name = 'observation.lines'
    _description = 'Observation Line'

    observation_id = fields.Many2one('trainee.evaluation')
    event_id = fields.Integer('Event ID')
    event = fields.Char('Event')
    mio_observation_poor = fields.Selection(
        [('yes', '(✔)'), ('no', '(x)'), ('','')], string='Poor(MIO)',
        default='')
    mio_observation_average = fields.Selection(
        [('yes', '(✔)'), ('no', '(x)'), ('','')], string='Average(MIO)',
        default='')
    mio_observation_good = fields.Selection(
        [('yes', '(✔)'), ('no', '(x)'), ('','')], string='Good(MIO)',
        default='')
    mio_observation_vgood = fields.Selection(
        [('yes', '(✔)'), ('no', '(x)'), ('','')], string='V.Good(MIO)',
        default='')

    am_rm_observation_poor = fields.Selection(
        [('yes', '(✔)'), ('no', '(x)'), ('','')], string='Poor(AM/RM)',
        default='')

    am_rm_observation_avg = fields.Selection(
        [('yes', '(✔)'), ('no', '(x)'), ('','')], string='Average(AM/RM)',
        default='')

    am_rm_observation_good = fields.Selection(
        [('yes', '(✔)'), ('no', '(x)'), ('','')], string='Good(AM/RM)',
        default='')

    am_rm_observation_vgood = fields.Selection(
            [('yes', '(✔)'), ('no', '(x)'), ('','')], string='V.Good(AM/RM)',
            default='')


