# -*- coding: utf-8 -*-
from datetime import datetime

from odoo import api, fields, models, _


class BriefcaseTracker(models.Model):
    _name = 'briefcase.tracker'
    _description = 'Briefcase Tracker for Trainee'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    batch_id = fields.Many2one('trainee.details.main', string='Batch No', required=False, ondelete='cascade')
    tracker_lines = fields.One2many('tracker.lines',
                                          'line_id',
                                          string='Tracker Line')
    sig_1 = fields.Many2one('hpl.employee', 'Signature Name(1)')
    sig_1_designation = fields.Char('Signature Designation(1)')
    sig_2 = fields.Many2one('hpl.employee', 'Signature Name(2)')
    sig_2_designation = fields.Char('Signature Designation(2)')

    @api.onchange('sig_1')
    def _compute_sig1(self):
        self.sig_1_designation = self.sig_1.position_name

    @api.onchange('sig_2')
    def _compute_sig2(self):
        self.sig_2_designation = self.sig_2.position_name

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                        'contact_no': line.phone_number,
                    }
                    lines.append((0, 0, val))
            rec.tracker_lines = lines


class TrackerLines(models.Model):
    _name = 'tracker.lines'
    _description = 'Tracker Line'

    line_id = fields.Many2one('briefcase.tracker', string='', required=False, ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='', required=False)
    trainee_name = fields.Char('Trainee Name', required=False)
    trainee_code = fields.Char('ID')
    items = fields.Selection(
        [('yes', '(✔)'), ('no', '(x)'), ('','')], string='Briefcase',
        default='yes')
    contact_no = fields.Char('Contact No', default='')
    signature = fields.Char('Signature of the recipient', required=False, store=True, default='')

