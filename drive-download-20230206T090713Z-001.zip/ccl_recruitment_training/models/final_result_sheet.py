
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class FinalResultSheet(models.Model):
    _name = 'final.result.sheet.details'
    _description = "Final Result Sheet"
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    batch_id = fields.Many2one('trainee.details.main', 'Batch NO', ondelete='cascade')
    sheet_lines = fields.One2many('result.list','final_sheet_id')

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            system = self.env["system.pss"].search([("batch_id.batch_no", "=", rec.batch_id.batch_no)])
            pss = self.env["pss.ii"].search([("batch_id.batch_no", "=", rec.batch_id.batch_no)])
            products = self.env["products.sheet"].search([("batch_id.batch_no", "=", rec.batch_id.batch_no)])
            role_play = self.env['grooming.role.sheet'].search([("batch_id.batch_no", "=", rec.batch_id.batch_no)])
            assignment = self.env["assignment.sheet"].search([("batch_id.batch_no", "=", rec.batch_id.batch_no)])


            lines = [(5, 0, 0)]
            for line, sys, ps, pro, ro, ass in zip(self.batch_id.details_line, system.trainees_lines, pss.trainees_lines, products.trainees_lines, role_play.trainees_lines, assignment.trainees_lines):
                val = {
                    'trainee_id': line.id,
                    'trainee_name': line.name,
                    'trainee_code': line.t_id,
                    'system': sys.system_sum,
                    'pss': ps.pss_ii_sum,
                    'products': pro.product_sum,
                    'role_play': ro.role_sum,
                    'grooming': ro.grooming_sum,
                    'assignment': ass.assignment_sum,
                    'total': sys.system_sum + ps.pss_ii_sum + pro.product_sum + ro.role_sum + ro.grooming_sum + ass.assignment_sum,
                }
                lines.append((0, 0, val))
            rec.sheet_lines = lines
            print(rec.sheet_lines)

class ResultList(models.Model):
    _name = 'result.list'
    _description = "Result List"

    final_sheet_id = fields.Many2one('final.result.sheet.details', ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', 'Another Team Member')
    trainee_code = fields.Char('Trainee ID')
    trainee_name = fields.Char('Trainee Name')
    system = fields.Float('System(30)')
    pss = fields.Float('PSS-II(20)')
    products = fields.Float('Products(20)')
    role_play = fields.Float('Role Play(05)')
    assignment = fields.Float('Assignment(10)')
    grooming = fields.Float('Grooming(05)')
    oral_test = fields.Float('Oral Test(10)', store=True)
    total = fields.Float('Total(100)', compute='oral_test_total', store=True)
    category = fields.Selection(
        [('C', 'C'), ('C/GP', 'C/GP'), ('GP', 'GP')], default='C')

    @api.depends('oral_test')
    def oral_test_total(self):
        total = 0.0
        for rec in self:
            total = rec.oral_test + rec.system + rec.pss + rec.role_play + rec.products + rec.assignment + rec.grooming
            rec.total = rec.oral_test + rec.system + rec.pss + rec.grooming + rec.products + rec.assignment + rec.role_play
        if total > 100.00:
            raise ValidationError(_('Total must be less than 100'))

