# -*- coding: utf-8 -*-
from datetime import datetime

from odoo import api, fields, models, _


class fieldAttendance(models.Model):
    _name = 'field.attendance'
    _description = 'field Attendance'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    batch_id = fields.Many2one('trainee.details.main', string='Batch', required=True, ondelete='cascade')
    from_date = fields.Date('Form Date')
    to_date = fields.Date('To Date')
    trainee_lines = fields.One2many('field.attendance.line', 'attendance_line_id', string='Tracker Line')

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                    }
                    lines.append((0, 0, val))
            rec.trainee_lines = lines

class FieldAttendanceLine(models.Model):
    _name = 'field.attendance.line'
    _description = 'Field Attendance line'

    attendance_line_id = fields.Many2one('field.attendance', string='', required=False, ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='Another Team', required=False)
    trainee_name = fields.Char('Trainee Name', required=False)
    trainee_code = fields.Char('ID')
    attendance_count = fields.Integer('Days', required=False, default=3)

    @api.onchange('trainee_id')
    def trainee_code_change(self):
        self.trainee_code = self.trainee_id.t_id

