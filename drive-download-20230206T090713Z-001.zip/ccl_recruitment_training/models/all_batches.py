# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError


class AllBatch(models.Model):
    _name = 'all.batch'
    _description = 'All Batch'
    _rec_name = 'batches'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    batches = fields.Integer('Batch')
    batch_field = fields.Char('Batch NO', compute='batch_change', store=True)

    @api.depends('batches')
    def batch_change(self):
        for rec in self:
            if rec.batches:
                rec.batch_field = str(rec.batches)
                print("Batch Field:", rec.batches)
