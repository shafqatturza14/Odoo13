# -*- coding: utf-8 -*-
from datetime import datetime

from odoo import api, fields, models, _


class FieldVisitList(models.Model):
    _name = 'field.visit.list'
    _description = 'Description'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    batch_id = fields.Many2one('trainee.details.main', string='Batch ID', required=True, ondelete='cascade')
    batch_number = fields.Char(string='Batch Number', store=True)
    team_name = fields.Char(string='Team Name', store=True)
    start_date = fields.Date(string='First Date', default=fields.Date.context_today)
    end_date = fields.Date(string='Third Date', default=fields.Date.context_today)
    middle_date = fields.Date(string='Second Date', default=fields.Date.context_today)
    start_day = fields.Char(string='First Day')
    end_day = fields.Char(string='Third Day')
    middle_day = fields.Char(string='Second Day')
    reporting_time = fields.Float(string='Reporting Time')
    closing_time = fields.Float(string='Closing Time')
    list_lines = fields.One2many('visit.list',
                                 'line_id',
                                 string='Visit List Line')

    dgm_name = fields.Many2one('hpl.employee', string="Name", required=True)
    dgm_designation = fields.Char('Designation', required=False, store=True)
    dgm_full_name = fields.Char('Full Name', required=False, store=True)

    @api.onchange('dgm_name')
    def _compute_dgm(self):
        self.dgm_designation = self.dgm_name.position_name

    @api.onchange('batch_id')
    def _compute_batch_name(self):
        self.team_name = self.batch_id.hpl_team
        self.batch_number = self.batch_id.batch_no
        print(self.batch_number)
        print(self.team_name)

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            val = {}
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_id': line.id,
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                        'trainee_cell_phone': line.phone_number,
                    }
                    lines.append((0, 0, val))
            rec.list_lines = lines

    @api.onchange('start_date')
    def _compute_start_day(self):
        import calendar
        if self.start_date:
            self.start_day = calendar.day_name[(self.start_date).weekday()]
        else:
            self.start_day = ''

    @api.onchange('end_date')
    def _compute_end_day(self):
        import calendar
        if self.end_date:
            self.end_day = calendar.day_name[(self.end_date).weekday()]
        else:
            self.end_day = ''

    @api.onchange('middle_date')
    def _compute_middle_day(self):
        import calendar
        if self.middle_date:
            self.middle_day = calendar.day_name[(self.middle_date).weekday()]
        else:
            self.middle_day = ''


class VisitList(models.Model):
    _name = 'visit.list'
    _description = 'Field Visit List'

    line_id = fields.Many2one('field.visit.list', ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='Trainee Name')
    trainee_name = fields.Char(string='Trainee Name')
    trainee_code = fields.Char(string='ID')
    trainee_cell_phone = fields.Char(string='Cell Phone')
    reporting_person_id = fields.Many2one('hpl.employee', string='Reporting Person')
    reporting_person = fields.Char(string='Reporting Person', store=True)
    rep_cell_no = fields.Char(string='Cell No', default="+8801")
    reporting_place = fields.Char(string='Reporting Place')
    category = fields.Char("Category")


    @api.onchange('trainee_id')
    def _compute_trainee_details(self):
        self.trainee_code = self.trainee_id.t_id
        self.trainee_cell_phone = self.trainee_id.phone_number


    @api.onchange('reporting_person_id')
    def _compute_reporting_person(self):
        if self.reporting_person_id.position_name:
            position = self.reporting_person_id.position_name
            print(position)
            lst = position.split()
            oupt = ""
            for word in lst:
                oupt += word[0]
            oupt = oupt.upper()
            print(oupt)
            self.reporting_person = self.reporting_person_id.full_name + ', ' + oupt
            print(self.reporting_person)
        self.reporting_place = self.reporting_person_id.org_unit

        if self.reporting_person_id.communication_line:
            for to in self.reporting_person_id.communication_line:
                if to.communication_type.code == 'CELL':
                    self.rep_cell_no = to.value

