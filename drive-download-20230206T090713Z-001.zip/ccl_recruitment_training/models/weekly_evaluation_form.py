# -*- coding: utf-8 -*-

from odoo import fields, models, api, _


class FieldLogisticsTracker(models.Model):
    _name = 'weekly.evaluation.form'
    _description = 'Weekly Evaluation Form'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    batch_id = fields.Many2one('trainee.details.main', String='Batch NO', required=True, ondelete='cascade')
    trainees_lines = fields.One2many('trainee.list.lines', 'trainee_track_id', string='Trainee List')

    basic_template_id = fields.Many2one('result.sheet.template', 'Basic Template', store=True)
    product_template_id = fields.Many2one('result.sheet.template', 'Product Template', store=True)
    role_play_template_id= fields.Many2one('result.sheet.template', 'Role Play Template', store=True)
    pss_template_id = fields.Many2one('result.sheet.template', 'PSS II Template', store=True)

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                val = {
                    'trainee_name': line.name,
                    'trainee_code': line.t_id,
                    'system_sum': 0.0,
                    'product_sum': 0.0,
                    'role_sum': 0.0,
                    'pss_sum': 0.0,
                }
                lines.append((0, 0, val))
            rec.trainees_lines = lines

    @api.onchange('basic_template_id')
    def basic_subject_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.basic_template_id.event_lines:
                val = {
                    'subject': line.subject,
                    'allocate_mark': line.allocate_mark,
                }
                lines.append((0, 0, val))
            rec.trainees_lines.subject_lines = lines

    @api.onchange('product_template_id')
    def product_subject_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.product_template_id.event_lines:
                val = {
                    'subject': line.subject,
                    'allocate_mark': line.allocate_mark,
                }
                lines.append((0, 0, val))
            rec.trainees_lines.product_lines = lines

    @api.onchange('role_play_template_id')
    def role_subject_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.role_play_template_id.event_lines:
                val = {
                    'subject': line.subject,
                    'allocate_mark': line.allocate_mark,
                }
                lines.append((0, 0, val))
            rec.trainees_lines.role_lines = lines

    @api.onchange('pss_template_id')
    def pss_subject_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.pss_template_id.event_lines:
                val = {
                    'subject': line.subject,
                    'allocate_mark': line.allocate_mark,
                }
                lines.append((0, 0, val))
            rec.trainees_lines.pssii_lines = lines




class Trainees(models.Model):
    _name = 'trainee.list.lines'
    _description = 'Trainees Lines'

    trainee_track_id = fields.Many2one('weekly.evaluation.form', ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='Trainee Name')
    trainee_name = fields.Char(string='Name', store=True)
    trainee_code = fields.Char('Trainee ID', store=True)
    subject_lines = fields.One2many('weekly.trainee.system.subject', 'subject_id', string='Subject List')
    product_lines = fields.One2many('weekly.trainee.product.subject', 'product_id', string='Product List')
    role_lines = fields.One2many('weekly.trainee.role.subject', 'role_id', string='Role List')
    pssii_lines = fields.One2many('weekly.trainee.pssii.subject', 'pssii_id', string='PSS II List')

    system_sum = fields.Float('Basic Sum', compute="_compute_basic_obtain_mark", store=True)
    product_sum = fields.Float('Product Sum', compute="_compute_product_obtain_mark", store=True)
    role_sum = fields.Float('Role Sum', compute="_compute_role_obtain_mark", store=True)
    pss_sum = fields.Float('PSS II Sum', compute="_compute_pss_obtain_mark", store=True)

    @api.depends('subject_lines')
    def _compute_basic_obtain_mark(self):
        for rec in self:
            sum = 0.0
            cnt = 0
            for line in rec.subject_lines:
                if line.obtain_mark:
                    sum += line.obtain_mark
                cnt += 1
            if cnt > 0 and rec.subject_lines:
                rec.system_sum = sum / float(cnt)

    @api.depends('product_lines')
    def _compute_product_obtain_mark(self):
        for rec in self:
            sum = 0.0
            cnt = 0
            for line in rec.product_lines:
                print(line.obtain_mark)
                if line.obtain_mark:
                    sum += line.obtain_mark
                cnt += 1
            print("=================SUM========================")
            print(sum)
            if cnt > 0 and rec.product_lines:
                rec.product_sum = sum / float(cnt)

    @api.depends('role_lines')
    def _compute_role_obtain_mark(self):
        for rec in self:
            sum = 0.0
            cnt = 0
            for line in rec.role_lines:
                if line.obtain_mark:
                    sum += line.obtain_mark
                cnt += 1
            if cnt > 0 and rec.role_lines:
                rec.role_sum = sum / float(cnt)

    @api.depends('pssii_lines')
    def _compute_pss_obtain_mark(self):
        for rec in self:
            sum = 0.0
            cnt = 0
            for line in rec.pssii_lines:
                if line.obtain_mark:
                    sum += line.obtain_mark
                cnt += 1
            if cnt > 0 and rec.pssii_lines:
                rec.pss_sum = sum / float(cnt)


class WeeklyTraineesSystemSubject(models.Model):
    _name = 'weekly.trainee.system.subject'
    _description = 'Trainees Subject Lines'

    subject_id = fields.Many2one('trainee.list.lines', ondelete='cascade')
    subject = fields.Char('Subject')
    allocate_mark = fields.Float('Allocate Mark')
    obtain_mark = fields.Float('Obtain Mark')


class WeeklyTraineesProductSubject(models.Model):
    _name = 'weekly.trainee.product.subject'
    _description = 'Trainees Subject Lines'

    product_id = fields.Many2one('trainee.list.lines', ondelete='cascade')
    subject = fields.Char('Subject')
    allocate_mark = fields.Float('Allocate Mark')
    obtain_mark = fields.Float('Obtain Mark')


class WeeklyTraineesRoleSubject(models.Model):
    _name = 'weekly.trainee.role.subject'
    _description = 'Trainees Subject Lines'

    role_id = fields.Many2one('trainee.list.lines', ondelete='cascade')
    subject = fields.Char('Subject')
    allocate_mark = fields.Float('Allocate Mark')
    obtain_mark = fields.Float('Obtain Mark')


class WeeklyTraineesPSSIISubject(models.Model):
    _name = 'weekly.trainee.pssii.subject'
    _description = 'Trainees Subject Lines'

    pssii_id = fields.Many2one('trainee.list.lines', ondelete='cascade')
    subject = fields.Char('Subject')
    allocate_mark = fields.Float('Allocate Mark')
    obtain_mark = fields.Float('Obtain Mark')



