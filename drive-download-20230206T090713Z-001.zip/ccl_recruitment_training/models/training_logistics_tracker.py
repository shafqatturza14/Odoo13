# -*- coding: utf-8 -*-

from odoo import fields, models, api, _


class LogisticsTracker(models.Model):
    _name = 'training.logistic.tracker'
    _description = 'Logistics Tracker'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    batch_id = fields.Many2one('trainee.details.main', string='Batch', required=True, ondelete='cascade')
    trainee_lists = fields.One2many('trainee.list.line', 'batch_track_id', string='Trainee List Lines')
    item_id = fields.Many2one('logistic.items', string="Items")
    sig_1 = fields.Many2one('hpl.employee', 'Signature Name(1)')
    sig_1_designation = fields.Char('Signature Designation(1)')
    sig_2 = fields.Many2one('hpl.employee', 'Signature Name(2)')
    sig_2_designation = fields.Char('Signature Designation(2)')

    @api.onchange('sig_1')
    def _compute_sig1(self):
        self.sig_1_designation = self.sig_1.position_name

    @api.onchange('sig_2')
    def _compute_sig2(self):
        self.sig_2_designation = self.sig_2.position_name


    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                    }
                    lines.append((0, 0, val))
            rec.trainee_lists = lines

    @api.onchange('item_id')
    def onchange_item_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.item_id.item_lines:
                val = {
                    'trainee_track_id': line.line_id.id,
                    'element': line.item_name,
                }
                lines.append((0, 0, val))
            rec.trainee_lists.element_list_id = lines

class TraineeListLine(models.Model):
    _name = 'trainee.list.line'
    _description = 'Trainee List'

    batch_track_id = fields.Many2one('training.logistic.tracker', ondelete='cascade')
    element_list_id = fields.One2many('element.list.line', 'trainee_track_id')
    trainee_id = fields.Many2one('trainee.details', string='Trainee Name')
    trainee_name = fields.Char(string='Name', store=True)
    trainee_code = fields.Char('Trainee ID', store=True)


    @api.depends('trainee_id')
    def _compute_trainee_name(self):
        if self.trainee_id:
            self.trainee_name = self.trainee_id.name
            print(self.trainee_name)

    @api.onchange('trainee_id')
    def _compute_trainee_code(self):
        if self.trainee_id:
            self.trainee_code = self.trainee_id.t_id
            print(self.trainee_name)


class ElementListLine(models.Model):
    _name = 'element.list.line'
    _description = 'Element List'

    trainee_track_id = fields.Many2one('trainee.list.line', ondelete='cascade')
    element = fields.Char(string='Element')
    quantity = fields.Integer(string='Quantity', default=1)
