# -*- coding: utf-8 -*-
from datetime import datetime
from odoo import api, fields, models, _
from odoo.exceptions import UserError



class TrainingSchedule(models.Model):
    _name = 'training.schedule'
    _description = 'Description'
    _rec_name = 'schedule_start_date'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    employee_id = fields.Many2one('hpl.employee', string='Contact Person', required=False)
    employee_name = fields.Char(string='Name', store=True, required=False, compute="_compute_name")
    phone_number = fields.Char('Phone Number', required=False)
    schedule_start_date = fields.Date('Start Date', required=False, default = datetime.now())
    schedule_start_day = fields.Char('Start Day', required=False, store=True, default='')
    schedule_end_date = fields.Date('End Date', required=False, default=datetime.now())
    schedule_end_day = fields.Char('End Day', required=False, store=True, default='')
    schedule_date_lines = fields.One2many('schedule.date.lines',
                                          'schedule_line_id',
                                          string='Schedule Date Line')

    mio_batch = fields.Many2one('trainee.details.main', string='MIO Batch ID')
    # mio_batch_number = fields.Char(store=True, string='MIO Batch Number', compute="_compute_batch_number")
    # training_id = fields.Many2one('training.management', string='Training Course')
    training_room = fields.Integer(string='Room Number')
    venue = fields.Many2one('venue.details', string='Venue')
    tea_break_start = fields.Float(string='Tea Break Start')
    tea_break_start_format = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string=' ',
                                              default='AM')
    tea_break_end = fields.Float(string='Tea Break End')
    tea_break_end_format = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string=' ',
                                            default='AM')
    lunch_break_start = fields.Float(string='Lunch Break Start')
    lunch_break_start_format = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string=' ',
                                                default='AM')
    lunch_break_end = fields.Float(string='Lunch Break End')
    lunch_break_end_format = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string=' ',
                                              default='AM')
    trainees_lines = fields.One2many('trainee.system', 'trainee_track_id', string='Trainee List')

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                val = {
                    'trainee_name': line.name,
                    'trainee_code': line.t_id,
                }
                lines.append((0, 0, val))
            rec.trainees_lines = lines

    @api.depends('employee_id')
    def _compute_name(self):
        for emp in self:
            if emp.employee_id:
                emp.employee_name = emp.employee_id.full_name

    # @api.depends('mio_batch')
    # def _compute_batch_number(self):
    #     for batch in self:
    #         if batch.mio_batch:
    #             batch.mio_batch_number = batch.mio_batch.mio_id


    @api.onchange('schedule_start_date')
    def _compute_start_day(self):
        import calendar
        self.schedule_start_day = calendar.day_name[(self.schedule_start_date).weekday()]

    @api.onchange('schedule_end_date')
    def _compute_end_day(self):
        import calendar
        self.schedule_end_day = calendar.day_name[(self.schedule_end_date).weekday()]


class TraineeList(models.Model):
    _name = 'attendance.trainee.list'
    _description = 'Description'

    trainee_track_id = fields.Many2one('training.schedule')
    trainee_name = fields.Char('Trainee Name', store=True)
    trainee_code = fields.Char('Trainee ID', store=True)


class ScheduleDateLines(models.Model):
    _name = 'schedule.date.lines'
    _description = 'Schedule Date Line'

    schedule_line_id = fields.Many2one('training.schedule')
    sequence = fields.Integer(default=10)
    schedule_date = fields.Date('Schedule Date', default=datetime.now())
    schedule_day = fields.Char(string='Day', default='')
    schedule_type = fields.Selection([('weekday', 'Week Day'),
                                      ('holiday', 'Holiday'),
                                      ('field_visit', 'Field visit')], default='weekday')
    holiday_name = fields.Char(string='Holiday Name', Default='Weekly Holiday')
    schedule_time_lines = fields.One2many('schedule.time.lines',
                                          'schedule_time_line_id',
                                          string='Schedule Time Line')


    @api.onchange('schedule_date')
    def class_day(self):
        import calendar
        if self.schedule_date:
            self.schedule_day = calendar.day_name[(self.schedule_date).weekday()]


class ScheduleTimeLines(models.Model):
    _name = 'schedule.time.lines'
    _description = 'Schedule Time Line'

    schedule_time_line_id = fields.Many2one('schedule.date.lines')
    schedule_start_time = fields.Float(string='Start Time')
    schedule_start_time_format = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string='Start FMT',
                                                  default='AM')
    schedule_end_time = fields.Float(string='End Time')
    schedule_end_time_format = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string='End FMT',
                                                default='AM')
    subject = fields.Char(string='Subject')
    resource = fields.Many2one('hpl.employee', string="Resource")
    resource_alt = fields.Many2one('hpl.employee', string="Alternate Resource")
