# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError


class AssignmentSheet(models.Model):
    _name = 'assignment.sheet'
    _description = 'Assignment Sheet'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    batch_id = fields.Many2one('trainee.details.main', String='Batch No', ondelete='cascade', required=True)
    trainees_lines = fields.One2many('trainee.assignment.lines', 'trainee_track_id', string='Trainee List')
    template_id = fields.Many2one('result.sheet.template', 'Template', store=True, ondelete='cascade')

    @api.onchange('template_id')
    def subject_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.template_id.event_lines:
                val = {
                    'subject': line.subject,
                    'allocate_mark': line.allocate_mark,
                }
                lines.append((0, 0, val))
            rec.trainees_lines.subject_lines = lines

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                        'assignment_sum': 0.00,
                        'assignment_sum_percentage': 0.00,
                    }
                    lines.append((0, 0, val))
            rec.trainees_lines = lines


class TraineeAssignmentLines(models.Model):
    _name = 'trainee.assignment.lines'
    _description = 'Trainee Assignment Lines'

    trainee_track_id = fields.Many2one('assignment.sheet', ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='Trainee Name')
    trainee_name = fields.Char(string='Name', store=True)
    trainee_code = fields.Char('Trainee ID', store=True)
    subject_lines = fields.One2many('assignment.system.subject', 'subject_id', string='Subject List')

    assignment_sum = fields.Float('Assignment Sum', compute="_compute_obtain_mark", store=True)
    assignment_sum_percentage = fields.Float('Assignment Percentage', store=True)



    @api.depends('subject_lines')
    def _compute_obtain_mark(self):
        for rec in self:
            sum = 0.0
            cnt = 0
            for line in rec.subject_lines:
                if line.obtain_mark:
                    sum += line.obtain_mark
                    cnt += 1
            avg = 0.09
            if cnt > 0 and rec.subject_lines:
                avg = sum / float(cnt)
                rec.assignment_sum = avg
                rec.assignment_sum_percentage = (avg/ 10.0) * 100.0
            if avg > 10.00:
                raise ValidationError(_('Average must be less than 10.00!'))


class AssignmentSheetSubject(models.Model):
    _name = 'assignment.system.subject'
    _description = 'Trainees Subject Lines'

    subject_id = fields.Many2one('trainee.assignment.lines', ondelete='cascade',)
    subject = fields.Char('Subject')
    allocate_mark = fields.Float('Allocate Mark')
    obtain_mark = fields.Float('Obtain Mark')
