# -*- coding: utf-8 -*-
from datetime import datetime

from odoo import api, fields, models, _


class TrainingAttendance(models.Model):
    _name = 'training.attendance'
    _description = 'Training Attendance'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    batch_id = fields.Many2one('trainee.details.main', string='Batch', required=True, ondelete='cascade')
    trainee_lines = fields.One2many('training.attendance.line', 'attendance_line_id', string='Tracker Line')

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                        'attendance_count': self.batch_id.duration,
                        'phone_number': line.phone_number,
                    }
                    lines.append((0, 0, val))
            rec.trainee_lines = lines

class TrainingAttendanceLine(models.Model):
    _name = 'training.attendance.line'
    _description = 'Training Attendance line'

    attendance_line_id = fields.Many2one('training.attendance', string='', required=False, ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='Another Team', required=False, ondelete='cascade')
    trainee_name = fields.Char('Trainee Name', required=False)
    trainee_code = fields.Char('ID')
    attendance_count = fields.Integer('Days', required=False)
    phone_number = fields.Char('Phone Number',store=True, required=False)


    @api.onchange('trainee_id')
    def trainee_code_change(self):
        self.trainee_code = self.trainee_id.t_id

