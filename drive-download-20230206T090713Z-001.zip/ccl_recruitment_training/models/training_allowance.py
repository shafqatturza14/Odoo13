# -*- coding: utf-8 -*-
from datetime import datetime
from num2words import num2words

from odoo import api, fields, models, _


class TrainingAllowance(models.Model):
    _name = 'training.allowance'
    _description = 'Training Allowance'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    batch_id = fields.Many2one('trainee.details.main', string='Batch No', required=False, ondelete='cascade')
    training_allowance_per_day = fields.Integer(string='Training Allowance Per Day', default=150)
    field_allowance_per_day = fields.Integer(string='Field Allowance Per Day', default=150)

    allowance_list = fields.One2many('allowance.list',
                                     'line_id', string='Allowance List')

    field_visit_allowance_sum = fields.Integer('Field Visit Allowance Sum', compute="_compute_field_allowance_sum",
                                               store=True)
    training_allowance_sum = fields.Integer('Training Allowance Sum', compute="_compute_training_allowance_sum",
                                            store=True)
    total_allowance_sum = fields.Integer('Total Allowance Sum', compute="_compute_total_allowance_sum",
                                         store=True)
    total_allowance_sum_words = fields.Char('Total Words', compute="_compute_total_allowance_sum",
                                            store=True)

    sig_1 = fields.Many2one('hpl.employee', "First Signature")
    sig_2 = fields.Many2one('hpl.employee', "Second Signature")
    sig_3 = fields.Many2one('hpl.employee', "Third Signature")

    sig_1_name = fields.Char("First Signature Name")
    sig_2_name = fields.Char("Second Signature Name")
    sig_3_name = fields.Char("Third Signature Name")

    sig_1_designation = fields.Char("First Signature Designation")
    sig_2_designation = fields.Char("Second Signature Designation")
    sig_3_designation = fields.Char("Third Signature Designation")

    @api.onchange('sig_1', 'sig_2', 'sig_3')
    def full_name_designation(self):
        print("------------------")
        print(self.sig_1)
        if self.sig_1:
            self.sig_1_name = self.sig_1.full_name
            self.sig_1_designation = self.sig_1.position_name

        if self.sig_2:
            self.sig_2_name = self.sig_2.full_name
            self.sig_2_designation = self.sig_2.position_name

        if self.sig_3:
            self.sig_3_name = self.sig_3.full_name
            self.sig_3_designation = self.sig_3.position_name

    @api.onchange('batch_id')
    def trainee_fetch(self):
        sl = 0
        for rec in self:
            training = self.env["training.attendance"].search([("batch_id.batch_no", "=", rec.batch_id.batch_no)])
            field = self.env["field.attendance"].search([("batch_id.batch_no", "=", rec.batch_id.batch_no)])
            lines = [(5, 0, 0)]

            for val, fi in zip(training.trainee_lines, field.trainee_lines):
                sl += 1
                val = {
                    'sl_no': sl,
                    'trainee_id': val.id,
                    'trainee_name': val.trainee_name,
                    'trainee_code': val.trainee_code,
                    'mobile_number': val.phone_number,
                    'training_days': val.attendance_count,
                    'training_allowance': val.attendance_count * rec.training_allowance_per_day,
                    'field_visit_days': fi.attendance_count,
                    'field_visit_allowance': fi.attendance_count * rec.field_allowance_per_day,
                    'total_allowance': (val.attendance_count * rec.training_allowance_per_day) + (
                            fi.attendance_count * rec.field_allowance_per_day),

                }
                lines.append((0, 0, val))
            rec.allowance_list = lines
            print(lines)

    @api.depends('allowance_list.training_allowance')
    def _compute_training_allowance_sum(self):
        sum = 0.0
        for emp in self.allowance_list:
            sum += emp.training_allowance
        self.training_allowance_sum = sum

    @api.depends('allowance_list.field_visit_allowance')
    def _compute_field_allowance_sum(self):
        sum = 0.0
        for emp in self.allowance_list:
            if emp.field_visit_allowance:
                sum += emp.field_visit_allowance

        self.field_visit_allowance_sum = sum

    @api.depends('allowance_list.total_allowance')
    def _compute_total_allowance_sum(self):
        sum = 0.0
        for emp in self.allowance_list:
            if emp.total_allowance:
                sum += emp.total_allowance

        self.total_allowance_sum = sum
        self.total_allowance_sum_words = (num2words(int(sum), to='ordinal')).capitalize()


class AllowanceList(models.Model):
    _name = 'allowance.list'
    _description = 'Allowance List Line'

    line_id = fields.Many2one('training.allowance', string='Allowance', required=False, ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='Another Team', required=False)
    sl_no = fields.Integer('SL NO')
    trainee_name = fields.Char('Trainee Name', required=False)
    trainee_code = fields.Char('ID')
    training_days = fields.Integer('Training Days')
    training_allowance = fields.Integer('Training Allowance', store=True)

    field_visit_days = fields.Integer('Field Visit Days')
    field_visit_allowance = fields.Integer('Field Visit Allowance', store=True, default=0.0)
    total_allowance = fields.Integer('Total Allowance', store=True, )

    mobile_number = fields.Char('Mobile Number', required=False, store=True, default='')
    signature = fields.Char('Signature', required=False, default='')

    @api.onchange('trainee_id')
    def trainee_code_change(self):
        self.trainee_code = self.trainee_id.t_id
