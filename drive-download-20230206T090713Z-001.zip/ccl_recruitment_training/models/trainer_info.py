# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError

class TrainerInfo(models.Model):
    _name = 'trainer.info'
    _description = 'Trainer Details Info'
    _rec_name = 'name'

    employee_id = fields.Many2one('hr.employee', string="Trainer Name")

    name = fields.Char('Trainer Name', required=False, compute='_compute_trainer_name', store=True)

    department_id = fields.Many2one('hr.department', 'Department', readonly=True, compute='_compute_employee_dept')

    employee_code = fields.Char(string='Employee ID', readonly=True, compute='_compute_employee_code')

    job_id = fields.Many2one('hr.job', 'Present Position', readonly=True, compute='_compute_employee_job_position')
    emp_joining_date = fields.Date('Date of Joining', readonly=True, compute='_compute_employee_joining_date')




    @api.onchange('employee_id')
    def _compute_employee_supervisor(self):
        for emp in self:
            if emp.employee_id.parent_id:
                emp.emp_supervisor = emp.employee_id.parent_id

    @api.depends('employee_id')
    def _compute_trainer_name(self):
        for emp in self:
            if emp.employee_id:
                emp.name = emp.employee_id.name



    @api.onchange('employee_id')
    def _compute_employee_code(self):
        for emp in self:
            if emp.employee_id.employee_code:
                emp.employee_code = emp.employee_id.employee_code


    @api.onchange('employee_id')
    def _compute_employee_name(self):
        for emp in self:
            if emp.employee_id:
                emp.name = emp.employee_id.name


    @api.onchange('employee_id')
    def _compute_employee_job_position(self):
        for emp in self:
            if emp.employee_id.job_id:
                emp.job_id = emp.employee_id.job_id.id

    @api.onchange('employee_id')
    def _compute_employee_dept(self):
        for emp in self:
            if emp.employee_id.department_id:
                emp.department_id = emp.employee_id.department_id.id


    @api.onchange('employee_id')
    def _compute_employee_joining_date(self):
        for emp in self:
            if emp.employee_id.emp_joining_date:
                emp.emp_joining_date = emp.employee_id.emp_joining_date

