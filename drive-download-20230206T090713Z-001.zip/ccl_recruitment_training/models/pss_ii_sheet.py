# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class PSSII(models.Model):
    _name = 'pss.ii'
    _description = 'PSS II Sheet'
    _rec_name = 'batch_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    batch_id = fields.Many2one('trainee.details.main', String='Batch', required=True, ondelete='cascade')
    trainees_lines = fields.One2many('pss.ii.trainee.system', 'trainee_track_id', string='Trainee List')
    template_id = fields.Many2one('result.sheet.template', 'Template', ondelete='cascade')

    @api.onchange('template_id')
    def subject_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.template_id.event_lines:
                val = {
                    'subject': line.subject,
                    'allocate_mark': line.allocate_mark,
                }
                lines.append((0, 0, val))
            rec.trainees_lines.subject_lines = lines

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_id': line.id,
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                        'pss_ii_sum': 0.0,
                        'pss_ii_sum_percentage': 0.0,
                    }
                    lines.append((0, 0, val))
            rec.trainees_lines = lines


class PSSIITraineesSystem(models.Model):
    _name = 'pss.ii.trainee.system'
    _description = 'Trainees Lines'

    trainee_track_id = fields.Many2one('pss.ii', ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='Trainee Name')
    trainee_name = fields.Char(string='Name', store=True)
    trainee_code = fields.Char('Trainee ID', store=True)
    subject_lines = fields.One2many('pss.ii.trainee.system.subject', 'subject_id', string='Subject List')

    pss_ii_sum = fields.Float('PSS II Sum', compute="_compute_obtain_mark", store=True)
    pss_ii_sum_percentage = fields.Float('PSS II Percentage', store=True)

    @api.depends('subject_lines')
    def _compute_obtain_mark(self):
        for rec in self:
            sum = 0.0
            cnt = 0
            for line in rec.subject_lines:
                if line.obtain_mark:
                    sum += line.obtain_mark
                    cnt += 1
            avg = 0
            if cnt > 0 and rec.subject_lines:
                avg = sum / float(cnt)
                rec.pss_ii_sum = "{:.2f}".format(avg)
                rec.pss_ii_sum_percentage = "{:.2f}".format((avg / 20.0) * 100.0)
            if avg > 30:
                raise ValidationError(_('Average must be less than 20.0'))

class TraineesSystemSubject(models.Model):
    _name = 'pss.ii.trainee.system.subject'
    _description = 'Trainees Subject Lines'

    subject_id = fields.Many2one('pss.ii.trainee.system', ondelete='cascade')
    subject = fields.Char('Subject')
    allocate_mark = fields.Float('Allocate Mark')
    obtain_mark = fields.Float('Obtain Mark')




