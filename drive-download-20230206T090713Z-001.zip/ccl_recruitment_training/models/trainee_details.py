# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime

from reportlab.platypus.tableofcontents import delta


class TraineeDetails(models.Model):
    _name = 'trainee.details.main'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Trainer Details Info'
    _rec_name = 'batch_no'

    hpl_team = fields.Selection(
        [('RX', 'General Team'),
         ('CRD', 'Credence Team'),
         ('VIS', 'Visionary Team'),
         ], string='Team',
        default='RX')

    batch_list = fields.Many2one('all.batch', 'Batch No')
    batch_no = fields.Integer('Batch', default=0, store=True)
    starting_date = fields.Date('Starting Date', default=datetime.today(), required=True)
    starting_day = fields.Char('Starting Day')
    closing_date = fields.Date('Closing Date', default=datetime.today(), required=True)
    closing_day = fields.Char('Closing Day')
    venue_details = fields.Many2one('venue.details', 'Venue', ondelete='cascade')
    reporting_time = fields.Char('Reporting Time', default="00:00")
    duration = fields.Char('Duration', compute='_compute_duration')

    to_name = fields.Char('To')
    concern = fields.Char('Concern')
    user_id = fields.Many2one('res.users', string='User', default=lambda self: self.env.user, readonly=True)

    details_line = fields.One2many('trainee.details', 'details_id', string='Details Line')

    @api.depends('starting_date', 'closing_date')
    def _compute_duration(self):
        for rec in self:
            duration = (rec.closing_date - rec.starting_date)
            rec.duration = (duration.days) + 1

    @api.onchange('batch_list', 'hpl_team')
    def applicant_fetch(self):
        for rec in self:
            if self.batch_list and self.hpl_team:
                self.batch_no = self.batch_list.batches
                batch_applicants = self.env['hr.applicant'].search([('batches', '=', self.batch_list.id)],
                                                                   order="id asc")
                lines = [(5, 0, 0)]
                rx_team_seq_ex = 201
                rx_team_seq_fr = 101

                crd_team_seq_e = 201
                crd_team_seq_f = 101

                vis_team_seq_e = 201
                vis_team_seq_f = 101

                trainee_code = ''

                for line in batch_applicants:
                    experienced = line.is_experienced
                    if self.hpl_team == 'RX':
                        if experienced:
                            trainee_code = self.hpl_team + "-E" + str(rx_team_seq_ex) \
                                           + "/" + str(self.batch_no)
                            rx_team_seq_ex += 1
                        else:
                            trainee_code = self.hpl_team + "-F" + str(rx_team_seq_fr) \
                                           + "/" + str(self.batch_no)
                            rx_team_seq_fr += 1

                    if self.hpl_team == 'CRD':
                        if experienced:
                            trainee_code = self.hpl_team + "-E" + str(crd_team_seq_e) \
                                           + "/" + str(self.batch_no)
                            crd_team_seq_e += 1
                        else:
                            trainee_code = self.hpl_team + "-F" + str(crd_team_seq_f) \
                                           + "/" + str(self.batch_no)
                            crd_team_seq_f += 1

                    if self.hpl_team == 'VIS':

                        if experienced:
                            trainee_code = self.hpl_team + "-E" + str(vis_team_seq_e) \
                                           + "/" + str(self.batch_no)
                            vis_team_seq_e += 1
                        else:
                            trainee_code = self.hpl_team + "-F" + str(vis_team_seq_f) \
                                           + "/" + str(self.batch_no)
                            vis_team_seq_f += 1

                    val = {
                        'applicant_name': line.id,
                        'name': line.partner_name,
                        't_id': trainee_code,
                        'work_email': line.email_from,
                        'phone_number': line.partner_phone,
                        'nid': line.nid_number,
                        'ssc': line.ssc,
                        'hsc': line.hsc,
                        'grad': line.grad if line.grad else '',
                        'post_grad': line.post_grad if line.post_grad else '',
                        'pe_company': line.company_name if line.company_name else '',
                        'pe_duration': line.experience or '',
                        'home_district': line.home_district or '',
                        'blood_group': line.blood_group_hpl.name or '',
                        'date_of_birth': line.date_of_birth or '',
                        'references': line.references or '',
                        'marital_status': line.marital_status or '',
                        'wife_occupation': line.wife_occupation or '',
                        'village': line.village or '',
                        'post_office': line.post_office or '',
                        'police_station': line.police_station or '',
                        'district': line.district or '',
                        'pe_posting_place': line.pe_posting_place or '',
                        'father': line.father or '',
                        'mother': line.mother or '',
                    }
                    lines.append((0, 0, val))
                rec.details_line = lines


class TraineeDetailsLine(models.Model):
    _name = 'trainee.details'
    _description = 'Trainee Details Line'
    _rec_name = 'name'

    details_id = fields.Many2one('trainee.details.main', string='Line Item', ondelete='cascade')
    t_id = fields.Char(string="Trainee ID", required=False, store=True, default='New')
    applicant_name = fields.Many2one('hr.applicant', string='Application Name', required=True, ondelete='cascade')
    name = fields.Char('Trainee Name', required=False, store=True)
    work_email = fields.Char(string='Work Email', store=True)
    phone_number = fields.Char(string='Phone Number')
    trainee_image = fields.Image(string='Trainee Image')

    father_name = fields.Char(string="Father Name", default='')
    mother_name = fields.Char(string="Mother Name", default='')

    village = fields.Char(string='Village')
    post_office = fields.Char(string='Post Office')
    police_station = fields.Char(string='Post Station')
    district = fields.Char(string='District')

    # Qualification
    nid = fields.Char(string='NID')
    ssc = fields.Char('SSC')
    hsc = fields.Char('HSC')
    grad = fields.Char('BA(Pass)')
    post_grad = fields.Char('MSC')

    home_district = fields.Char('Home District')
    pe_company = fields.Char('Company')
    pe_duration = fields.Char('Duration')
    pe_posting_place = fields.Char('Previous Posting Place')
    gender = fields.Selection(
        [('male', 'Male'),
         ('female', 'Female'),
         ('other', 'Other'),
         ], string='Gender',
        default='male')
    blood_group = fields.Char('Blood Group')
    date_of_birth = fields.Date(string='Date of Birth')
    references = fields.Char('References')
    pr_posting_place = fields.Char('Probable Posting place')
    joining_date = fields.Date('Joining Date')
    marital_status = fields.Char('Marital Status')
    wife_occupation = fields.Char('Wife Occupation', default='')
    venue = fields.Char('Venue Details', default='')
    status = fields.Selection(
        [('running', 'Running'),
         ('selected', 'Selected'),
         ('joined', 'Joined'),
         ('not_selected', 'Not Joined'),
         ('resign', 'Resign'),
         ('absent', 'Absent'),
         ], string='State',
        default='running')
    remarks = fields.Char('Remarks')

    offer_letter_template = fields.Text('Offer Letter')
    signee = fields.Char('Offer Letter Signature')
    signee_position = fields.Char('Offer Letter Signature')
    father = fields.Char('Father')
    mother = fields.Char('Mother')
    last_name = fields.Char('Last Name', compute='_compute_trainee_last_name')

    @api.depends('name')
    def _compute_trainee_last_name(self):
        split_str = (self.name).split(' ')
        self.last_name = split_str[-1]

    @api.onchange('applicant_name')
    def trainer_code_creation(self):
        for rec in self:
            # exp_trainee = self.env['trainee.details'].search_count(
            #     [('applicant_name.is_experienced', '=',  True), ('details_id.batch_no', '=', str(rec.details_id.batch_no))])
            #
            # non_exp_trainee = self.env['trainee.details'].search_count(
            #     [('applicant_name.is_experienced', '!=',  True), ('details_id.batch_no', '=', str(rec.details_id.batch_no))])

            exp_trainee_list = []
            exp_trainee = 0
            non_exp_trainee_list = []
            non_exp_trainee = 0
            exp_str = ''
            non_exp_str = ''
            for line in rec.details_id.details_line:
                if line.applicant_name.is_experienced:
                    exp_trainee_list.append(line.t_id)
                elif not line.applicant_name.is_experienced:
                    non_exp_trainee_list.append(line.t_id)

            print(exp_trainee_list)
            if len(exp_trainee_list) > 2 and exp_trainee_list[-1] == exp_trainee_list[-2]:
                exp_str = exp_trainee_list[-3]
            elif len(exp_trainee_list) > 0 and exp_trainee_list[-1] == 'New':
                print(exp_trainee_list[-1])
                exp_str = exp_trainee_list[-2]
            elif len(exp_trainee_list) > 0:
                exp_str = exp_trainee_list[-1]

            if len(non_exp_trainee_list) > 2 and non_exp_trainee_list[-1] == non_exp_trainee_list[-2]:
                non_exp_str = non_exp_trainee_list[-3]
            elif len(non_exp_trainee_list) > 0 and non_exp_trainee_list[-1] == 'New':
                non_exp_str = non_exp_trainee_list[-2]
            else:
                non_exp_str = non_exp_trainee_list[-1]
            print(non_exp_trainee_list)

            # exp_trainee_tmp = self.env['trainee.details'].search_count([('id', '=', exp_trainee_list[-1])])
            # non_exp_trainee_tmp = self.env['trainee.details'].search_count([('id', '=', non_exp_trainee_list[-1])])
            #
            if exp_str:
                exp_slash_index = exp_str.rfind('/')
                exp_trainee = int(exp_str[exp_slash_index - 3:exp_slash_index])
            if non_exp_str:
                print(non_exp_str)
                non_exp_slash_index = non_exp_str.rfind('/')
                non_exp_trainee = int(non_exp_str[non_exp_slash_index-3:non_exp_slash_index])
                print("non exp trainee sum", non_exp_trainee)

            if rec.applicant_name.is_experienced:
                rec.t_id = rec.details_id.hpl_team + '-E' + str(exp_trainee + 1) + "/" + str(rec.details_id.batch_no)
            else:
                rec.t_id = rec.details_id.hpl_team + '-F' + str(non_exp_trainee + 1) + "/" + str(
                    rec.details_id.batch_no)

            self.name = self.applicant_name.partner_name
            self.work_email = self.applicant_name.email_cc
            self.phone_number = self.applicant_name.partner_phone
            self.nid = self.applicant_name.nid_number
            self.ssc = self.applicant_name.ssc
            self.hsc = self.applicant_name.hsc
            self.grad = self.applicant_name.grad if self.applicant_name.grad else ''
            self.post_grad = self.applicant_name.post_grad if self.applicant_name.post_grad else ''
            self.pe_company = self.applicant_name.company_name if self.applicant_name.company_name else ''
            self.pe_duration = self.applicant_name.is_experienced or ''
            self.home_district = self.applicant_name.home_district or ''
            self.date_of_birth = self.applicant_name.date_of_birth or ''
            self.references = self.applicant_name.references or ''
            self.wife_occupation = self.applicant_name.wife_occupation or ''
            self.village = self.applicant_name.village or ''
            self.post_office = self.applicant_name.post_office or ''
            self.police_station = self.applicant_name.police_station or ''
            self.district = self.applicant_name.district or ''
