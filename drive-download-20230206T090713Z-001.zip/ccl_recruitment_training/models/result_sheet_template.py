
from odoo import api, fields, models, _

class ResultSheetTemplate(models.Model):
    _name = 'result.sheet.template'
    _description = "Result Sheet Template"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']


    name = fields.Char('Result Sheet Template Name', required=True, store=True)
    event_lines = fields.One2many('result.sheet.template.line', 'event_line_id', string="Template Line")


class ResultSheetTemplateLines(models.Model):
    _name = 'result.sheet.template.line'
    _description = "Result Sheet Template Line"

    event_line_id = fields.Many2one('result.sheet.template', ondelete='cascade')

    subject = fields.Char('Subject')
    allocate_mark = fields.Float('Allocate Mark')
