# -*- coding: utf-8 -*-

from odoo import fields, models, api, _


class VenueDetails(models.Model):
    _name = 'venue.details'
    _description = 'Venue Details Info'
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Text('Venue Address')
