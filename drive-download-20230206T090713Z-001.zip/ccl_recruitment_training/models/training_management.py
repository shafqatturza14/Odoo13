# -*- coding: utf-8 -*-

from odoo import fields, models, api, _


class TrainingManagement(models.Model):
    _name = 'training.management'
    _description = 'Training Management'
    _rec_name = 'name'

    @api.model
    def create(self, vals):
        if vals.get('tr_id', 'New') == 'New':
            vals['tr_id'] = self.env['ir.sequence'].next_by_code('training.management.sequence')
            print('vals-----', vals['tr_id'])

        res = super(TrainingManagement, self).create(vals)
        return res

    tr_id = fields.Char(string="Training ID", required=False, readonly=True, copy=False, index=True,
                       default=lambda self: _('New'))

    name = fields.Char(string='Training Name')
    trainer_id = fields.Many2one( 'trainer.info', string='Trainer Name')
    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')
    venue = fields.Char(string='Venue')
    mio_batch_no = fields.Many2one('mio.batch', string='MIO Batch No')
    status = fields.Selection(
        [('not_started', 'Not Started'),
         ('running', 'Running'),
         ('close', 'Close'),
         ], string='Status',
        default='not_started')
