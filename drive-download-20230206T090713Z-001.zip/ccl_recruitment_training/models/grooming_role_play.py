# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class GroomingRoleSheet(models.Model):
    _name = 'grooming.role.sheet'
    _description = 'Grooming Role Play Sheet'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'batch_id'

    batch_id = fields.Many2one('trainee.details.main', String='Batch NO', required=True, ondelete='cascade')
    trainees_lines = fields.One2many('grooming.role.play.list', 'trainee_track_id', string='Trainee List')
    template_id = fields.Many2one('result.sheet.template', 'Template', store=True, ondelete='cascade')

    @api.onchange('template_id')
    def subject_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.template_id.event_lines:
                val = {
                    'subject': line.subject,
                    'allocate_mark': line.allocate_mark,

                }
                lines.append((0, 0, val))
            rec.trainees_lines.subject_lines = lines

    @api.onchange('batch_id')
    def trainee_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.batch_id.details_line:
                if line.status == 'running':
                    val = {
                        'trainee_id': line.id,
                        'trainee_name': line.name,
                        'trainee_code': line.t_id,
                        'role_sum': 0.0,
                        'role_sum_percentage': 0.0,
                    }
                    lines.append((0, 0, val))
            rec.trainees_lines = lines


class GroomingRolePlayList(models.Model):
    _name = 'grooming.role.play.list'
    _description = 'Grooming Role Play List'

    trainee_track_id = fields.Many2one('grooming.role.sheet', ondelete='cascade')
    trainee_id = fields.Many2one('trainee.details', string='Trainee Name')
    trainee_name = fields.Char(string='Name', store=True)
    trainee_code = fields.Char('Trainee ID', store=True)

    subject_lines = fields.One2many('role.play.subject', 'subject_id', string='Subject List')

    role_sum = fields.Float('Role AVG', store=True, compute='_compute_role_mark')
    role_sum_percentage = fields.Float('Role (%)', store=True, compute='_compute_role_mark')

    grooming_sum = fields.Float('Grooming AVG', store=True)
    grooming_sum_percentage = fields.Float('Grooming (%)', store=True)



    @api.onchange('template_id')
    def subject_fetch(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.template_id.event_lines:
                val = {
                    'subject': line.subject,

                }
                lines.append((0, 0, val))
            rec.subject_lines = lines

    @api.onchange('subject_lines')
    def _compute_obtain_mark(self):
        for rec in self:
            sum = 0.0
            cnt = 0
            for line in rec.subject_lines:
                if line.grooming_mark:
                    sum += line.grooming_mark
                    cnt += 1
            avg = 0
            if cnt > 0 and rec.subject_lines:
                avg = sum / float(cnt)
                rec.grooming_sum = "{:.2f}".format(avg)
                rec.grooming_sum_percentage = "{:.2f}".format((avg / 5.0) * 100.0)
            if avg > 5.00:
                raise ValidationError(_('Average must be less than 5.0'))

    @api.depends('subject_lines')
    def _compute_role_mark(self):
        for rec in self:
            sum_role = 0.0
            cnt_role = 0
            for line in rec.subject_lines:
                if line.role_play_mark:
                    sum_role += line.role_play_mark
                    cnt_role += 1

            avg_role = 0
            if cnt_role > 0 and rec.subject_lines:
                avg_role = sum_role / float(cnt_role)
                rec.role_sum = "{:.2f}".format(avg_role)
                rec.role_sum_percentage = "{:.2f}".format((avg_role / 5.0) * 100.0)
            if avg_role > 5.00:
                raise ValidationError(_('Average must be less than 5.0'))


class RolePlaySheetSubject(models.Model):
    _name = 'role.play.subject'
    _description = 'Role Play Subject'

    subject_id = fields.Many2one('grooming.role.play.list', ondelete='cascade')
    subject = fields.Char('Subject')
    allocate_mark = fields.Float('Allocate Mark')
    grooming_mark = fields.Float('Grooming Mark')
    role_play_mark = fields.Float('Role Play Mark')





