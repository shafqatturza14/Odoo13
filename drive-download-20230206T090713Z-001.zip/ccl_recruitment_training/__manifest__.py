# -*- coding: utf-8 -*-

{
    'name': "Training",

    'summary': 'Recruitment Training Module for Trainee',

    'description': """
        Trainee Module for Trainee
    """,

    'author': "Mim Jannat Talukder",
    'website': "",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'report_xlsx','hr_recruitment'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'wizard/mio_email_name.xml',
        'wizard/training_offer_letter.xml',
        'wizard/training_schedule_mail.xml',
        'views/menu.xml',
        'views/templates.xml',
        'views/all_batch.xml',
        'views/trainee_details.xml',
        'views/trainer_info.xml',
        'views/training_management.xml',
        'views/training_schedule.xml',
        'views/mio_batch.xml',
        'views/trainee_evaluation.xml',
        'views/trainee_certificate_collection.xml',
        'views/field_visit_list.xml',
        'views/training_logistics_tracker.xml',
        'views/field_logistics_tracker.xml',
        'views/briefcase_tracker.xml',
        'views/role_play.xml',
        'views/training_allowance.xml',
        'views/system_pss_sheet.xml',
        'views/products.xml',
        'views/grooming_role_play.xml',
        'views/logistic_items.xml',
        'views/assignment.xml',
        'views/venue.xml',
        'views/event_template.xml',
        'views/training_attendance.xml',
        'views/field_visit_attendance.xml',
        'views/result_sheet_template_line.xml',
        'views/pss_ii_sheet.xml',
        'views/grooming_sheet.xml',
        'views/final_result_sheet.xml',
        'reports/training_schedule_details.xml',
        'reports/trainee_evaluation_report.xml',
        'reports/field_visit_list_report.xml',
        'reports/trainee_certificate_collection.xml',
        'reports/role_play.xml',
        'reports/training_allowance_report.xml',
        'reports/briefcase_tracker_report.xml',
        'reports/training_logistic_tracker_report.xml',
        'reports/field_logistic_tracker.xml',
        'reports/weekly_evaluation_report.xml',
        'reports/final_result_sheet_details.xml',
        'reports/mio_profile.xml',
        'reports/training_offer_letter_report.xml',
        'reports/trainee_attendance_report.xml',
        'reports/trainee_mio_list_id_card_format.xml',
        'reports/system_sheet.xml',
        'reports/pss_II.xml',
        'reports/products_sheet_report.xml',
        'reports/assignment_report_sheet.xml',
        'reports/weekly_evaluation_result_report.xml',
        'reports/grooming_role_play_sheet.xml',
        'wizard/final_result_sheet.xml',
        'wizard/weekly_evaluation_report.xml',
        'data/sequence.xml',
        'data/mail_template.xml'

    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
