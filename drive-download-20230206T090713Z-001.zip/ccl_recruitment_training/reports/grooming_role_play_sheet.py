from odoo import models


class SystemSheetReport(models.AbstractModel):
    _name = 'report.ccl_recruitment_training.grooming_role_sheet_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('System Sheet Result Report')
        format_heading = workbook.add_format({'font_name': 'cambria','font_size': 10, 'align': 'center','valign':'vcenter', 'bold': True, 'border': True, 'text_wrap': True})
        format_heading_name = workbook.add_format({'font_name': 'cambria','font_size': 10, 'align': 'left','valign':'vcenter', 'border': True, 'text_wrap': True})
        format_signature_1 = workbook.add_format({'font_name': 'cambria','font_size': 10, 'align': 'left', 'valign':'vcenter', 'bold': True, 'text_wrap': True})
        format_signature_2 = workbook.add_format({'font_name': 'cambria','font_size': 10, 'align': 'right', 'valign':'vcenter', 'bold': True})
        format_heading_item = workbook.add_format({'font_name': 'cambria','font_size': 10, 'align': 'center','valign':'vcenter', 'bold': True, 'border': True, 'text_wrap': True})
        format_body = workbook.add_format({'font_name': 'cambria','font_size': 10, 'align': 'center','valign':'vcenter', 'border': True})

        bold = workbook.add_format(
            {'font_name': 'cambria', 'font_size': 15, 'bold': True, 'align': 'center','valign':'vcenter'})

        sheet.set_column(1, 1, 16)
        sheet.set_column(0, 0, 4)
        sheet.set_column(2, 2, 17)
        sheet.merge_range('A1:Q2', 'Healthcare Pharmaceuticals Ltd.', bold)
        sheet.merge_range('A5:A7', "SI", format_heading)
        sheet.merge_range('B5:B7', "Trainee Name", format_heading)
        sheet.merge_range('C5:C7', "Trainee ID", format_heading)
        row_start = 6
        serial_number = 1

        col = 3
        for index, line in enumerate(lines):
            sheet.merge_range('A3:Q4', "Result Sheet_Role Play & Grooming#" + str(line.batch_id.hpl_team)+"-" + str(line.batch_id.batch_no), format_heading)
            for ind, item in enumerate(line.trainees_lines):
                for ind, item in enumerate(item.subject_lines):
                    sheet.write(6, col, "Grooming", format_heading_item)
                    sheet.write(6, col+1, "Role Play", format_heading_item)
                    sheet.merge_range(5, col, 5, col + 1, item.subject, format_heading)
                    col += 2
                sheet.set_column(3, col - 1, 9)
                break
            break
        sheet.set_column(col, col+1, 9)
        sheet.merge_range(4, 3, 4, col - 1, "OUT   OF   10 (Grooming: 05; Role Play: 05)", format_heading)
        sheet.merge_range(4, col, 6, col, 'Avg.', format_heading)
        sheet.merge_range(4, col+1, 6, col+1, 'Avg.(%).', format_heading)

        row = 0
        for index, line in enumerate(lines):
            row = row_start + 1
            for ind, item in enumerate(line.trainees_lines):
                sheet.write(row, 0, serial_number, format_body)
                sheet.write(row, 1, item.trainee_name, format_heading_name)
                sheet.write(row, 2, item.trainee_code, format_body)
                col = 3
                for ind, item_lines in enumerate(item.subject_lines):
                    
                    sheet.write(row, col, item_lines.grooming_mark if item_lines.grooming_mark > 0 else '', format_body)
                    sheet.write(row, col+1, item_lines.role_play_mark if item_lines.role_play_mark > 0 else '', format_body)
                    col += 2
                sheet.write(row, col, "{:.2f}".format(item.role_sum) if item.role_sum else ".", format_body)
                sheet.write(row, col+1, "{:.2f}".format(item.role_sum_percentage) if item.role_sum_percentage else '', format_body)
                col += 2
                serial_number += 1
                row += 1

            # sheet.merge_range(row + 1, 0, row + 3, 3, '----------------------------------------------',
            #                   format_signature_1)
            # sheet.merge_range(row + 4, 0, row + 4, 3, line.sig_1.full_name, format_signature_1)
            # sheet.merge_range(row + 5, 0, row + 5, 3, line.sig_1.position_name, format_signature_1)
            # sheet.merge_range(row + 1, col - 4, row + 3, col, '----------------------------------------------',
            #                   format_signature_2)
            # sheet.merge_range(row + 4, col - 4, row + 4, col, line.sig_1.full_name, format_signature_2)
            # sheet.merge_range(row + 5, col - 4, row + 5, col, line.sig_1.position_name, format_signature_2)
