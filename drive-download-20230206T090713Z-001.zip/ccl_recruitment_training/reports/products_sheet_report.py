from odoo import models


class SystemSheetReport(models.AbstractModel):
    _name = 'report.ccl_recruitment_training.products_sheet_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('System Sheet Result Report')
        format_heading = workbook.add_format({ 'font_name':'cambria', 'font_size': 10, 'align': 'center', 'valign':'vcenter', 'bold': True, 'border': True, 'text_wrap': True})
        format_signature_1 = workbook.add_format({'font_size': 10,  'font_name':'cambria', 'align': 'left', 'valign':'vcenter', 'bold': True, 'text_wrap': True})
        format_signature_2 = workbook.add_format({'font_size': 10, 'align': 'right', 'font_name':'cambria',  'valign':'vcenter', 'bold': True})
        format_heading_item = workbook.add_format({'font_size': 10, 'align': 'center', 'valign':'vcenter',  'font_name':'cambria',  'bold': True, 'border': True, 'text_wrap': True})
        format_body = workbook.add_format({'font_size': 10, 'align': 'center', 'valign':'vcenter',  'border': True, 'font_name':'cambria'})
        format_body_name = workbook.add_format({'font_size': 10, 'align': 'left', 'valign':'vcenter',  'border': True, 'font_name':'cambria', })

        bold = workbook.add_format(
            {'font_size': 15, 'bold': True, 'valign':'vcenter', 'align': 'center'})
        title = workbook.add_format(
            {'bold': True, 'align': 'center', 'valign': 'center', 'font_size': 18, 'bg_color': '#f2eee4'})

        sheet.set_column(1, 1, 16)
        sheet.set_column(0, 0, 4)
        sheet.set_column(2, 2, 17)
        sheet.merge_range('A1:S2', 'Healthcare Pharmaceuticals Ltd.', bold)
        sheet.merge_range('A5:A6', "SI", format_heading)
        sheet.merge_range('B5:B6', "Trainee Name", format_heading)
        sheet.merge_range('C5:C6', "Trainee ID", format_heading)
        row_start = 5
        serial_number = 1

        col = 3
        sheet.set_row(5,40)
        for index, line in enumerate(lines):
            sheet.merge_range('A3:S4', "Result Sheet_Products# " + str(line.batch_id.hpl_team)+"-" + str(line.batch_id.batch_no), format_heading)
            for ind, item in enumerate(line.trainees_lines):
                for ind, item in enumerate(item.subject_lines):
                    sheet.write(5, col, item.subject, format_heading_item)
                    col = col + 1
                sheet.set_column(3, col - 1, 9)
                break
            break
        sheet.set_column(col, col+1, 9)
        sheet.merge_range(4, 3, 4, col - 1, "OUT          OF       20", format_heading)
        sheet.merge_range(4, col, 5, col, 'Product Avg.', format_heading)
        sheet.merge_range(4, col+1, 5, col+1, 'Product Avg.(%)', format_heading)

        row = 0
        for index, line in enumerate(lines):
            row = row_start + 1
            for ind, item in enumerate(line.trainees_lines):
                sheet.set_row(row, 40)
                sheet.write(row, 0, serial_number, format_body)
                sheet.write(row, 1, item.trainee_name, format_body_name)
                sheet.write(row, 2, item.trainee_code, format_body)
                col = 3
                for ind, item_lines in enumerate(item.subject_lines):
                    sheet.set_row(row, 20)
                    sheet.write(row, col, item_lines.obtain_mark, format_body)
                    col += 1
                sheet.write(row, col, "{:.2f}".format(item.product_sum), format_body)
                sheet.write(row, col+1, "{:.2f}".format(item.product_sum_percentage), format_body)
                col += 2
                serial_number += 1
                row += 1

            # sheet.merge_range(row + 1, 0, row + 3, 3, '----------------------------------------------',
            #                   format_signature_1)
            # sheet.merge_range(row + 4, 0, row + 4, 3, line.sig_1.full_name, format_signature_1)
            # sheet.merge_range(row + 5, 0, row + 5, 3, line.sig_1.position_name, format_signature_1)
            # sheet.merge_range(row + 1, col - 4, row + 3, col, '----------------------------------------------',
            #                   format_signature_2)
            # sheet.merge_range(row + 4, col - 4, row + 4, col, line.sig_1.full_name, format_signature_2)
            # sheet.merge_range(row + 5, col - 4, row + 5, col, line.sig_1.position_name, format_signature_2)
