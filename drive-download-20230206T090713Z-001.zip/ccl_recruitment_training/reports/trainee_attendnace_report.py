from odoo import models


class TraineeAttendanceReport(models.AbstractModel):
    _name = 'report.ccl_recruitment_training.trainee_attendance_report_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('Trainee Attendance Report Excel')
        format_heading = workbook.add_format({'valign': 'vcenter', 'font_size': 10, 'align': 'center', 'bold': True, 'border': True, 'font_name':'cambria'})
        format_heading_rotate = workbook.add_format({'font_size': 10,'valign': 'vcenter', 'align': 'center', 'bold': True,
                                                     'border': True, 'rotation': '90', 'text_wrap': True,'font_name':'cambria','bg_color':'#d9d1d1'})

        format_body = workbook.add_format({'font_size': 10,'valign': 'vcenter', 'align': 'center', 'border': True, 'font_name':'cambria'})
        format_body_name = workbook.add_format({'font_size': 10,'valign': 'vcenter', 'align': 'left', 'border': True, 'font_name':'cambria'})


        bold = workbook.add_format(
            {'font_size': 15, 'bold': True, 'align': 'center','valign': 'vcenter', 'border': True, 'font_name':'cambria'})

        sheet.set_column(1, 2, 20)
        sheet.merge_range('A1:AP2', 'Healthcare Pharmaceuticals Ltd.', bold)

        row_start = 4
        serial_number = 1
        sheet.set_row(4, 40)
        col = 3

        sheet.write(4, 0, 'SI', format_heading)
        sheet.write(4, 1, 'Trainee Name', format_heading)
        sheet.write(4, 2, 'Trainee ID', format_heading)

        for index, line in enumerate(lines):
            row = row_start + 1
            for ind, item in enumerate(line.mio_batch.details_line):
                sheet.set_row(row, 40)
                if item.status == 'running':
                    sheet.write(row, 0, serial_number, format_body)
                    sheet.write(row, 1, item.name, format_body_name)
                    sheet.write(row, 2, item.t_id, format_body)
                    serial_number += 1
                    row += 1

        for index, line in enumerate(lines):
            sheet.merge_range('A3:AP4', "Trainee Attendance Report_Batch # " + str(line.mio_batch.hpl_team)+"-" + str(line.mio_batch.batch_no), format_heading)
            for ind, item in enumerate(line.schedule_date_lines):
                if item.schedule_type == 'weekday':
                    sheet.write(4, col,(item.schedule_date).strftime('%d.%m'), format_heading)
                    sheet.set_column(col, col, 15)
                    col = col + 1
                elif item.schedule_type == 'holiday':
                    sheet.write(4, col, (item.schedule_date).strftime('%d.%m'), format_heading_rotate)
                    sheet.merge_range(5,col,serial_number+3,col,item.holiday_name, format_heading_rotate)
                    # sheet.write(6, item.holiday_name, format_heading_rotate)
                    # sheet.merge_range(6, col, 20, col, item.holiday_name, format_heading_rotate)
                    sheet.set_column(col, col, 3)
                    col = col + 1
                else:
                    sheet.write(4, col, (item.schedule_date).strftime('%d.%m'), format_heading)
                    sheet.set_column(col, col, 15)
                    col = col + 1

            break

