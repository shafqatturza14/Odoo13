import base64
import io

from PIL import Image
from odoo import models


class MIOProfileReport(models.AbstractModel):
    _name = 'report.ccl_recruitment_training.mio_profile_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('MIO Profile Report')
        format_heading = workbook.add_format({'text_wrap': True,'border':True, 'font_size': 10, 'valign':'vcenter', 'align': 'center','bold': True, 'font_name':'cambria'})
        format_body = workbook.add_format({'text_wrap': True, 'font_size': 10, 'valign':'vcenter','align': 'center', 'border':True, 'font_name':'cambria'})
        format_body_result = workbook.add_format({'text_wrap': True, 'font_size': 10, 'valign':'vcenter', 'align': 'center', 'border':True, 'rotation': '90','font_name':'cambria'})

        bold = workbook.add_format(
            {'font_size': 12, 'align': 'center', 'valign':'vcenter','font_name':'cambria'})

        bold_title = workbook.add_format(
            {'font_size': 15, 'bold': True, 'align': 'center', 'valign':'vcenter','font_name':'cambria'})



        sheet.set_column(0, 0, 3)
        sheet.set_column(1, 2, 13)
        sheet.set_column(3, 3, 15)
        sheet.set_column(4, 7, 4)
        sheet.set_column(8, 10, 18)
        sheet.set_column(11, 20, 12)
        sheet.set_row(7,1)
        # sheet.merge_range('A1:T3', "Personal Profile", bold)
        sheet.merge_range('A5:A7', "SI", format_heading)
        sheet.merge_range('B5:B7', "Trainee ID", format_heading)
        sheet.merge_range('C5:C7', "Photograph", format_heading)
        sheet.merge_range('D5:D7', "Trainee Name", format_heading)
        sheet.merge_range('E5:H7', "Qualification", format_heading)
        sheet.merge_range('I5:I7', "Home District", format_heading)
        sheet.merge_range('J5:K5', "Previous Experience", format_heading)
        sheet.merge_range('J6:J7', "Company", format_heading)
        sheet.merge_range('K6:K7', "Duration", format_heading)
        sheet.merge_range('L5:L7', "Previous Posting Place", format_heading)
        # sheet.merge_range('M5:M7', "Blood Group", format_heading)
        # sheet.merge_range('N5:N7', "Date of Birth", format_heading)
        sheet.merge_range('M5:M7', "Mobile No", format_heading)
        sheet.merge_range('N5:N7', "References", format_heading)
        sheet.merge_range('O5:O7', "Probable Posting Place", format_heading)
        sheet.merge_range('P5:P7', "Joining Date", format_heading)
        sheet.merge_range('Q5:Q7', "Marital Status", format_heading)
        sheet.merge_range('R5:R7', "Wife Occupation", format_heading)
        sheet.merge_range('S5:S7', "Category", format_heading)
        row_start = 7
        serial_number = 1
        row = row_start
        col = 3
        for index, line in enumerate(lines):
            sheet.merge_range('A1:T2', "Healthcare Pharmaceuticals Ltd.", bold_title)
            sheet.merge_range('A3:T4', "Personal Profile, " +str(line.hpl_team) + '-' +str(line.batch_no), bold)
            for ind, item in enumerate(line.details_line):
                emp = self.env['certificate.list'].search([('trainee_code', '=', item.t_id)])
                result = self.env['result.list'].search([('trainee_code', '=', item.t_id)])
                ssc, hsc, hons, masters = '','','',''
                for val in emp:
                    ssc = val.ssc
                    hsc = val.hsc
                    hons = val.hons
                    masters = val.masters

                sheet.set_row(row, 69.8)
                if item.status == 'selected':
                    sheet.write(row, 0, serial_number, format_body)
                    sheet.write(row, 1, item.t_id, format_body)
                    if item.trainee_image:
                        imgdata = io.BytesIO(base64.b64decode(item.trainee_image))
                        sheet.insert_image(row, 2, "image.png", {'image_data': imgdata, 'x_scale': 0.15, 'y_scale': 0.15})
                    sheet.write(row, 3, item.applicant_name.partner_name if item.applicant_name.partner_name else '', format_body)
                    sheet.write(row, 4, ssc if ssc else '', format_body_result)
                    sheet.write(row, 5, hsc if hsc else '', format_body_result)
                    sheet.write(row, 6, hons if hons else '', format_body_result)
                    sheet.write(row, 7, masters if masters else '', format_body_result)
                    sheet.write(row, 8, item.applicant_name.district if item.applicant_name.district else '', format_body)
                    sheet.write(row, 9, item.applicant_name.company_name if item.applicant_name.company_name else '', format_body)
                    sheet.write(row, 10, item.applicant_name.experience if item.applicant_name.experience else '', format_body)
                    sheet.write(row, 11, item.applicant_name.pe_posting_place if item.pe_posting_place else '', format_body)
                    # sheet.write(row, 12, item.applicant_name.blood_group_hpl.name if item.applicant_name.blood_group_hpl.name else '', format_body)
                    # sheet.write(row, 13, str(item.applicant_name.date_of_birth) if item.date_of_birth else '', format_body)
                    sheet.write(row, 12, item.phone_number if item.phone_number else '', format_body)
                    sheet.write(row, 13, item.applicant_name.references if item.applicant_name.references else '', format_body)
                    sheet.write(row, 14, item.pr_posting_place if item.pr_posting_place else '', format_body)
                    sheet.write(row, 15, str(item.joining_date) if item.joining_date else '', format_body)
                    sheet.write(row, 16, item.applicant_name.marital_status.name if item.applicant_name.marital_status else '', format_body)
                    sheet.write(row, 17, item.applicant_name.wife_occupation if item.applicant_name.wife_occupation else '', format_body)
                    sheet.write(row, 18, result.category if result.category else '', format_body)
                    row += 1
                    serial_number += 1


