from odoo import models


class WeeklyEvaluationReport(models.AbstractModel):
    _name = 'report.ccl_recruitment_training.weekly_evaluation_report_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('Weekly Evaluation Report Excel')
        format_heading = workbook.add_format({'font_size': 10, 'align': 'left','border':True, 'bold': True})
        format_heading.set_text_wrap()
        format_body = workbook.add_format({'font_size': 10, 'align': 'left', 'border':True})
        empty_line = workbook.add_format({'font_size': 10, 'align': 'left'})

        bold = workbook.add_format(
            {'font_size': 15, 'align': 'center', 'valign': 'center'})

        sheet.set_column(1, 2, 30)
        sheet.set_column(3, 15, 10)

        sheet.merge_range('A1:N1', '', bold)
        sheet.merge_range('A2:N2', '', bold)
        sheet.merge_range('A3:I3', "Weekly Evaluation Report", bold)
        sheet.merge_range('A1:N2', "", bold)
        sheet.merge_range('A6:A8', "SI", format_heading)
        sheet.merge_range('B6:B8', "Trainee Name", format_heading)
        sheet.merge_range('C6:C8', "Trainee ID", format_heading)
        row_start = 5
        serial_number = 1

        col = 3
        for index, line in enumerate(lines):
            sheet.merge_range('A4:I4', "Weekly Evaluation Report_Batch # " + str(line.batch_id.batch_no), bold)
            for ind, item in enumerate(line.trainees_lines):
                print("===============Item=================")
                print(item)

                for ind, line in enumerate(item.subject_lines):
                    sheet.merge_range(5, col, 7, col, line.subject, format_heading)
                    col = col + 1
                sheet.merge_range(5, col, 7, col, 'Avg', format_heading)
                col += 1
                sheet.merge_range(5, col, 7, col, '', empty_line)
                col += 1
                for ind, line in enumerate(item.product_lines):
                    sheet.merge_range(5, col, 7, col, line.subject, format_heading)
                    col = col + 1
                sheet.merge_range(5, col, 7, col, 'Avg', format_heading)
                col += 1
                sheet.merge_range(5, col, 7, col, '', empty_line)
                col += 1
                for ind, line in enumerate(item.role_lines):
                    sheet.merge_range(5, col, 7, col, line.subject, format_heading)
                    col = col + 1
                sheet.merge_range(5, col, 7, col, 'Avg', format_heading)
                col += 1
                sheet.merge_range(5, col, 7, col, ' ', empty_line)
                col += 1
                for ind, line in enumerate(item.pssii_lines):
                    sheet.merge_range(5, col, 7, col, line.subject, format_heading)
                    col = col + 1
                sheet.merge_range(5, col, 7, col, 'Avg', format_heading)
                col += 1
                sheet.merge_range(5, col, 7, col, '', empty_line)
                col += 1
                break
            break

        for index, line in enumerate(lines):
            row = row_start + 1
            for ind, item in enumerate(line.trainees_lines):
                sheet.write(row, 0, serial_number, format_body)
                sheet.write(row, 1, item.trainee_name, format_body)
                sheet.write(row, 2, item.trainee_code, format_body)
                col = 3
                for ind, item_lines in enumerate(item.subject_lines):
                    sheet.write(row, col, item_lines.obtain_mark, format_body)
                    col += 1
                sheet.write(row, col, item.system_sum, format_body)
                col = col + 1
                sheet.merge_range(row_start, col, row, col, '', empty_line)
                col += 1

                for ind, item_lines in enumerate(item.product_lines):
                    sheet.write(row, col, item_lines.obtain_mark, format_body)
                    col = col + 1
                sheet.merge_range(row, col, row, col, item.product_sum, format_heading)
                col += 1
                sheet.merge_range(row_start, col, row, col, '', empty_line)
                col += 1

                for ind, item_lines in enumerate(item.role_lines):
                    sheet.write(row, col, item_lines.obtain_mark, format_body)
                    col = col + 1
                sheet.merge_range(row, col, row, col, item.role_sum, format_heading)
                col += 1
                sheet.merge_range(row_start, col, row, col, '', empty_line)
                col += 1

                for ind, item_lines in enumerate(item.pssii_lines):
                    sheet.write(row, col, item_lines.obtain_mark, format_body)
                    col = col + 1
                sheet.write(row, col, item.pss_sum, format_body)
                col = col + 1
                sheet.merge_range(row_start, col, row, col, '', empty_line)
                col += 1
                serial_number += 1
                row += 1
