# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from datetime import date
from . import strings


class TrainingOfferLetterWizard(models.TransientModel):
    _name = 'training.offer.wizard'

    offer_letter_template = fields.Text(string='Letter')
    signee = fields.Many2one('hpl.employee', string='Signee')

    @api.model
    def default_get(self, fields):
        res = super(TrainingOfferLetterWizard, self).default_get(fields)
        active_id = self._context.get('active_id')
        trainee = self.env['trainee.details'].browse(active_id)
        today = (date.today()).strftime('%B %d, %Y')
        batch = trainee.details_id.hpl_team + '-' + str(trainee.details_id.batch_no)
        birth = ''
        if trainee.applicant_name.gender.code == '1':
            title = 'Mr.'
        else:
            title = 'Ms.'

        print(self.signee.full_name, self.signee.position)
        if trainee.applicant_name.date_of_birth:
            birth = (trainee.applicant_name.date_of_birth).strftime('%B %d, %Y')
        res['offer_letter_template'] = strings.offer_letter_template.format(
            trainee.name, trainee.applicant_name.father, trainee.applicant_name.mother, trainee.applicant_name.village, trainee.applicant_name.post_office, trainee.applicant_name.police_station,
            trainee.applicant_name.district, birth, trainee.phone_number, today, batch, (trainee.details_id.starting_date).strftime('%B-%Y'),
            title, trainee.last_name, trainee.details_id.venue_details.name, (trainee.details_id.starting_date).strftime('%B %d, %Y'), (trainee.details_id.closing_date).strftime('%B %d,%Y'),trainee.details_id.reporting_time,
            trainee.details_id.duration, self.signee.full_name, self.signee.position)
        return res

    @api.onchange('offer_letter_template')
    def change_trainee(self):
        active_id = self._context.get('active_id')
        trainee = self.env['trainee.details'].browse(active_id)
        for rec in self:
            trainee.signee = self.signee.full_name
            trainee.signee_position = self.signee.position

    @api.onchange('signee')
    def change_trainee(self):
        active_id = self._context.get('active_id')
        trainee = self.env['trainee.details'].browse(active_id)
        for rec in self:
            trainee.offer_letter_template = rec['offer_letter_template']
            trainee.signee = self.signee.full_name
            trainee.signee_position = self.signee.position_name



    def action_send_offer_letter(self):
        active_id = self._context.get('active_id')
        trainee = self.env['trainee.details'].browse(active_id)
        template_id = self.env.ref('ccl_recruitment_training.offer_letter_email_template').id
        template = self.env['mail.template'].browse(template_id)
        template.send_mail(trainee.id, force_send=True)


    def print_offer_letter(self):
        active_id = self._context.get('active_id')
        trainee = self.env['trainee.details'].browse(active_id)
        template_id = self.env.ref('ccl_recruitment_training.offer_letter_email_template').id
        template = self.env['mail.template'].browse(template_id)
        return self.env.ref('ccl_recruitment_training.training_offer_letter_pdf').report_action(trainee.id)

