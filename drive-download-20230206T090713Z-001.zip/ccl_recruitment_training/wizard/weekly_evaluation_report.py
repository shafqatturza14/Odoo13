import math

from odoo import fields, api, models


class WeeklyEvaluationReport(models.TransientModel):
    _name = 'weekly.evaluation.report'

    batch_id = fields.Many2one('trainee.details.main', string='Batch NO', required=False)

    def generate_weekly_evaluation_result_report(self):
        data = {
            'batch_id': self.batch_id.id,
        }
        return self.env.ref('ccl_recruitment_training.weekly_report_xlsx').report_action(self, data=data)


class ReturnXlsxReport(models.AbstractModel):
    _name = 'report.ccl_recruitment_training.weekly_report_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('')
        format_heading_tr = workbook.add_format({'border': True, 'font_size': 10,'valign':'vcenter',  'align': 'center', 'bold': True, 'text_wrap': True, 'font_name':'cambria'})
        format_heading = workbook.add_format({'border': True, 'font_size': 10, 'valign':'vcenter', 'align': 'center', 'bold': True, 'text_wrap': True, 'font_name':'cambria'})
        format_body = workbook.add_format({'font_size': 9,'valign':'vcenter',  'align': 'center', 'font_name':'cambria', 'border': True})
        format_body_avg = workbook.add_format({'text_wrap': True, 'font_size': 9,'valign':'vcenter',  'align': 'center','bg_color':'#d9d1d1', 'font_name':'cambria', 'border': True})
        format_body_avg_title = workbook.add_format({'bold': True,'text_wrap': True, 'font_size': 9,'valign':'vcenter',  'align': 'center','bg_color':'#d9d1d1', 'font_name':'cambria', 'border': True})
        format_body_name = workbook.add_format({'font_size': 9, 'align': 'left', 'valign':'vcenter', 'font_name':'cambria', 'border': True})
        bold = workbook.add_format(
            {'font_size': 13, 'bold': True, 'font_name':'cambria', 'valign':'vcenter',  'align': 'center', 'border': True, 'text_wrap': True})

        sheet.merge_range('A1:Z2', 'HealthCare Pharmaceuticals Ltd.', bold)
        sheet.merge_range('A3:Z3', "Weekly Evaluation Sheet", bold)

        sheet.write(3, 0, 'SI', format_heading_tr)
        sheet.write(3, 1, 'Trainee Name', format_heading_tr)
        sheet.write(3, 2, 'Trainee ID', format_heading_tr)

        sheet.set_row(3, 50)  # Set the height of Row 1 to 20.
        sheet.set_row(2, 40)  # Set the height of Row 1 to 20.
        sheet.set_column(1, 2, 20)
        head_col = 3
        head_row = 3
        main_row = 4
        main_col = 3
        col = 3
        sheet.set_column(0, 0, 3)
        batch = (data.get('batch_id'))

        trainee_batch = self.env['trainee.details.main'].search([('id', '=', batch)])
        trainee = self.env['trainee.details'].search([('details_id', '=', trainee_batch.id)])

        tr_row = 4
        sl = 1
        for trai in trainee:
            sheet.write(tr_row, 0, sl, format_body)
            sheet.write(tr_row, 1, trai.name, format_body_name)
            sheet.write(tr_row, 2, trai.t_id, format_body)
            sheet.set_row(tr_row,20)
            tr_row += 1
            sl += 1

        avg_exist = False
        sys_cnt = 0
        system_batch = self.env['system.pss'].search([('batch_id', '=', batch)])
        system_trainees = self.env['trainee.system'].search([('trainee_track_id', '=', system_batch.id)])
        for sys in system_trainees:
            system_sub = self.env['trainee.system.subject'].search([('subject_id', '=', sys.id)])
            for sub in system_sub:
                if sub.obtain_mark > 0.0:
                    sheet.write(head_row, head_col, sub.subject, format_heading_tr)
                    head_col += 1
                    sys_cnt += 1
                    avg_exist = True
            if avg_exist == True:
                sheet.write(head_row, head_col, 'Basic AVG', format_body_avg_title)
            break
        if avg_exist == True:
            head_col += 2
            sheet.set_column(head_col-1,head_col-1, 3)

        system_batch = self.env['system.pss'].search([('batch_id', '=', batch)])
        system_trainees = self.env['trainee.system'].search([('trainee_track_id', '=', system_batch.id)])
        lp = 0
        row = main_row
        for sys in system_trainees:
            system_sub = self.env['trainee.system.subject'].search([('subject_id', '=', sys.id)])
            col = main_col
            for sub in system_sub:
                if sub.obtain_mark > 0.0:
                    sheet.write(row, col, sub.obtain_mark, format_body)
                    lp += 1
                    col += 1
                    if lp == sys_cnt:
                        break
            if avg_exist == True:
                sheet.write(row, col, sys.system_sum, format_body_avg)
            row += 1
        if avg_exist == True:
            main_col = col
            main_col += 2

        avg_exist = False
        pss_cnt = 0
        pss_batch = self.env['pss.ii'].search([('batch_id', '=', batch)])
        pss_trainees = self.env['pss.ii.trainee.system'].search([('trainee_track_id', '=', pss_batch.id)])
        for pss in pss_trainees:
            system_sub = self.env['pss.ii.trainee.system.subject'].search([('subject_id', '=', pss.id)])
            for sub in system_sub:
                if sub.obtain_mark > 0.0:
                    sheet.write(head_row, head_col, sub.subject, format_heading_tr)
                    head_col += 1
                    pss_cnt += 1
                    avg_exist = True
            if avg_exist == True:
                sheet.write(head_row, head_col, 'PSS AVG', format_body_avg_title)
            break
        if avg_exist == True:
            head_col += 2
            sheet.set_column(head_col-1,head_col-1, 3)


        pss_batch = self.env['pss.ii'].search([('batch_id', '=', batch)])
        pss_trainees = self.env['pss.ii.trainee.system'].search([('trainee_track_id', '=', pss_batch.id)])
        lp = 0
        row = main_row
        for pss in pss_trainees:
            system_sub = self.env['pss.ii.trainee.system.subject'].search([('subject_id', '=', pss.id)])
            col = main_col
            for sub in system_sub:
                if sub.obtain_mark > 0.0:
                    sheet.write(row, col, sub.obtain_mark, format_body)
                    lp += 1
                    col += 1
                    if lp == pss_cnt:
                        break
            if avg_exist == True:
                sheet.write(row, col, pss.pss_ii_sum, format_body_avg)
            row += 1
        if avg_exist == True:
            main_col = col
            main_col += 2

        avg_exist = False
        pro_cnt = 0
        pro_batch = self.env['products.sheet'].search([('batch_id', '=', batch)])
        pro_trainees = self.env['products.trainee.list'].search([('trainee_track_id', '=', pro_batch.id)])
        for pro in pro_trainees:
            system_sub = self.env['product.subject'].search([('subject_id', '=', pro.id)])
            for sub in system_sub:
                if sub.obtain_mark > 0.0:
                    sheet.write(head_row, head_col, sub.subject, format_heading_tr)
                    head_col += 1
                    pro_cnt += 1
                    avg_exist = True
            if avg_exist == True:
                sheet.write(head_row, head_col, 'Products AVG', format_body_avg_title)
            break
        if avg_exist == True:
            head_col += 2
            sheet.set_column(head_col-1,head_col-1, 3)


        pro_batch = self.env['products.sheet'].search([('batch_id', '=', batch)])
        pro_trainees = self.env[ 'products.trainee.list'].search([('trainee_track_id', '=', pro_batch.id)])
        lp = 0
        row = main_row
        for pro in pro_trainees:
            pro_sub = self.env['product.subject'].search([('subject_id', '=', pro.id)])
            col = main_col
            for sub in pro_sub:
                if sub.obtain_mark > 0.0:
                    sheet.write(row, col, sub.obtain_mark, format_body)
                    lp += 1
                    col += 1
                    print(lp)
                    if lp == pro_cnt:
                        break
            if avg_exist == True:
                sheet.write(row, col, pro.product_sum, format_body_avg)
            row += 1
        if avg_exist == True:
            main_col = col
            main_col += 2


        avg_exist = False
        ass_cnt = 0
        ass_batch = self.env['assignment.sheet'].search([('batch_id', '=', batch)])
        ass_trainees = self.env['trainee.assignment.lines'].search([('trainee_track_id', '=', ass_batch.id)])
        for ass in ass_trainees:
            system_sub = self.env['assignment.system.subject'].search([('subject_id', '=', ass.id)])
            for sub in system_sub:
                if sub.obtain_mark > 0.0:
                    sheet.write(head_row, head_col, sub.subject, format_heading_tr)
                    head_col += 1
                    ass_cnt += 1
                    avg_exist = True
            if avg_exist == True:
                sheet.write(head_row, head_col, 'Assignment AVG', format_body_avg_title)
            break

        if avg_exist == True:
            head_col += 2
            sheet.set_column(head_col-1,head_col-1, 3)

        ass_batch = self.env['assignment.sheet'].search([('batch_id', '=', batch)])
        ass_trainees = self.env['trainee.assignment.lines'].search([('trainee_track_id', '=', ass_batch.id)])
        lp = 0
        row = main_row
        for ass in ass_trainees:
            system_sub = self.env['assignment.system.subject'].search([('subject_id', '=', ass.id)])
            col = main_col
            for sub in system_sub:
                if sub.obtain_mark > 0.0:
                    sheet.write(row, col, sub.obtain_mark, format_body)
                    lp += 1
                    col += 1
                    if lp == ass_cnt:
                        break
            if avg_exist == True:
                sheet.write(row, col, ass.assignment_sum, format_body_avg)
            row += 1
        if avg_exist == True:
            main_col = col
            main_col += 2

        avg_exist = False
        gro_cnt = 0
        gro_batch = self.env['grooming.role.sheet'].search([('batch_id', '=', batch)])
        gro_trainees = self.env['grooming.role.play.list'].search([('trainee_track_id', '=', gro_batch.id)])
        for pro in gro_trainees:
            system_sub = self.env['role.play.subject'].search([('subject_id', '=', pro.id)])
            for sub in system_sub:
                if sub.grooming_mark > 0.0:
                    sheet.write(head_row, head_col, sub.subject, format_heading_tr)
                    head_col += 1
                    gro_cnt += 1
                    avg_exist = True
            if avg_exist == True:
                sheet.write(head_row, head_col, 'Grooming AVG', format_body_avg_title)
            break
        if avg_exist == True:
            head_col += 2
            sheet.set_column(head_col - 1, head_col - 1, 3)

        gro_batch = self.env['grooming.role.sheet'].search([('batch_id', '=', batch)])
        gro_trainees = self.env['grooming.role.play.list'].search([('trainee_track_id', '=', gro_batch.id)])
        lp = 0
        row = main_row
        for gro in gro_trainees:
            gro_sub = self.env['role.play.subject'].search([('subject_id', '=', gro.id)])
            col = main_col
            for sub in gro_sub:
                if sub.grooming_mark > 0.0:
                    sheet.write(row, col, sub.grooming_mark, format_body)
                    lp += 1
                    col += 1
                    print(lp)
                    if lp == gro_cnt:
                        break
            if avg_exist == True:
                sheet.write(row, col, gro.grooming_sum, format_body_avg)
            row += 1
        if avg_exist == True:
            main_col = col
            main_col += 2

        avg_exist = False
        role_cnt = 0
        role_batch = self.env['grooming.role.sheet'].search([('batch_id', '=', batch)])
        role_trainees = self.env['grooming.role.play.list'].search([('trainee_track_id', '=', role_batch.id)])
        for role in role_trainees:
            system_sub = self.env['role.play.subject'].search([('subject_id', '=', role.id)])
            for sub in system_sub:
                if sub.role_play_mark > 0.0:
                    sheet.write(head_row, head_col, sub.subject, format_heading_tr)
                    head_col += 1
                    role_cnt += 1
                    avg_exist = True
            if avg_exist == True:
                sheet.write(head_row, head_col, 'Role Play AVG', format_body_avg_title)
            break
        if avg_exist == True:
            head_col += 2
            sheet.set_column(head_col - 1, head_col - 1, 3)

        role_batch = self.env['grooming.role.sheet'].search([('batch_id', '=', batch)])
        role_trainees = self.env['grooming.role.play.list'].search([('trainee_track_id', '=', role_batch.id)])
        lp = 0
        row = main_row
        for role in role_trainees:
            system_sub = self.env['role.play.subject'].search([('subject_id', '=', role.id)])
            col = main_col
            for sub in system_sub:
                if sub.role_play_mark > 0.0:
                    sheet.write(row, col, sub.role_play_mark, format_body)
                    lp += 1
                    col += 1
                    print(lp)
                    if lp == role_cnt:
                        break
            if avg_exist == True:
                sheet.write(row, col, role.role_sum, format_body_avg)
            row += 1
        if avg_exist == True:
            main_col = col
            main_col += 2
