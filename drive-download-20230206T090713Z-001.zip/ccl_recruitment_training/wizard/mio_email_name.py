# -*- coding: utf-8 -*-
from odoo import fields, api, models, _
from datetime import date
from . import strings
from odoo.exceptions import UserError



class MioEmailWizard(models.TransientModel):
    _name = 'mio.email.wizard'



    wiz_to_name = fields.Many2one('hpl.employee', 'To Name')
    to_name_mail = fields.Char('To Mail')
    wiz_c_name = fields.Many2many('hpl.employee', string='Concern People')
    all_cc_mail = fields.Char('Concern Mail')

    @api.model
    def default_get(self, fields):
        res = super(MioEmailWizard, self).default_get(fields)
        active_id = self._context.get('active_id')
        trainee = self.env['trainee.details.main'].browse(active_id)
        return res

    @api.onchange('wiz_to_name','wiz_c_name')
    def change_mail(self):
        active_id = self._context.get('active_id')
        trainee = self.env['trainee.details.main'].browse(active_id)
        cc_all_mail = ''
        for rec in self:
            for to in rec.wiz_to_name.communication_line:
                if to.communication_type.code == '0010':
                    print("====================CODE=================")
                    trainee.to_name = to.value
                    rec.to_name_mail = to.value
            print("===================CC Name=================")
            print(rec.wiz_c_name)
            for wiz in rec.wiz_c_name:
                print("===================CC Name=================")
                for con in wiz.communication_line:
                    if con.communication_type.code == '0010':
                        cc_all_mail += con.value + ','
                        rec.all_cc_mail += con.value + ','
                        print(con.value)
                        print("IF section")

            print(cc_all_mail)
            trainee.concern = cc_all_mail
            rec.all_cc_mail = cc_all_mail

    def action_send_mio_list(self):
        active_id = self._context.get('active_id')
        trainee = self.env['trainee.details.main'].browse(active_id)
        template_id = self.env.ref('ccl_recruitment_training.mio_card_email_template').id
        template = self.env['mail.template'].browse(template_id)
        print("=====================Template=====================")
        print(template_id)
        template['email_cc'] = self.all_cc_mail
        template.send_mail(trainee.id, force_send=True)



