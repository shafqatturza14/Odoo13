import math

from odoo import fields, api, models


class FinalResultSheet(models.TransientModel):
    _name = 'final.result.sheet'

    batch_id = fields.Many2one('final.result.sheet.details', string='Batch NO', required=False)

    def generate_final_result_report(self):
        data = {
            'batch_id': self.batch_id.id,
        }
        return self.env.ref('ccl_recruitment_training.action_final_result_report_xlsx').report_action(self, data=data)


class ReturnXlsxReport(models.AbstractModel):
    _name = 'report.ccl_recruitment_training.final_result_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('Final Result Sheet Report')
        format_heading = workbook.add_format(
            {'font_name': 'cambria', 'font_size': 10, 'align': 'center', 'valign': 'vcenter', 'bold': True,
             'border': True, 'text_wrap': True})

        format_body = workbook.add_format(
            {'font_name': 'cambria', 'font_size': 10, 'align': 'center', 'valign': 'vcenter', 'border': True})

        format_body_name = workbook.add_format(
            {'font_name': 'cambria', 'font_size': 10, 'align': 'left', 'valign': 'vcenter', 'border': True})

        bold = workbook.add_format(
            {'font_name': 'cambria', 'font_size': 15, 'bold': True, 'align': 'center', 'valign': 'vcenter'})

        sheet.write(5, 0, 'SI', format_heading)
        sheet.write(5, 1, 'Trainee Name', format_heading)
        sheet.write(5, 2, 'Trainee ID', format_heading)
        sheet.write(5, 3, 'System (30)', format_heading)
        sheet.write(5, 4, 'PSS-II (20)', format_heading)
        sheet.write(5, 5, 'Products(20)', format_heading)
        sheet.write(5, 6, 'Role Play (5)', format_heading)
        sheet.write(5, 7, 'Grooming(5)', format_heading)
        sheet.write(5, 8, 'Oral Test(10)', format_heading)
        sheet.write(5, 9, 'Assignment (10)', format_heading)
        sheet.write(5, 10, 'Total (100)', format_heading)
        sheet.write(5, 11, 'Category', format_heading)

        sheet.merge_range('A1:L2', 'Healthcare Pharmaceuticals Ltd.', bold)
        sheet.merge_range('A3:L4', "Result Sheet_Summary", format_heading)

        sheet.set_column(1, 2, 20)
        sheet.set_column(3, 15, 13)

        batch = data.get('batch_id')

        sql_query = f"""
                         SELECT   
                        result.trainee_name           AS trainee_name,
                        result.trainee_code           AS trainee_code,
                        result.system                 AS system,
                        result.pss                    AS pss,
                        result.products               AS products,
                        result.role_play              AS role_play,
                        result.grooming               AS grooming,                        
                        result.oral_test              AS oral_test,
                        result.assignment             AS assignment,
                        result.total                  AS total,
                        result.category               AS category

              FROM    trainee_details_main           as trainee_details_main JOIN
                      final_result_sheet_details     as final_result on trainee_details_main.id = final_result.batch_id FULL JOIN
                      result_list                    as result on result.final_sheet_id = final_result.id

              where 
                      final_result.id = '%s'

              GROUP BY 
                        trainee_details_main.batch_no,
                        final_result.batch_id,
                        result.trainee_name,
                        result.trainee_code,
                        result.system,
                        result.pss,
                        result.products,
                        result.role_play,
                        result.assignment,
                        result.grooming,
                        result.oral_test,
                        result.total,
                        result.category;            

                        """ % (batch)

        self.env.cr.execute(sql_query)
        query_data = self.env.cr.fetchall()

        rows = 6
        columns = 1
        si = 1
        sum = 0.0
        for row, items in enumerate(query_data, start=1):
            sheet.write(rows, 0, si, format_body)
            for col, item in enumerate(items):
                if columns == 1:
                    sheet.write(rows, columns, item, format_body_name)
                else:
                    if columns > 2 and item is not None and columns < 11:
                        item = math.ceil(float(item))
                    sheet.write(rows, columns, item, format_body)
                columns += 1

            columns = 1
            si += 1
            rows += 1
