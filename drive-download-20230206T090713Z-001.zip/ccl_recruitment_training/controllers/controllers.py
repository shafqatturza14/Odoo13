# -*- coding: utf-8 -*-
# from odoo import http


# class CclRecruitmentTraining(http.Controller):
#     @http.route('/ccl_recruitment_training/ccl_recruitment_training/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/ccl_recruitment_training/ccl_recruitment_training/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('ccl_recruitment_training.listing', {
#             'root': '/ccl_recruitment_training/ccl_recruitment_training',
#             'objects': http.request.env['ccl_recruitment_training.ccl_recruitment_training'].search([]),
#         })

#     @http.route('/ccl_recruitment_training/ccl_recruitment_training/objects/<model("ccl_recruitment_training.ccl_recruitment_training"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('ccl_recruitment_training.object', {
#             'object': obj
#         })
